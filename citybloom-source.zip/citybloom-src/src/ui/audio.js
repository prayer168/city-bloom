// 聲音：配景音樂、城市廣播的提示音與語音
// 全部用 Web Audio 即時合成（原創旋律與和弦進行，不使用任何錄音或現成曲子）。
// 瀏覽器規定要使用者先互動才能出聲，所以預設是關的，由玩家在「聲音」選單打開。

const NOTE = (n) => 440 * Math.pow(2, (n - 69) / 12); // MIDI 音高 → 頻率

// 三種氣氛的和弦（MIDI）：平常（大調五聲）、災害（小調、低一點）、炎熱（明亮但稀疏）
const MOODS = {
  calm: { chords: [[48, 55, 64, 71], [45, 52, 60, 67], [41, 48, 57, 64], [43, 50, 59, 64]], scale: [72, 74, 76, 79, 81, 84], beat: 0.9, chordBeats: 8, filter: 1400 },
  storm: { chords: [[45, 52, 60, 67], [41, 48, 57, 64], [38, 45, 53, 60], [40, 47, 55, 62]], scale: [69, 72, 74, 76, 79], beat: 1.1, chordBeats: 8, filter: 900 },
  heat: { chords: [[50, 57, 66, 69], [47, 54, 62, 66], [43, 50, 59, 66], [45, 52, 61, 64]], scale: [74, 76, 78, 81, 83, 86], beat: 1.2, chordBeats: 6, filter: 1800 },
};

function load() {
  try { return JSON.parse(localStorage.getItem('zc-sound') || '{}'); } catch { return {}; }
}
function save(s) {
  try { localStorage.setItem('zc-sound', JSON.stringify(s)); } catch { /* 無痕模式等情況：只是不記住設定 */ }
}

export class SoundEngine {
  constructor() {
    const s = load();
    this.settings = { music: !!s.music, volume: s.volume ?? 0.5, voice: s.voice ?? true, chime: s.chime ?? true };
    this.ctx = null;
    this.mood = 'calm';
    this.timer = null;
    this.step = 0;
    this.voices = [];
  }

  // 第一次互動時建立音訊環境
  ensure() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return this.ctx; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    const ctx = new AC();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = this.settings.volume;
    const comp = ctx.createDynamicsCompressor();
    this.master.connect(comp).connect(ctx.destination);
    // 音樂匯流排（廣播時壓低）
    this.musicBus = ctx.createGain();
    this.musicBus.gain.value = 0.55;
    this.filter = ctx.createBiquadFilter();
    this.filter.type = 'lowpass';
    this.filter.frequency.value = 1400;
    this.musicBus.connect(this.filter).connect(this.master);
    // 旋律用的回音
    this.delay = ctx.createDelay(1);
    this.delay.delayTime.value = 0.36;
    const fb = ctx.createGain(); fb.gain.value = 0.3;
    const wet = ctx.createGain(); wet.gain.value = 0.28;
    this.delay.connect(fb).connect(this.delay);
    this.delay.connect(wet).connect(this.filter);
    this.sfxBus = ctx.createGain();
    this.sfxBus.gain.value = 0.9;
    this.sfxBus.connect(this.master);
    return ctx;
  }

  set(key, value) {
    this.settings[key] = value;
    save(this.settings);
    if (key === 'volume' && this.master) this.master.gain.setTargetAtTime(value, this.ctx.currentTime, 0.05);
    if (key === 'music') value ? this.startMusic() : this.stopMusic();
    if (key === 'voice' && !value) window.speechSynthesis?.cancel();
  }

  setMood(m) {
    if (!MOODS[m] || m === this.mood) return;
    this.mood = m;
    if (this.filter) this.filter.frequency.setTargetAtTime(MOODS[m].filter, this.ctx.currentTime, 1.5);
  }

  startMusic() {
    if (!this.ensure() || this.timer) return;
    this.nextTime = this.ctx.currentTime + 0.1;
    this.step = 0;
    // 每 0.2 秒往前排程，聲音不會因為畫面忙而斷斷續續
    this.timer = setInterval(() => this.schedule(), 200);
  }
  stopMusic() {
    clearInterval(this.timer);
    this.timer = null;
  }

  schedule() {
    const ctx = this.ctx;
    while (this.nextTime < ctx.currentTime + 0.6) {
      const m = MOODS[this.mood];
      const chord = m.chords[Math.floor(this.step / m.chordBeats) % m.chords.length];
      if (this.step % m.chordBeats === 0) this.pad(chord, this.nextTime, m.beat * m.chordBeats);
      // 旋律：大約一半的拍子出現一個音，從五聲音階裡挑（聽起來柔和、不會有刺耳的音）
      const r = Math.sin(this.step * 12.9898 + this.mood.length * 78.233) * 43758.5453;
      const rnd = r - Math.floor(r);
      if (rnd < 0.45) this.pluck(m.scale[Math.floor(rnd * 1000) % m.scale.length], this.nextTime);
      if (this.step % 16 === 8 && rnd < 0.7) this.pluck(chord[0] + 24, this.nextTime + m.beat / 2, 0.06);
      this.nextTime += m.beat;
      this.step++;
    }
  }

  pad(notes, t, dur) {
    const ctx = this.ctx;
    for (const n of notes) {
      for (const [type, det, vol] of [['triangle', -4, 0.05], ['sine', 5, 0.045]]) {
        const o = ctx.createOscillator();
        o.type = type;
        o.frequency.value = NOTE(n);
        o.detune.value = det;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(vol, t + 2);
        g.gain.setValueAtTime(vol, t + dur - 1.5);
        g.gain.linearRampToValueAtTime(0, t + dur + 1);
        o.connect(g).connect(this.musicBus);
        o.start(t); o.stop(t + dur + 1.1);
      }
    }
  }

  pluck(n, t, vol = 0.09) {
    const ctx = this.ctx;
    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.value = NOTE(n);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 1.6);
    o.connect(g);
    g.connect(this.musicBus);
    g.connect(this.delay);
    o.start(t); o.stop(t + 1.7);
  }

  // 廣播提示音：兩聲柔和的鐘聲（高 → 低）
  chime() {
    if (!this.settings.chime || !this.ensure()) return;
    const ctx = this.ctx;
    const t0 = ctx.currentTime + 0.02;
    [[76, 0], [72, 0.32]].forEach(([n, dt]) => {
      for (const [mult, vol] of [[1, 0.22], [2.76, 0.05]]) {
        const o = ctx.createOscillator();
        o.type = 'sine';
        o.frequency.value = NOTE(n) * mult;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t0 + dt);
        g.gain.linearRampToValueAtTime(vol, t0 + dt + 0.01);
        g.gain.exponentialRampToValueAtTime(0.0005, t0 + dt + 1.4);
        o.connect(g).connect(this.sfxBus);
        o.start(t0 + dt); o.stop(t0 + dt + 1.5);
      }
    });
  }

  // 城市廣播語音（瀏覽器內建的語音合成，有中文語音才會唸）
  speak(text) {
    const synth = window.speechSynthesis;
    if (!this.settings.voice || !synth || typeof SpeechSynthesisUtterance === 'undefined') return false;
    if (!this.voices.length) this.voices = synth.getVoices();
    const voice = this.voices.find((v) => /zh[-_]TW/i.test(v.lang)) || this.voices.find((v) => /^zh/i.test(v.lang));
    if (!voice) return false;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.voice = voice;
    u.lang = voice.lang;
    u.rate = 1.05;
    u.volume = Math.min(1, this.settings.volume + 0.3);
    // 唸的時候把音樂壓低
    if (this.musicBus) this.musicBus.gain.setTargetAtTime(0.18, this.ctx.currentTime, 0.2);
    u.onend = () => { if (this.musicBus) this.musicBus.gain.setTargetAtTime(0.55, this.ctx.currentTime, 0.5); };
    setTimeout(() => synth.speak(u), 700); // 鐘聲之後再唸
    return true;
  }

  hasVoice() {
    const synth = window.speechSynthesis;
    if (!synth) return false;
    if (!this.voices.length) this.voices = synth.getVoices();
    return this.voices.some((v) => /^zh/i.test(v.lang));
  }
}
