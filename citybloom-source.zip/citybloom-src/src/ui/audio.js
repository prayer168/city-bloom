// 聲音：配景音樂與天氣音效
// 全部用 Web Audio 即時合成（原創旋律與和弦進行，不使用任何錄音或現成曲子）。
//   配景音樂：預設關閉，從「聲音」選單打開。
//   天氣音效：下雨、颱風的風雨聲、遠方雷聲、熱浪時的蟬鳴。預設打開（瀏覽器規定：第一次點畫面後才會出聲）。
// 城市廣播只有文字與發光邊框，沒有人聲。

const NOTE = (n) => 440 * Math.pow(2, (n - 69) / 12); // MIDI 音高 → 頻率

// 三種氣氛的和弦（MIDI）：平常（大調五聲）、災害（小調、低一點）、炎熱（明亮但稀疏）
const MOODS = {
  calm: { chords: [[48, 55, 64, 71], [45, 52, 60, 67], [41, 48, 57, 64], [43, 50, 59, 64]], scale: [72, 74, 76, 79, 81, 84], beat: 0.9, chordBeats: 8, filter: 1400 },
  storm: { chords: [[45, 52, 60, 67], [41, 48, 57, 64], [38, 45, 53, 60], [40, 47, 55, 62]], scale: [69, 72, 74, 76, 79], beat: 1.1, chordBeats: 8, filter: 900 },
  heat: { chords: [[50, 57, 66, 69], [47, 54, 62, 66], [43, 50, 59, 66], [45, 52, 61, 64]], scale: [74, 76, 78, 81, 83, 86], beat: 1.2, chordBeats: 6, filter: 1800 },
};

function load() {
  try { return JSON.parse(localStorage.getItem('zc-sound') || '{}'); } catch { return {}; }
}
function save(s) {
  try { localStorage.setItem('zc-sound', JSON.stringify(s)); } catch { /* 無痕模式等情況：只是不記住設定 */ }
}

export class SoundEngine {
  constructor() {
    const s = load();
    this.settings = { music: !!s.music, sfx: s.sfx ?? true, volume: s.volume ?? 0.6 };
    this.ctx = null;
    this.mood = 'calm';
    this.timer = null;
    this.step = 0;
    this.weather = { rain: 0, wind: 0, heat: 0 };
  }

  // 第一次互動時建立音訊環境
  ensure() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return this.ctx; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    const ctx = new AC();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = this.settings.volume;
    const comp = ctx.createDynamicsCompressor();
    this.master.connect(comp).connect(ctx.destination);
    // 音樂
    this.musicBus = ctx.createGain();
    this.musicBus.gain.value = 0.5;
    this.filter = ctx.createBiquadFilter();
    this.filter.type = 'lowpass';
    this.filter.frequency.value = 1400;
    this.musicBus.connect(this.filter).connect(this.master);
    this.delay = ctx.createDelay(1);
    this.delay.delayTime.value = 0.36;
    const fb = ctx.createGain(); fb.gain.value = 0.3;
    const wet = ctx.createGain(); wet.gain.value = 0.28;
    this.delay.connect(fb).connect(this.delay);
    this.delay.connect(wet).connect(this.filter);
    // 天氣音效
    this.sfxBus = ctx.createGain();
    this.sfxBus.gain.value = this.settings.sfx ? 1 : 0;
    this.sfxBus.connect(this.master);
    this.buildWeather();
    this.applyWeather();
    return ctx;
  }

  set(key, value) {
    this.settings[key] = value;
    save(this.settings);
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    if (key === 'volume') this.master.gain.setTargetAtTime(value, t, 0.05);
    if (key === 'music') value ? this.startMusic() : this.stopMusic();
    if (key === 'sfx') this.sfxBus.gain.setTargetAtTime(value ? 1 : 0, t, 0.2);
  }

  setMood(m) {
    if (!MOODS[m] || m === this.mood) return;
    this.mood = m;
    if (this.filter) this.filter.frequency.setTargetAtTime(MOODS[m].filter, this.ctx.currentTime, 1.5);
  }

  // ---------------- 天氣音效 ----------------
  // 一段 2 秒的白噪音循環播放，再用濾波器做出雨聲與風聲
  buildWeather() {
    const ctx = this.ctx;
    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;
    const noise = () => { const s = ctx.createBufferSource(); s.buffer = buf; s.loop = true; s.start(); return s; };

    // 雨：高頻的沙沙聲 + 低一點的嘩啦聲
    const rainHi = ctx.createBiquadFilter(); rainHi.type = 'highpass'; rainHi.frequency.value = 1200;
    const rainLo = ctx.createBiquadFilter(); rainLo.type = 'lowpass'; rainLo.frequency.value = 9000;
    this.rainGain = ctx.createGain(); this.rainGain.gain.value = 0;
    noise().connect(rainHi).connect(rainLo).connect(this.rainGain).connect(this.sfxBus);
    const heavy = ctx.createBiquadFilter(); heavy.type = 'bandpass'; heavy.frequency.value = 500; heavy.Q.value = 0.6;
    this.heavyGain = ctx.createGain(); this.heavyGain.gain.value = 0;
    noise().connect(heavy).connect(this.heavyGain).connect(this.sfxBus);

    // 風：帶通濾波的噪音，頻率與音量慢慢起伏，聽起來像呼嘯的強風
    const wf = ctx.createBiquadFilter(); wf.type = 'bandpass'; wf.frequency.value = 500; wf.Q.value = 1.4;
    this.windGain = ctx.createGain(); this.windGain.gain.value = 0;
    const windAmp = ctx.createGain(); windAmp.gain.value = 0.6;
    noise().connect(wf).connect(windAmp).connect(this.windGain).connect(this.sfxBus);
    const lfo1 = ctx.createOscillator(); lfo1.frequency.value = 0.13;
    const lfo1g = ctx.createGain(); lfo1g.gain.value = 320;
    lfo1.connect(lfo1g).connect(wf.frequency); lfo1.start();
    const lfo2 = ctx.createOscillator(); lfo2.frequency.value = 0.21;
    const lfo2g = ctx.createGain(); lfo2g.gain.value = 0.4;
    lfo2.connect(lfo2g).connect(windAmp.gain); lfo2.start();

    // 蟬鳴（熱浪）：高頻的音，用快速的脈衝調變
    const cic = ctx.createOscillator(); cic.type = 'sawtooth'; cic.frequency.value = 4300;
    const cicF = ctx.createBiquadFilter(); cicF.type = 'bandpass'; cicF.frequency.value = 4800; cicF.Q.value = 3;
    const pulse = ctx.createGain(); pulse.gain.value = 0;
    const am = ctx.createOscillator(); am.type = 'square'; am.frequency.value = 38;
    const amg = ctx.createGain(); amg.gain.value = 0.5;
    am.connect(amg).connect(pulse.gain); am.start();
    this.cicadaGain = ctx.createGain(); this.cicadaGain.gain.value = 0;
    cic.connect(cicF).connect(pulse).connect(this.cicadaGain).connect(this.sfxBus); cic.start();
    const swell = ctx.createOscillator(); swell.frequency.value = 0.09;
    const swellG = ctx.createGain(); swellG.gain.value = 0.25;
    swell.connect(swellG).connect(pulse.gain); swell.start();
  }

  // 依畫面的天氣調整音量：rain、wind、heat 都是 0–1
  setWeather(w) {
    this.weather = { rain: w.rain || 0, wind: w.wind || 0, heat: w.heat || 0 };
    this.applyWeather();
  }
  applyWeather() {
    if (!this.ctx || !this.rainGain) return;
    const t = this.ctx.currentTime;
    const { rain, wind, heat } = this.weather;
    this.rainGain.gain.setTargetAtTime(rain > 0 ? 0.28 + 0.32 * rain : 0, t, 1.2);
    this.heavyGain.gain.setTargetAtTime(rain > 0.5 ? 0.35 * rain : 0, t, 1.2);
    this.windGain.gain.setTargetAtTime(wind > 0 ? 0.5 + 0.5 * wind : 0, t, 1.5);
    this.cicadaGain.gain.setTargetAtTime(heat > 0.5 && rain === 0 ? 0.05 + 0.05 * heat : 0, t, 2);
    // 颱風與大豪雨：遠方的雷聲
    clearTimeout(this.thunderTimer);
    if (rain > 0.6 || wind > 0) this.scheduleThunder();
  }
  scheduleThunder() {
    this.thunderTimer = setTimeout(() => {
      if (this.settings.sfx && this.ctx && (this.weather.rain > 0.6 || this.weather.wind > 0)) {
        this.thunder();
        this.scheduleThunder();
      }
    }, 7000 + Math.random() * 12000);
  }
  thunder() {
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const s = ctx.createBufferSource(); s.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(400, t); f.frequency.exponentialRampToValueAtTime(90, t + 2.5);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.9, t + 0.08);
    g.gain.exponentialRampToValueAtTime(0.001, t + 3.2);
    s.connect(f).connect(g).connect(this.sfxBus);
    s.start(t); s.stop(t + 3.3);
  }

  // ---------------- 配景音樂 ----------------
  startMusic() {
    if (!this.ensure() || this.timer) return;
    this.nextTime = this.ctx.currentTime + 0.1;
    this.step = 0;
    // 每 0.2 秒往前排程，聲音不會因為畫面忙而斷斷續續
    this.timer = setInterval(() => this.schedule(), 200);
  }
  stopMusic() {
    clearInterval(this.timer);
    this.timer = null;
  }

  schedule() {
    const ctx = this.ctx;
    while (this.nextTime < ctx.currentTime + 0.6) {
      const m = MOODS[this.mood];
      const chord = m.chords[Math.floor(this.step / m.chordBeats) % m.chords.length];
      if (this.step % m.chordBeats === 0) this.pad(chord, this.nextTime, m.beat * m.chordBeats);
      // 旋律：大約一半的拍子出現一個音，從五聲音階裡挑（聽起來柔和、不會有刺耳的音）
      const r = Math.sin(this.step * 12.9898 + this.mood.length * 78.233) * 43758.5453;
      const rnd = r - Math.floor(r);
      if (rnd < 0.45) this.pluck(m.scale[Math.floor(rnd * 1000) % m.scale.length], this.nextTime);
      if (this.step % 16 === 8 && rnd < 0.7) this.pluck(chord[0] + 24, this.nextTime + m.beat / 2, 0.06);
      this.nextTime += m.beat;
      this.step++;
    }
  }

  pad(notes, t, dur) {
    const ctx = this.ctx;
    for (const n of notes) {
      for (const [type, det, vol] of [['triangle', -4, 0.05], ['sine', 5, 0.045]]) {
        const o = ctx.createOscillator();
        o.type = type;
        o.frequency.value = NOTE(n);
        o.detune.value = det;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(vol, t + 2);
        g.gain.setValueAtTime(vol, t + dur - 1.5);
        g.gain.linearRampToValueAtTime(0, t + dur + 1);
        o.connect(g).connect(this.musicBus);
        o.start(t); o.stop(t + dur + 1.1);
      }
    }
  }

  pluck(n, t, vol = 0.09) {
    const ctx = this.ctx;
    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.value = NOTE(n);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 1.6);
    o.connect(g);
    g.connect(this.musicBus);
    g.connect(this.delay);
    o.start(t); o.stop(t + 1.7);
  }
}
