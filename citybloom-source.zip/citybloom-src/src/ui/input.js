// 滑鼠、觸控、鍵盤輸入
//   滑鼠：左鍵用工具（查看工具則是拖曳平移），右鍵 / 中鍵拖曳平移，滾輪縮放
//   觸控：一指用工具（查看工具則平移），兩指平移 + 開合縮放
//   鍵盤：見說明對話框

const DRAG_THRESHOLD = 6; // px，超過才算拖曳（避免點擊時手抖）

export function attachInput(canvas, game) {
  const pointers = new Map(); // id → { x, y, type }
  let mode = null;            // 'pan' | 'tool' | 'pinch' | 'pending'
  let downPos = null;
  let lastPan = null;
  let velocity = { x: 0, y: 0, t: 0 };
  let pinch = null;
  let wheelAcc = 0;
  let pendingTouch = null;    // 觸控時先等一下，確認不是兩指手勢才開始用工具

  const pos = (e) => {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  function startPan(p) {
    mode = 'pan';
    lastPan = { ...p, t: performance.now() };
    velocity = { x: 0, y: 0, t: lastPan.t };
    game.camera.vx = game.camera.vy = 0;
    canvas.classList.add('panning');
  }

  function movePan(p) {
    const now = performance.now();
    const dx = p.x - lastPan.x, dy = p.y - lastPan.y;
    game.camera.panBy(dx, dy);
    const dt = Math.max(1, now - lastPan.t);
    const z = game.camera.zoom;
    // 平滑後的速度（世界單位 / 毫秒），放開時用來慣性滑行
    velocity.x = velocity.x * 0.6 + (dx / z / dt) * 0.4;
    velocity.y = velocity.y * 0.6 + (dy / z / dt) * 0.4;
    velocity.t = now;
    lastPan = { ...p, t: now };
    game.requestDraw();
  }

  function endPan() {
    canvas.classList.remove('panning');
    if (performance.now() - velocity.t < 80) {
      game.camera.vx = velocity.x;
      game.camera.vy = velocity.y;
    }
    mode = null;
  }

  canvas.addEventListener('contextmenu', (e) => e.preventDefault());

  canvas.addEventListener('pointerdown', (e) => {
    if (game.modalOpen) return;
    canvas.setPointerCapture(e.pointerId);
    const p = pos(e);
    pointers.set(e.pointerId, { ...p, type: e.pointerType });
    game.selected = null;

    if (pointers.size === 2) {
      // 兩指：取消尚未開始的工具動作，進入平移縮放
      pendingTouch = null;
      if (mode === 'tool') game.endStroke();
      const [a, b] = [...pointers.values()];
      pinch = { dist: Math.hypot(a.x - b.x, a.y - b.y), mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 } };
      mode = 'pinch';
      return;
    }
    if (pointers.size > 2) return;

    downPos = p;
    const isTouch = e.pointerType === 'touch';
    if (e.button === 1 || e.button === 2 || game.spaceHeld) { startPan(p); return; }
    if (game.tool === 'inspect') { mode = 'pending'; return; }
    if (isTouch) { mode = 'pending'; pendingTouch = p; return; }
    game.mouse = p;
    mode = 'tool';
    game.beginStroke(p.x, p.y);
  });

  canvas.addEventListener('pointermove', (e) => {
    const p = pos(e);
    if (pointers.has(e.pointerId)) pointers.set(e.pointerId, { ...p, type: e.pointerType });
    game.mouse = p;
    game.positionTip();

    if (mode === 'pinch' && pointers.size >= 2) {
      const [a, b] = [...pointers.values()];
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      game.camera.panBy(mid.x - pinch.mid.x, mid.y - pinch.mid.y);
      // 三段縮放：開合超過一定比例才換一段
      const ratio = dist / pinch.dist;
      if (ratio > 1.45 && game.camera.zoomStep(1, mid.x, mid.y)) pinch.dist = dist;
      else if (ratio < 0.69 && game.camera.zoomStep(-1, mid.x, mid.y)) pinch.dist = dist;
      pinch.mid = mid;
      game.afterView();
      return;
    }

    if (mode === 'pending' && downPos) {
      if (Math.hypot(p.x - downPos.x, p.y - downPos.y) > DRAG_THRESHOLD) {
        if (game.tool === 'inspect') { startPan(downPos); movePan(p); }
        else if (pendingTouch) { mode = 'tool'; game.beginStroke(pendingTouch.x, pendingTouch.y); game.continueStroke(p.x, p.y); pendingTouch = null; }
      }
      return;
    }
    if (mode === 'pan') { movePan(p); return; }
    if (mode === 'tool') { game.continueStroke(p.x, p.y); return; }

    if (e.pointerType === 'mouse') game.setHover(p.x, p.y);
  });

  function finish(e) {
    const p = pos(e);
    const wasMode = mode;
    pointers.delete(e.pointerId);
    if (wasMode === 'pinch') {
      if (pointers.size === 0) mode = null;
      return; // 剩一指時不要突然變成工具或平移
    }
    if (pointers.size > 0) return;
    if (wasMode === 'pan') endPan();
    else if (wasMode === 'tool') game.endStroke();
    else if (wasMode === 'pending') {
      if (game.tool === 'inspect') game.select(p.x, p.y);
      else if (pendingTouch) { game.beginStroke(pendingTouch.x, pendingTouch.y); game.endStroke(); }
    }
    pendingTouch = null;
    mode = null;
    downPos = null;
    if (e.pointerType === 'mouse') game.setHover(p.x, p.y);
  }
  canvas.addEventListener('pointerup', finish);
  canvas.addEventListener('pointercancel', finish);
  canvas.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse' && !mode) game.clearHover(); });

  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    if (game.modalOpen) return;
    const p = pos(e);
    // 觸控板會送出很多小的捲動量，累積到一定程度才換一段縮放
    wheelAcc += e.deltaMode === 1 ? e.deltaY * 40 : e.deltaY;
    if (Math.abs(wheelAcc) >= 60) {
      game.camera.zoomStep(wheelAcc < 0 ? 1 : -1, p.x, p.y);
      wheelAcc = 0;
      game.afterView();
      game.setHover(p.x, p.y);
    }
  }, { passive: false });

  // ---- 鍵盤 ----
  const held = new Set();
  window.addEventListener('keydown', (e) => {
    if (game.modalOpen || e.target.closest?.('input, textarea')) return;
    const k = e.key.toLowerCase();
    if (k === ' ') { game.spaceHeld = true; e.preventDefault(); return; }
    if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) {
      held.add(k); e.preventDefault(); game.requestDraw(); return;
    }
    if (e.repeat) return;
    if (k === 'q') game.rotate(-1);
    else if (k === 'e') game.rotate(1);
    else if (k === '+' || k === '=') game.zoom(1);
    else if (k === '-' || k === '_') game.zoom(-1);
    else if (k === 'g') game.toggleGrid();
    else if (k === 'f') game.toggleFps();
    else if (k === '[') game.setBrush(Math.max(0, game.brush - 1));
    else if (k === ']') game.setBrush(Math.min(2, game.brush + 1));
    else if (k === 'escape') { game.selected = null; game.setTool('inspect'); game.toolbar.closeFly(); }
    else if (k === 'p') game.togglePause();
    else if (k === 'l') game.toggleOverlay('power');
    else if (/^[0-9zx]$/.test(k)) game.setToolByKey(k);
  });
  window.addEventListener('keyup', (e) => {
    const k = e.key.toLowerCase();
    if (k === ' ') game.spaceHeld = false;
    held.delete(k);
  });
  window.addEventListener('blur', () => { held.clear(); game.spaceHeld = false; });

  // 每幀由主迴圈呼叫：處理按住方向鍵的平移
  return {
    update(dt) {
      if (!held.size) return false;
      const sp = 0.7 * dt; // CSS px / ms
      let dx = 0, dy = 0;
      if (held.has('a') || held.has('arrowleft')) dx += sp;
      if (held.has('d') || held.has('arrowright')) dx -= sp;
      if (held.has('w') || held.has('arrowup')) dy += sp;
      if (held.has('s') || held.has('arrowdown')) dy -= sp;
      if (dx || dy) { game.camera.panBy(dx, dy); return true; }
      return false;
    },
  };
}
