// 左側工具列：九個按鈕，分區、電力、地形三組有彈出選單

import { ICONS } from './icons.js';
import { PLANTS, PLANT_TYPES, plantCost } from '../data/energy.js';
import { COSTS } from '../data/buildings/infra.js';
import { ZONE } from '../core/constants.js';
import { TRANSIT } from '../data/transport.js';
import { GREEN } from '../data/climate.js';

const wan = (k) => `${Math.round(k / 10).toLocaleString('zh-TW')} 萬`;

// 每個工具：id、名稱、拖曳方式（click 單點 / path 沿路徑 / rect 拉矩形 / brush 筆刷）、說明
export const TOOLS = {
  inspect: { name: '查看', mode: 'click', hint: '拖曳移動地圖，點一下格子看詳細資料。' },
  bulldoze: { name: '拆除', mode: 'path', hint: '拖曳經過的道路、電線、分區、建築都會<b>拆掉</b>。點電廠任何一格會拆掉整座。', cost: () => `每格 ${wan(COSTS.bulldoze)}` },
  road: { name: '道路', sub: '分區要在 3 格內', mode: 'path', hint: '拖曳畫出<b>道路</b>。分區要在道路 3 格內才會長出建築。<b>道路不會導電。</b>', cost: () => `每格 ${wan(COSTS.road)}` },
  bikelane: { name: '自行車道', sub: '畫在既有道路上', mode: 'path', hint: '在<b>道路上</b>拖曳畫自行車道。住在附近、通勤 2.5 公里內的人會改騎腳踏車。', cost: () => `每格 ${wan(TRANSIT.bikeLane.cost)}` },
  busStop: { name: '公車站', sub: '服務半徑 600 公尺', mode: 'click', hint: '點道路旁的空地設<b>公車站</b>。附近 600 公尺內的居民會改搭公車，路上的車變少。', cost: () => wan(TRANSIT.busStop.cost) },
  powerline: { name: '電線', mode: 'path', hint: '拖曳拉<b>電線</b>，把電廠和分區接起來。分區本身會互相傳電，電線可以架在道路上。', cost: () => `每格 ${wan(COSTS.powerline)}` },
  zoneR1: { sub: '透天厝，每格最多 90 人', name: '輕度住宅', mode: 'rect', zone: ZONE.R1, hint: '拉出矩形劃設<b>輕度住宅區</b>：透天厝，人口少、環境安靜。', cost: () => `每格 ${wan(COSTS.zone)}` },
  zoneR2: { sub: '公寓大樓，每格最多 450 人', name: '高密度住宅', mode: 'rect', zone: ZONE.R2, hint: '拉出矩形劃設<b>高密度住宅區</b>：公寓大樓，可以住很多人。', cost: () => `每格 ${wan(COSTS.zone)}` },
  zoneC1: { sub: '店面，每格最多 45 個工作', name: '輕度商業', mode: 'rect', zone: ZONE.C1, hint: '拉出矩形劃設<b>輕度商業區</b>：店面、小吃。', cost: () => `每格 ${wan(COSTS.zone)}` },
  zoneC2: { sub: '辦公大樓，每格最多 320 個工作', name: '高密度商業', mode: 'rect', zone: ZONE.C2, hint: '拉出矩形劃設<b>高密度商業區</b>：百貨公司、辦公大樓。', cost: () => `每格 ${wan(COSTS.zone)}` },
  zoneI1: { sub: '倉庫、小工廠', name: '輕度工業', mode: 'rect', zone: ZONE.I1, hint: '拉出矩形劃設<b>輕度工業區</b>：倉庫、小工廠。', cost: () => `每格 ${wan(COSTS.zone)}` },
  zoneI2: { sub: '大型工廠，用電最多', name: '高密度工業', mode: 'rect', zone: ZONE.I2, hint: '拉出矩形劃設<b>高密度工業區</b>：大型工廠，工作多，用電也多。', cost: () => `每格 ${wan(COSTS.zone)}` },
  park: { name: '小公園', sub: '1×1・周圍 300 公尺降溫', mode: 'click', park: 'park', hint: '在空地蓋<b>小公園</b>：周圍變涼、地價上升、吸附空氣污染。', cost: () => wan(GREEN.park.cost), wiki: 'heatIsland' },
  bigPark: { name: '公園', sub: '2×2・有小水池', mode: 'click', park: 'bigPark', hint: '在空地蓋<b>公園</b>（2×2）：降溫效果比小公園大。', cost: () => wan(GREEN.bigPark.cost), wiki: 'heatIsland' },
  streetTrees: { name: '行道樹', sub: '種在道路上', mode: 'path', cover: 'streetTrees', hint: '在<b>道路上</b>拖曳種行道樹：樹蔭讓路面變涼。', cost: () => `每格 ${wan(GREEN.streetTrees.cost)}` },
  greenRoof: { name: '綠屋頂', sub: '拉矩形選建築', mode: 'rect', cover: 'greenRoof', hint: '拉出矩形，替範圍內的建築加<b>綠屋頂</b>：隔熱降溫。', cost: () => `每棟 ${wan(GREEN.greenRoof.cost)}` },
  coolRoof: { name: '冷屋頂', sub: '拉矩形選建築', mode: 'rect', cover: 'coolRoof', hint: '拉出矩形，替範圍內的建築漆上反光的<b>冷屋頂</b>：便宜，效果比綠屋頂小一點。', cost: () => `每棟 ${wan(GREEN.coolRoof.cost)}` },
  raise: { sub: '一次 2 公尺', name: '升高', mode: 'brush', hint: '點或拖曳，把地面<b>升高一層</b>（2 公尺）。在水上使用會填出陸地。' },
  lower: { name: '降低', mode: 'brush', hint: '點或拖曳，把地面<b>降低一層</b>。低於海平面就會變成水。' },
  level: { sub: '電廠要蓋在平地', name: '整平', mode: 'brush', hint: '先點的格子決定高度，拖曳經過的地方都會<b>整平成同一層</b>。電廠要蓋在平地上。' },
  trees: { name: '種樹', mode: 'brush', hint: '在草地上<b>種樹</b>。樹林之後會吸收碳、讓周圍變涼。' },
  clearTrees: { name: '砍樹', mode: 'brush', hint: '把樹林<b>變回草地</b>。' },
  water: { sub: '變成池塘', name: '挖水', mode: 'brush', hint: '把陸地<b>挖成池塘</b>，水面會比原本的地面低一層。' },
};
for (const t of PLANT_TYPES) {
  const p = PLANTS[t];
  TOOLS['plant_' + t] = {
    name: p.name, mode: 'click', plant: t,
    hint: `${p.desc}<br><b>${p.mw} MW</b> · 占地 ${p.footprint[0]}×${p.footprint[1]}${p.kind === 'storage' ? ` · 可存 ${p.mwh} MWh` : ` · 碳排放 ${p.co2} g/度`}`,
    cost: (year) => wan(plantCost(t, year)),
  };
}

export const GROUPS = [
  { id: 'inspect', icon: 'inspect', label: '查看', key: '1', tools: ['inspect'] },
  { id: 'bulldoze', icon: 'bulldoze', label: '拆除', key: '2', tools: ['bulldoze'] },
  { id: 'road', icon: 'road', label: '交通', key: '3', tools: ['road', 'bikelane', 'busStop'] },
  { id: 'powerline', icon: 'powerline', label: '電線', key: '4', tools: ['powerline'] },
  { id: 'res', icon: 'res', label: '住宅', key: '5', tools: ['zoneR1', 'zoneR2'], color: 'r' },
  { id: 'com', icon: 'com', label: '商業', key: '6', tools: ['zoneC1', 'zoneC2'], color: 'c' },
  { id: 'ind', icon: 'ind', label: '工業', key: '7', tools: ['zoneI1', 'zoneI2'], color: 'i' },
  { id: 'power', icon: 'plant', label: '電廠', key: '8', tools: PLANT_TYPES.map((t) => 'plant_' + t) },
  { id: 'terrain', icon: 'raise', label: '地形', key: '9', tools: ['raise', 'lower', 'level', 'trees', 'clearTrees', 'water'] },
  { id: 'green', icon: 'leaf', label: '降溫', key: '0', tools: ['park', 'bigPark', 'streetTrees', 'greenRoof', 'coolRoof'], color: 'g' },
];

export function groupOf(toolId) { return GROUPS.find((g) => g.tools.includes(toolId)); }

export function createToolbar(root, game) {
  const el = document.createElement('nav');
  el.className = 'toolbar';
  el.setAttribute('aria-label', '工具');
  el.innerHTML = GROUPS.map((g) => `
      <button class="tool${g.color ? ' zc-' + g.color : ''}" type="button" data-group="${g.id}" title="${g.label}（${g.key}）" aria-label="${g.label}">
        ${ICONS[g.icon]}<span>${g.label}</span><kbd>${g.key}</kbd>${g.tools.length > 1 ? '<i class="more" aria-hidden="true"></i>' : ''}
      </button>`).join('') + `
    <div class="sep"></div>
    <div class="group-label">筆刷</div>
    <div class="brushes">
      ${[0, 1, 2].map((r) => `<button class="brush" type="button" data-brush="${r}" title="${2 * r + 1}×${2 * r + 1} 格">${2 * r + 1}</button>`).join('')}
    </div>`;
  root.appendChild(el);

  const fly = document.createElement('div');
  fly.className = 'flyout';
  fly.hidden = true;
  root.appendChild(fly);

  const lastInGroup = Object.fromEntries(GROUPS.map((g) => [g.id, g.tools[0]]));

  function openFly(g, btn) {
    const year = game.world?.city.year ?? 2025;
    fly.innerHTML = `<div class="fly-title">${g.label}</div>` + g.tools.map((id) => {
      const t = TOOLS[id];
      const sub = t.plant ? (PLANTS[t.plant].kind === 'storage' ? `${PLANTS[t.plant].mw} MW · 可存 ${PLANTS[t.plant].mwh} MWh` : `${PLANTS[t.plant].mw} MW · ${PLANTS[t.plant].co2} g CO₂/度`) : t.sub ?? '';
      return `<button type="button" class="fly-item${id === game.tool ? ' active' : ''}" data-tool="${id}">
        ${t.plant ? `<span class="swatch src-${t.plant}"></span>` : t.zone ? `<span class="swatch zc-${g.color}${id.endsWith('2') ? ' dense' : ''}"></span>` : ''}
        <span class="fly-name">${t.name}<small>${sub}</small></span>
        <span class="fly-cost">${t.cost ? t.cost(year) : ''}</span>
      </button>`;
    }).join('');
    const r = btn.getBoundingClientRect();
    fly.hidden = false;
    fly.style.top = Math.min(r.top, window.innerHeight - fly.offsetHeight - 12) + 'px';
    fly.style.left = r.right + 8 + 'px';
    fly.dataset.group = g.id;
  }
  function closeFly() { fly.hidden = true; }

  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-group]');
    if (b) {
      const g = GROUPS.find((x) => x.id === b.dataset.group);
      if (g.tools.length === 1) { closeFly(); game.setTool(g.tools[0]); return; }
      if (!fly.hidden && fly.dataset.group === g.id) { closeFly(); return; }
      game.setTool(lastInGroup[g.id]);
      openFly(g, b);
      return;
    }
    const br = e.target.closest('[data-brush]');
    if (br) game.setBrush(Number(br.dataset.brush));
  });
  fly.addEventListener('click', (e) => {
    const it = e.target.closest('[data-tool]');
    if (!it) return;
    game.setTool(it.dataset.tool);
    closeFly();
  });
  document.addEventListener('pointerdown', (e) => {
    if (!fly.hidden && !fly.contains(e.target) && !el.contains(e.target)) closeFly();
  });

  function sync() {
    const g = groupOf(game.tool);
    if (g) lastInGroup[g.id] = game.tool;
    el.querySelectorAll('[data-group]').forEach((b) => b.classList.toggle('active', b.dataset.group === g?.id));
    el.querySelectorAll('[data-brush]').forEach((b) => b.classList.toggle('active', Number(b.dataset.brush) === game.brush));
    el.querySelector('.brushes').classList.toggle('off', TOOLS[game.tool]?.mode !== 'brush' && TOOLS[game.tool]?.mode !== 'path');
  }
  game.bus.on('tool', sync);
  game.bus.on('brush', sync);
  sync();

  return {
    selectGroupByKey(k) {
      const g = GROUPS.find((x) => x.key === k);
      if (!g) return;
      const cur = groupOf(game.tool);
      // 同一組再按一次：換到組內下一個工具
      if (cur === g && g.tools.length > 1) {
        const i = g.tools.indexOf(game.tool);
        game.setTool(g.tools[(i + 1) % g.tools.length]);
      } else game.setTool(lastInGroup[g.id]);
    },
    closeFly,
  };
}
