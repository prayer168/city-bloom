// 電力面板：本月用電與發電、一天四時段的供需、發電組成、碳排放

import { PLANTS, SLOT_NAMES, SLOT_HOURS, RENEWABLE } from '../../data/energy.js';
import { fmtDu } from '../hud.js';
import { wk } from '../wiki.js';

const ORDER = ['solar', 'wind', 'hydro', 'gas', 'nuclear', 'battery', 'coal'];
const NAME = { ...Object.fromEntries(Object.entries(PLANTS).map(([k, v]) => [k, v.name.replace(/電廠|發電場|光電場/, '')])), battery: '儲能放電', solar: '太陽能', wind: '風力' };

export function createPowerPanel(root, game) {
  const el = document.createElement('aside');
  el.className = 'side-panel power-panel';
  el.hidden = true;
  el.setAttribute('aria-label', '電力');
  root.appendChild(el);

  function render() {
    if (el.hidden || !game.world) return;
    const c = game.world.city;
    const p = c.power;
    const head = `<header><h3>本月電力 <small>${monthBefore(c)}</small></h3><button type="button" class="x" data-act="close" aria-label="關閉">×</button></header>`;
    if (!p) { el.innerHTML = head + '<p class="muted">時間開始走之後，這裡會顯示每個月的電力。</p>'; return; }
    const shortPct = p.demandMWh > 0 ? p.unservedMWh / p.demandMWh : 0;
    const max = Math.max(1, ...p.slots.map((s) => Math.max(s.demand, sum(s.supply) + s.curtailed + s.charge)));

    const slotRows = p.slots.map((s, k) => {
      const segs = ORDER.filter((src) => s.supply[src] > 0)
        .map((src) => `<i class="seg src-${src}" style="width:${(s.supply[src] / max) * 100}%" title="${NAME[src]} ${fmtDu(s.supply[src])}"></i>`).join('');
      const extra = s.charge > 0 ? `<i class="seg charge" style="width:${(s.charge / max) * 100}%" title="充進電池 ${fmtDu(s.charge)}"></i>` : '';
      const cur = s.curtailed > 0 ? `<i class="seg curtail" style="width:${(s.curtailed / max) * 100}%" title="用不完（棄電）${fmtDu(s.curtailed)}"></i>` : '';
      const uns = s.unserved > 0 ? `<i class="seg unserved" style="width:${(s.unserved / max) * 100}%" title="缺電 ${fmtDu(s.unserved)}"></i>` : '';
      return `<div class="slot-row">
        <span class="slot-lbl">${SLOT_NAMES[k]}<small>${SLOT_HOURS[k]}</small></span>
        <div class="slot-bar">${segs}${uns}${extra}${cur}<b class="demand-mark" style="left:${(s.demand / max) * 100}%" title="需要 ${fmtDu(s.demand)}"></b></div>
      </div>`;
    }).join('');

    const gen = p.generationMWh || 0;
    const mix = ORDER.filter((src) => src !== 'battery' && (p.genBySource[src] || 0) > 0).map((src) => {
      const v = p.genBySource[src];
      return `<li><span class="swatch src-${src}"></span><span>${NAME[src]}${RENEWABLE.has(src) ? '<em>綠電</em>' : ''}</span><b>${fmtDu(v)}</b><span class="pct">${Math.round((v / gen) * 100)}%</span></li>`;
    }).join('');

    el.innerHTML = head + `
      <div class="kpis">
        <div><span>用電（${wk('kwh', '度')}）</span><b>${fmtDu(p.demandMWh)}</b></div>
        <div class="${shortPct > 0.001 ? 'bad' : 'good'}"><span>${wk('rollingBlackout', '缺電')}</span><b>${shortPct > 0.001 ? Math.round(shortPct * 100) + '%' : '沒有'}</b></div>
        <div><span>${wk('renewable', '綠電比例')}</span><b>${gen > 0 ? Math.round(p.renewableShare * 100) + '%' : '—'}</b></div>
        <div><span>碳排放</span><b>${Math.round(p.co2t).toLocaleString('zh-TW')} 公噸</b></div>
      </div>
      <h4>一天四個時段：供電夠不夠？</h4>
      <div class="slots">${slotRows}</div>
      <div class="legend-row"><span><b class="demand-mark static"></b>需要的電</span><span><i class="lg unserved"></i>缺電</span><span><i class="lg charge"></i>${wk('storage', '充電池')}</span><span><i class="lg curtail"></i>${wk('curtail', '用不完')}</span></div>
      <h4>這個月的電從哪裡來</h4>
      ${mix ? `<ul class="mix">${mix}</ul>` : '<p class="muted">還沒有發電。</p>'}
      ${p.storageMWh > 0 ? `<p class="note">儲能電池：${fmtDu(p.storageSoc)}／${fmtDu(p.storageMWh)}</p>` : ''}
      ${advice(p)}`;
  }

  el.addEventListener('click', (e) => { if (e.target.closest('[data-act="close"]')) toggle(false); });
  game.bus.on('tick', render);
  game.bus.on('world', render);

  function toggle(force) {
    el.hidden = force === undefined ? !el.hidden : !force;
    if (!el.hidden) game.climatePanel?.toggle(false);
    render();
  }
  return { toggle, render };
}

const sum = (o) => Object.values(o).reduce((a, b) => a + b, 0);

function monthBefore(c) {
  let y = c.year, m = c.month - 1;
  if (m < 1) { m = 12; y--; }
  return `${y} 年 ${m} 月`;
}

// 依本月狀況給一句提示（給學生思考的方向，不直接給答案）
function advice(p) {
  const tips = [];
  if (p.gridsWithoutPlant > 0) tips.push(`有 ${p.gridsWithoutPlant} 個區域沒有接上電廠。用電線把它們接起來。`);
  const night = p.slots[0].unserved + p.slots[3].unserved;
  const day = p.slots[1].unserved + p.slots[2].unserved;
  const solar = p.genBySource.solar || 0;
  if (night > 0 && day <= night * 0.2 && solar > 0) tips.push('白天夠用、晚上缺電：太陽能晚上不會發電。有什麼方法能把白天的電留到晚上？');
  else if (p.unservedMWh > 0) tips.push('電不夠用，離電廠最遠的地方會先停電。');
  if (p.curtailedMWh > p.generationMWh * 0.15) tips.push('有不少電用不完被浪費了，可以考慮加蓋儲能電池。');
  if (!tips.length) return '';
  return `<div class="tips">${tips.map((t) => `<p>${t}</p>`).join('')}</div>`;
}
