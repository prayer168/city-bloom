// 災情報告卡：極端天氣結算後彈出（不暫停遊戲）
// 內容：災情數字、受影響範圍小地圖、「有設施 vs 沒有設施」比較、發揮作用的設施、還可以改進的地方

import { ICONS } from '../icons.js';
import { wk } from '../wiki.js';
import { SURFACE } from '../../core/constants.js';

const TYPE_ICON = { typhoon: 'storm', heavyRain: 'rain', heatwave: 'sun', drought: 'drop', sea: 'water' };
const HELP_WIKI = {
  detentionPond: 'detentionPond', pumpStation: 'pumpStation', levee: 'levee', seawall: 'seawall', undergroundGrid: 'undergroundGrid',
  roofSolar: 'roofSolar', shelter: 'shelter', warningCenter: 'earlyWarning', sponge: 'spongeCity', heatIsland: 'heatIsland',
  coolingCenter: 'coolingCenter', recycledWater: 'recycledWater', desalination: 'desalination', rainHarvest: 'rainHarvest', water: 'drought',
};
const wan = (k) => `${Math.round((k || 0) / 10).toLocaleString('zh-TW')} 萬`;

export function createReportCard(root, game) {
  const el = document.createElement('aside');
  el.className = 'report-card';
  el.hidden = true;
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-label', '災情報告');
  root.appendChild(el);
  let currentId = null;

  function show(id) {
    const reps = game.world?.city.reports || [];
    const rep = reps.find((r) => r.id === id) || reps[reps.length - 1];
    if (!rep) return;
    currentId = rep.id;
    const newer = reps.filter((r) => r.id > rep.id).length;
    const cmp = rep.compare;
    let compareHtml = '';
    if (cmp && cmp.withoutTiles != null && (cmp.withoutTiles > 0 || cmp.withTiles > 0)) {
      compareHtml = bars('市區淹水（公頃）', cmp.withTiles, cmp.withoutTiles, cmp.savedLossK > 0 ? `調適設施少了約 ${wan(cmp.savedLossK)} 的損失` : '');
    } else if (cmp && cmp.withoutPeople != null && (cmp.withoutPeople > 0 || cmp.withPeople > 0)) {
      compareHtml = bars('36 °C 以上的居民（人）', cmp.withPeople, cmp.withoutPeople, '');
    }
    const flood = rep.type === 'typhoon' || rep.type === 'heavyRain' || rep.type === 'sea';
    el.className = `report-card sev-${rep.severity || 1} t-${rep.type}`;
    el.innerHTML = `
      <header>
        <span class="rc-icon">${ICONS[TYPE_ICON[rep.type]] || ICONS.alert}</span>
        <div><span class="rc-tag">災情報告</span><h3>${rep.title}<small>${rep.y} 年 ${rep.m} 月</small></h3></div>
        <button type="button" class="x" data-act="close" aria-label="關閉">×</button>
      </header>
      <div class="rc-body">
        <figure class="rc-map"><canvas aria-label="受影響範圍"></canvas><figcaption>${rep.type === 'heatwave' ? '橘色：36 °C 以上的住宅區' : rep.type === 'sea' ? '深藍：被海水淹沒　淺藍：漲潮會淹' : rep.type === 'drought' ? '全市限水' : '藍色：淹水的地方'}・上方是北</figcaption></figure>
        <dl>${rep.rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>
      </div>
      ${compareHtml}
      ${rep.helped.length ? `<h4>發揮作用的準備</h4><ul class="rc-helped">${rep.helped.map(([k, t]) => `<li>${HELP_WIKI[k] ? wk(HELP_WIKI[k], '✓') : '✓'}<span>${t}</span></li>`).join('')}</ul>` : ''}
      ${rep.warnings.length ? `<h4>可以再改進</h4><ul class="rc-warn">${rep.warnings.map((t) => `<li>${t}</li>`).join('')}</ul>` : ''}
      ${rep.lossK > 0 ? `<p class="rc-loss">本月災害損失約 <b>${wan(rep.lossK)}</b>，市府負擔重建與救助 <b>${wan(rep.cityPaidK)}</b>。</p>` : ''}
      <div class="actions">
        ${newer ? `<button type="button" class="btn" data-act="newer">下一份（還有 ${newer} 份）</button>` : ''}
        ${flood ? '<button type="button" class="btn" data-act="overlay">看淹水潛勢圖層</button>' : ''}
        <button type="button" class="btn" data-act="all">所有報告</button>
        <button type="button" class="btn primary" data-act="close">知道了</button>
      </div>`;
    el.hidden = false;
    drawMap(el.querySelector('canvas'), game.world, rep);
  }

  el.addEventListener('click', (e) => {
    const a = e.target.closest('[data-act]')?.dataset.act;
    if (a === 'close') el.hidden = true;
    if (a === 'overlay') { game.setOverlay('flood'); el.hidden = true; }
    if (a === 'all') { el.hidden = true; game.hazardPanel.toggle(true); }
    if (a === 'newer') {
      const reps = game.world.city.reports;
      const nx = reps.find((r) => r.id > currentId);
      if (nx) show(nx.id);
    }
  });
  el.addEventListener('keydown', (e) => { if (e.key === 'Escape') el.hidden = true; e.stopPropagation(); });
  return { show, hide: () => { el.hidden = true; } };
}

function bars(label, withV, withoutV, note) {
  const max = Math.max(1, withV, withoutV);
  return `<div class="rc-compare">
    <div class="rc-cl">${label}</div>
    <div class="rc-row"><span>現在的城市</span><i style="width:${(withV / max) * 100}%" class="with"></i><b>${withV.toLocaleString('zh-TW')}</b></div>
    <div class="rc-row"><span>如果沒有調適設施</span><i style="width:${(withoutV / max) * 100}%" class="without"></i><b>${withoutV.toLocaleString('zh-TW')}</b></div>
    ${note ? `<div class="rc-note">${note}</div>` : ''}
  </div>`;
}

// 受影響範圍小地圖（北方朝上）
function drawMap(canvas, world, rep) {
  const n = world.size;
  canvas.width = n; canvas.height = n;
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(n, n);
  const L = world.layers;
  const mark = new Uint8Array(n * n);
  for (const i of rep.floodTiles || []) mark[i] = 1;
  for (const i of rep.heatTiles || []) mark[i] = 2;
  for (const i of rep.seaTiles || []) mark[i] = 3;
  for (let i = 0; i < n * n; i++) {
    let c;
    if (mark[i] === 1) c = [70, 150, 240];
    else if (mark[i] === 2) c = [245, 140, 50];
    else if (mark[i] === 3) c = (L.state[i] & 16) ? [30, 60, 140] : [110, 175, 240];
    else if (L.surface[i] === SURFACE.WATER) c = [28, 52, 84];
    else if (L.zone[i] && L.devLevel[i]) c = [170, 172, 178];
    else if (L.net[i] & 1) c = [120, 122, 128];
    else c = L.surface[i] === SURFACE.FOREST ? [44, 70, 48] : [62, 84, 60];
    if (rep.type === 'drought' && L.zone[i] && L.devLevel[i]) c = [220, 170, 80];
    img.data.set([c[0], c[1], c[2], 255], i * 4);
  }
  ctx.putImageData(img, 0, 0);
}
