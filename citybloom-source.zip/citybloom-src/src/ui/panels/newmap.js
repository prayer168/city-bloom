// 新地圖對話框（含三種地形的俯視縮圖）與操作說明

import { MAP_PRESETS, generateMap } from '../../sim/mapgen.js';
import { DEFAULT_MAP_SIZE, SMALL_MAP_SIZE, SURFACE, SEA_LEVEL_CM } from '../../core/constants.js';
import { GRASS_BY_LEVEL, FOREST_BY_LEVEL, SAND, MUDFLAT, WATER_BY_DEPTH } from '../../render/palette.js';

export function drawPreview(canvas, world) {
  const n = world.size;
  canvas.width = n;
  canvas.height = n;
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(n, n);
  const { surface, elev } = world.layers;
  for (let i = 0; i < n * n; i++) {
    const s = surface[i];
    const lv = world.level(i);
    let hex;
    if (s === SURFACE.WATER) hex = WATER_BY_DEPTH[Math.min(15, Math.max(0, Math.round((SEA_LEVEL_CM - elev[i]) / 100)))][1];
    else if (s === SURFACE.FOREST) hex = FOREST_BY_LEVEL[lv][0];
    else if (s === SURFACE.SAND) hex = SAND[1];
    else if (s === SURFACE.MUDFLAT) hex = MUDFLAT[1];
    else hex = GRASS_BY_LEVEL[lv][1];
    const v = parseInt(hex.slice(1), 16);
    // 依高度加一點陰影，看得出起伏
    const f = 0.82 + Math.min(lv, 15) * 0.018;
    img.data[i * 4] = Math.min(255, ((v >> 16) & 255) * f);
    img.data[i * 4 + 1] = Math.min(255, ((v >> 8) & 255) * f);
    img.data[i * 4 + 2] = Math.min(255, (v & 255) * f);
    img.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
}

export function createNewMapDialog(root, game) {
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.hidden = true;
  back.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="nm-title">
      <h2 id="nm-title">建立新地圖</h2>
      <p class="sub">選一種地形。同一個地圖編號一定會產生同一張地圖，全班可以用同一個編號一起比較。</p>
      <div>
        <div class="field-label">地形</div>
        <div class="presets">
          ${MAP_PRESETS.map((p) => `
            <button type="button" class="preset" data-preset="${p.id}">
              <canvas aria-hidden="true"></canvas>
              <div><b>${p.name}</b><br><span>${p.desc}</span></div>
            </button>`).join('')}
        </div>
      </div>
      <div class="row">
        <div>
          <label class="field-label" for="nm-seed">地圖編號</label>
          <div style="display:flex;gap:6px">
            <input id="nm-seed" class="seed" type="text" inputmode="numeric" maxlength="9" autocomplete="off">
            <button type="button" class="btn" data-act="random">隨機</button>
          </div>
        </div>
        <div>
          <div class="field-label">世界的暖化情境</div>
          <div class="seg" role="radiogroup" aria-label="暖化情境">
            <button type="button" data-sc="low" title="SSP1-2.6：全世界一起大幅減碳">低排放</button>
            <button type="button" data-sc="mid" title="SSP2-4.5：延續目前的政策">中排放</button>
            <button type="button" data-sc="high" title="SSP5-8.5：化石燃料大量增加">高排放</button>
          </div>
        </div>
        <div>
          <div class="field-label">地圖大小</div>
          <div class="seg" role="radiogroup" aria-label="地圖大小">
            <button type="button" data-size="${DEFAULT_MAP_SIZE}">標準 128 × 128</button>
            <button type="button" data-size="${SMALL_MAP_SIZE}">平板 96 × 96</button>
          </div>
        </div>
      </div>
      <div class="actions">
        <button type="button" class="btn" data-act="cancel">取消</button>
        <button type="button" class="btn primary" data-act="create">建立地圖</button>
      </div>
    </div>`;
  root.appendChild(back);

  const seedInput = back.querySelector('#nm-seed');
  let preset = 'river-plain';
  let size = DEFAULT_MAP_SIZE;
  let scenario = 'mid';
  let previewTimer = 0;

  function sync() {
    back.querySelectorAll('[data-preset]').forEach((b) => b.classList.toggle('active', b.dataset.preset === preset));
    back.querySelectorAll('[data-size]').forEach((b) => b.classList.toggle('active', Number(b.dataset.size) === size));
    back.querySelectorAll('[data-sc]').forEach((b) => b.classList.toggle('active', b.dataset.sc === scenario));
  }
  function readSeed() {
    const v = parseInt(seedInput.value.replace(/\D/g, ''), 10);
    return Number.isFinite(v) ? v : 1;
  }
  function refreshPreviews() {
    clearTimeout(previewTimer);
    previewTimer = setTimeout(() => {
      const seed = readSeed();
      back.querySelectorAll('[data-preset]').forEach((b) => {
        const w = generateMap({ size: 128, seed, preset: b.dataset.preset });
        drawPreview(b.querySelector('canvas'), w);
      });
    }, 120);
  }

  back.addEventListener('click', (e) => {
    if (e.target === back) return close();
    const p = e.target.closest('[data-preset]');
    if (p) { preset = p.dataset.preset; sync(); }
    const sc = e.target.closest('[data-sc]');
    if (sc) { scenario = sc.dataset.sc; sync(); }
    const s = e.target.closest('[data-size]');
    if (s) { size = Number(s.dataset.size); sync(); }
    const a = e.target.closest('[data-act]')?.dataset.act;
    if (a === 'cancel') close();
    if (a === 'random') { seedInput.value = String(Math.floor(Math.random() * 99999999) + 1); refreshPreviews(); }
    if (a === 'create') {
      game.newMap({ seed: readSeed(), preset, size, cityOptions: { scenario } });
      close();
    }
  });
  seedInput.addEventListener('input', refreshPreviews);
  back.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
    if (e.key === 'Enter' && e.target === seedInput) back.querySelector('[data-act="create"]').click();
    e.stopPropagation();
  });

  function open() {
    preset = game.mapOptions.preset;
    size = game.mapOptions.size;
    scenario = game.mapOptions.cityOptions?.scenario ?? 'mid';
    seedInput.value = String(game.mapOptions.seed);
    sync();
    refreshPreviews();
    back.hidden = false;
    game.modalOpen = true;
    seedInput.focus();
    seedInput.select();
  }
  function close() {
    back.hidden = true;
    game.modalOpen = false;
  }
  return { open, close };
}

export function createHelpDialog(root, game) {
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.hidden = true;
  back.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="help-title">
      <h2 id="help-title">操作說明</h2>
      <div class="keys">
        <div><b>移動地圖</b>：用「查看」工具拖曳，或按住滑鼠右鍵拖曳；平板用兩指拖曳。也可以用 <kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> 或方向鍵。</div>
        <div><b>縮放</b>：滑鼠滾輪、兩指開合，或 <kbd>+</kbd> <kbd>−</kbd>，共三段。</div>
        <div><b>旋轉</b>：<kbd>Q</kbd> 向左、<kbd>E</kbd> 向右，每次 90 度。右下角指北針會跟著轉。</div>
        <div><b>工具</b>：<kbd>1</kbd>–<kbd>9</kbd>、<kbd>0</kbd>（降溫）、<kbd>Z</kbd>（氣候調適）、<kbd>X</kbd>（AI 與智慧城市）切換工具，<kbd>[</kbd> <kbd>]</kbd> 改筆刷大小，<kbd>G</kbd> 顯示格線，<kbd>F</kbd> 顯示畫面更新速度。</div>
        <div><b>比例尺</b>：一格約 100 公尺見方（1 公頃），畫面上每一層高度是 2 公尺。</div>
      </div>
      <div class="actions"><button type="button" class="btn primary" data-act="close">知道了</button></div>
    </div>`;
  root.appendChild(back);
  const close = () => { back.hidden = true; game.modalOpen = false; };
  back.addEventListener('click', (e) => { if (e.target === back || e.target.closest('[data-act="close"]')) close(); });
  back.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); e.stopPropagation(); });
  return {
    open() { back.hidden = false; game.modalOpen = true; back.querySelector('[data-act="close"]').focus(); },
    close,
  };
}
