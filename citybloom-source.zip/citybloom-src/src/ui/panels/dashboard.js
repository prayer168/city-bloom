// 永續儀表板：碳排放、綠電比例、空氣品質集中在一個畫面
// 圖表用 SVG 直接畫；每張圖都有滑鼠提示，下方可以展開數字表格

import { CARBON_SOURCES, ABSORB, WORLD_PER_CAPITA_T } from '../../data/emissions.js';
import { PLANTS, RENEWABLE } from '../../data/energy.js';
import { AQI_LEVELS } from '../../data/environment.js';
import { fmtDu } from '../hud.js';
import { wk } from '../wiki.js';

const GEN_ORDER = ['solar', 'wind', 'hydro', 'gas', 'nuclear', 'battery', 'coal'];
const GEN_COLOR = { solar: '#c98500', wind: '#199e70', hydro: '#3987e5', gas: '#d95926', nuclear: '#9085e9', battery: '#4a9a2a', coal: '#d55181' };
const GEN_NAME = { solar: '太陽能', wind: '風力', hydro: '水力', gas: '燃氣', nuclear: '核能', battery: '儲能放電', coal: '燃煤' };
const t0 = (v) => Math.round(v).toLocaleString('zh-TW');
const t1 = (v) => (+v).toLocaleString('zh-TW', { maximumFractionDigits: 1, minimumFractionDigits: 1 });
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export function createDashboard(root, game) {
  const back = document.createElement('div');
  back.className = 'modal-back dash-back';
  back.hidden = true;
  back.innerHTML = '<div class="dash" role="dialog" aria-modal="true" aria-labelledby="dash-title"></div><div class="viz-tip" hidden></div>';
  root.appendChild(back);
  const el = back.querySelector('.dash');
  const tip = back.querySelector('.viz-tip');

  function render() {
    if (back.hidden || !game.world) return;
    const c = game.world.city;
    const hist = c.history.monthly;
    const cb = c.carbon;
    const last = hist[hist.length - 1];
    if (!cb || !last) {
      el.innerHTML = head(c) + '<p class="muted">時間開始走之後，這裡會顯示城市的碳排放、綠電比例與空氣品質。</p>';
      return;
    }
    const year = hist.slice(-12);
    const genYear = {};
    for (const h of year) for (const [k, v] of Object.entries(h.gen || {})) genYear[k] = (genYear[k] || 0) + v;
    const genTotal = Object.entries(genYear).filter(([k]) => k !== 'battery').reduce((a, [, v]) => a + v, 0);
    const renewYear = Object.entries(genYear).filter(([k]) => RENEWABLE.has(k)).reduce((a, [, v]) => a + v, 0);
    const aqi = last.aqiPop || [0, 0, 0, 0];
    const aqiTotal = aqi.reduce((a, b) => a + b, 0);

    el.innerHTML = head(c) + `
      <div class="dash-kpis">
        ${kpi('本月碳排放', `${t0(cb.net)}<small> 公噸</small>`, `${wk('co2', '碳排放')}・扣掉樹林吸收後`)}
        ${kpi('人均碳排放', `${c.population ? t1(cb.perCapita) : '—'}<small> 公噸／人／年</small>`, perCapitaBar(cb.perCapita, c.population))}
        ${kpi('綠電比例（近一年）', `${genTotal ? Math.round((renewYear / genTotal) * 100) : 0}<small>%</small>`, wk('renewable', '什麼是綠電？'))}
        ${kpi('空氣良好的居民', `${aqiTotal ? Math.round((aqi[0] / aqiTotal) * 100) : 0}<small>%</small>`, wk('aqi', '空氣品質怎麼看？'))}
      </div>
      <div class="dash-grid">
        <section class="card">
          <h3>碳從哪裡來 <small>本月</small></h3>
          ${sourceBars(cb)}
          ${advice(cb, c)}
        </section>
        <section class="card wide">
          <h3>每月碳排放 <small>最近 ${Math.min(24, hist.length)} 個月</small></h3>
          ${legend(CARBON_SOURCES)}
          <div class="chart" data-chart="stack">${stackChart(hist.slice(-24))}</div>
          ${tableDetails(hist.slice(-12))}
        </section>
        <section class="card">
          <h3>綠電比例變化 <small>每月</small></h3>
          <div class="chart" data-chart="line">${lineChart(hist.slice(-36))}</div>
        </section>
        <section class="card">
          <h3>發電組成 <small>近 12 個月</small></h3>
          ${genTotal ? mixBar(genYear, genTotal) : '<p class="muted">還沒有發電。</p>'}
        </section>
        <section class="card">
          <h3>居民呼吸的空氣 <small>本月</small></h3>
          ${aqiTotal ? airBar(aqi, aqiTotal) : '<p class="muted">還沒有居民。</p>'}
          <p class="note">本月風向：${c.air?.wind ?? '—'}（${wk('monsoon', '季風')}）</p>
        </section>
      </div>`;
    bindHover();
  }

  function head(c) {
    return `<header class="dash-head"><h2 id="dash-title">永續儀表板</h2><span class="muted">${c.year} 年 ${c.month} 月・人口 ${t0(c.population)}</span><button type="button" class="x" data-act="close" aria-label="關閉">×</button></header>`;
  }

  // ---- 滑鼠提示 ----
  function bindHover() {
    el.querySelectorAll('[data-tip]').forEach((n) => {
      n.addEventListener('pointerenter', (e) => { tip.innerHTML = n.dataset.tip; tip.hidden = false; move(e); });
      n.addEventListener('pointermove', move);
      n.addEventListener('pointerleave', () => { tip.hidden = true; });
    });
  }
  function move(e) {
    const r = back.getBoundingClientRect();
    const x = Math.min(e.clientX - r.left + 14, r.width - tip.offsetWidth - 8);
    tip.style.transform = `translate(${Math.max(8, x)}px, ${e.clientY - r.top + back.scrollTop + 14}px)`;
  }

  back.addEventListener('click', (e) => {
    if (e.target === back || e.target.closest('[data-act="close"]')) toggle(false);
  });
  back.addEventListener('keydown', (e) => { if (e.key === 'Escape') toggle(false); e.stopPropagation(); });
  game.bus.on('tick', render);

  function toggle(force) {
    back.hidden = force === undefined ? !back.hidden : !force;
    game.modalOpen = !back.hidden;
    if (!back.hidden) { render(); el.querySelector('[data-act="close"]')?.focus(); }
  }
  return { toggle, render };
}

function kpi(label, value, sub) {
  return `<div class="kpi"><span class="kpi-l">${label}</span><b class="kpi-v">${value}</b><span class="kpi-s">${sub}</span></div>`;
}

function perCapitaBar(v, pop) {
  if (!pop) return '與世界平均比較';
  const max = Math.max(v, WORLD_PER_CAPITA_T) * 1.15;
  return `<span class="pc-bar" data-tip="我們的城市 ${t1(v)} 公噸<br>世界平均約 ${WORLD_PER_CAPITA_T} 公噸">
    <i style="width:${(v / max) * 100}%"></i><em style="left:${(WORLD_PER_CAPITA_T / max) * 100}%"></em></span>
    <span class="pc-cap">${v > WORLD_PER_CAPITA_T ? '高於' : '低於'}世界平均（白線）</span>`;
}

function legend(items) {
  return `<div class="viz-legend">${items.map((s) => `<span><i style="background:${s.color}"></i>${s.name}</span>`).join('')}</div>`;
}

function sourceBars(cb) {
  const max = Math.max(1, ...CARBON_SOURCES.map((s) => cb[s.id]), -cb.absorb);
  const rows = CARBON_SOURCES.map((s) => {
    const v = cb[s.id];
    const pct = cb.gross > 0 ? Math.round((v / cb.gross) * 100) : 0;
    return `<div class="src-row" data-tip="${s.name}：${t0(v)} 公噸（${pct}%）">
      <span class="src-l">${s.name}</span>
      <span class="src-track"><i style="width:${(v / max) * 100}%;background:${s.color}"></i></span>
      <span class="src-v">${t0(v)}<small> t</small></span><span class="src-p">${pct}%</span></div>`;
  }).join('');
  const ab = -cb.absorb;
  const abRow = `<div class="src-row" data-tip="${cb.forestTiles} 公頃新種樹林吸收 ${t0(ab)} 公噸">
      <span class="src-l">${ABSORB.name}</span>
      <span class="src-track"><i style="width:${(ab / max) * 100}%;background:${ABSORB.color}"></i></span>
      <span class="src-v">${ab > 0.5 ? '−' : ''}${t0(Math.abs(ab))}<small> t</small></span><span class="src-p"></span></div>`;
  return `<div class="src-bars">${rows}${abRow}</div>`;
}

// 依最大來源給一個思考方向（用問句，不直接給答案）
function advice(cb, c) {
  if (cb.gross <= 0) return '';
  const top = CARBON_SOURCES.reduce((a, s) => (cb[s.id] > cb[a.id] ? s : a), CARBON_SOURCES[0]);
  const q = {
    power: '發電是最大的來源。換成哪些發電方式，碳排放會下降最多？晚上的電要從哪裡來？',
    transport: '交通是最大的來源。怎麼讓更多人不用開車也能上班、上學？',
    buildings: '住宅和商店用瓦斯產生的排放最多。有沒有不用燒瓦斯的方法？',
    industry: '工業是最大的來源。工廠一定要蓋這麼多嗎？城市的錢和工作會受什麼影響？',
    landuse: '這個月砍掉很多樹林，樹裡存的碳跑回空氣中了。可以把建設蓋在已經是草地的地方嗎？',
  }[top.id];
  const forest = -cb.absorb;
  const cmp = forest > 0
    ? `<p>新種樹林吸收的量，是排放量的 ${Math.max(1, Math.round((forest / cb.gross) * 100))}%。</p>`
    : `<p>用「地形 → 種樹」在草地上種樹，${wk('carbonSink', '新種的樹林')}會開始吸收二氧化碳。</p>`;
  return `<div class="tips"><p>${q}</p>${cmp}${c.population ? '' : ''}</div>`;
}

// ---- 每月碳排堆疊長條 ----
function stackChart(rows) {
  const W = 600, H = 210, pl = 46, pr = 8, pt = 10, pb = 26;
  const n = Math.max(1, rows.length);
  const totals = rows.map((r) => CARBON_SOURCES.reduce((a, s) => a + (r.co2?.[s.id] || 0), 0));
  if (Math.max(0, ...totals) < 1) return '<p class="muted">城市開始排放之後，這裡會顯示每個月的變化。</p>';
  const maxV = niceMax(Math.max(10, ...totals));
  const band = (W - pl - pr) / n;
  const bw = Math.min(24, band - 4);
  const y = (v) => pt + (H - pt - pb) * (1 - v / maxV);
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="每月碳排放堆疊長條圖">`;
  for (const g of ticks(maxV)) {
    svg += `<line x1="${pl}" x2="${W - pr}" y1="${y(g)}" y2="${y(g)}" class="grid"/><text x="${pl - 6}" y="${y(g) + 4}" class="ax" text-anchor="end">${shortT(g)}</text>`;
  }
  rows.forEach((r, k) => {
    const x = pl + band * k + (band - bw) / 2;
    let acc = 0;
    const segs = CARBON_SOURCES.map((s) => ({ s, v: r.co2?.[s.id] || 0 })).filter((d) => d.v > 0);
    segs.forEach((d, j) => {
      const y0 = y(acc), y1 = y(acc + d.v);
      const top = j === segs.length - 1;
      const h = Math.max(0, y0 - y1 - (j > 0 ? 2 : 0)); // 2px 間隔
      if (h > 0) svg += top ? roundTop(x, y1, bw, h, d.s.color) : `<rect x="${x}" y="${y1}" width="${bw}" height="${h}" fill="${d.s.color}"/>`;
      acc += d.v;
    });
    if (r.m === 1 || k === 0) svg += `<text x="${x + bw / 2}" y="${H - 8}" class="ax" text-anchor="middle">${r.y}/${r.m}</text>`;
    const tipHtml = `<b>${r.y} 年 ${r.m} 月</b><br>${CARBON_SOURCES.map((s) => `<i style="background:${s.color}"></i>${s.name} ${t0(r.co2?.[s.id] || 0)} t`).join('<br>')}<br>新種樹林吸收 −${t0(-(r.co2?.absorb || 0))} t`;
    svg += `<rect x="${pl + band * k}" y="${pt}" width="${band}" height="${H - pt - pb}" fill="transparent" data-tip="${esc(tipHtml)}"/>`;
  });
  return svg + '</svg>';
}

function roundTop(x, y, w, h, fill) {
  const r = Math.min(4, h, w / 2);
  return `<path d="M${x},${y + h} V${y + r} Q${x},${y} ${x + r},${y} H${x + w - r} Q${x + w},${y} ${x + w},${y + r} V${y + h} Z" fill="${fill}"/>`;
}

// ---- 綠電比例折線 ----
function lineChart(rows) {
  const W = 360, H = 170, pl = 34, pr = 34, pt = 12, pb = 24;
  if (rows.length < 2) return '<p class="muted">至少要兩個月的資料。</p>';
  const xs = (k) => pl + ((W - pl - pr) * k) / (rows.length - 1);
  const y = (v) => pt + (H - pt - pb) * (1 - v);
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="綠電比例折線圖">`;
  for (const g of [0, 0.5, 1]) svg += `<line x1="${pl}" x2="${W - pr}" y1="${y(g)}" y2="${y(g)}" class="grid"/><text x="${pl - 6}" y="${y(g) + 4}" class="ax" text-anchor="end">${g * 100}%</text>`;
  const pts = rows.map((r, k) => [xs(k), y(r.renewableShare || 0)]);
  svg += `<path d="M${pts.map((p) => p.join(',')).join(' L')} L${pts[pts.length - 1][0]},${y(0)} L${pts[0][0]},${y(0)} Z" fill="#199e70" opacity="0.1"/>`;
  svg += `<polyline points="${pts.map((p) => p.join(',')).join(' ')}" fill="none" stroke="#199e70" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
  const lp = pts[pts.length - 1];
  const lv = rows[rows.length - 1].renewableShare || 0;
  svg += `<circle cx="${lp[0]}" cy="${lp[1]}" r="4" fill="#199e70" stroke="var(--ui-bg)" stroke-width="2"/><text x="${lp[0] + 6}" y="${lp[1] + 4}" class="lbl">${Math.round(lv * 100)}%</text>`;
  svg += `<text x="${pl}" y="${H - 6}" class="ax">${rows[0].y}/${rows[0].m}</text><text x="${W - pr}" y="${H - 6}" class="ax" text-anchor="end">${rows[rows.length - 1].y}/${rows[rows.length - 1].m}</text>`;
  const band = (W - pl - pr) / (rows.length - 1);
  rows.forEach((r, k) => {
    svg += `<rect x="${xs(k) - band / 2}" y="${pt}" width="${band}" height="${H - pt - pb}" fill="transparent" data-tip="${r.y} 年 ${r.m} 月：綠電 ${Math.round((r.renewableShare || 0) * 100)}%"/>`;
  });
  return svg + '</svg>';
}

// ---- 發電組成（100% 橫條） ----
function mixBar(gen, total) {
  const items = GEN_ORDER.filter((k) => k !== 'battery' && (gen[k] || 0) > 0);
  const segs = items.map((k) => `<i style="flex:${gen[k]};background:${GEN_COLOR[k]}" data-tip="${GEN_NAME[k]}：${fmtDu(gen[k])}（${Math.round((gen[k] / total) * 100)}%）"></i>`).join('');
  const rows = items.map((k) => `<li><span class="sw" style="background:${GEN_COLOR[k]}"></span>${GEN_NAME[k]}${RENEWABLE.has(k) ? '<em>綠電</em>' : ''}<b>${Math.round((gen[k] / total) * 100)}%</b><span class="muted">${fmtDu(gen[k])}</span></li>`).join('');
  return `<div class="mix-bar">${segs}</div><ul class="mix-list">${rows}</ul>`;
}

// ---- 空氣品質（居民人數） ----
function airBar(levels, total) {
  const segs = AQI_LEVELS.map((l, k) => levels[k] > 0
    ? `<i style="flex:${levels[k]};background:${l.color}" data-tip="${l.name}：${t0(levels[k])} 人"></i>` : '').join('');
  const rows = AQI_LEVELS.map((l, k) => `<li><span class="sw" style="background:${l.color}"></span>${l.name}<b>${Math.round((levels[k] / total) * 100)}%</b></li>`).join('');
  return `<div class="mix-bar">${segs}</div><ul class="mix-list">${rows}</ul>`;
}

function tableDetails(rows) {
  return `<details class="tbl"><summary>看數字表格</summary><div class="tbl-wrap"><table>
    <thead><tr><th>月份</th>${CARBON_SOURCES.map((s) => `<th>${s.name}</th>`).join('')}<th>吸收</th><th>淨排放</th><th>綠電</th></tr></thead>
    <tbody>${rows.map((r) => `<tr><td>${r.y}/${r.m}</td>${CARBON_SOURCES.map((s) => `<td>${t0(r.co2?.[s.id] || 0)}</td>`).join('')}<td>${t0(r.co2?.absorb || 0)}</td><td>${t0(r.co2?.net || 0)}</td><td>${Math.round((r.renewableShare || 0) * 100)}%</td></tr>`).join('')}</tbody>
  </table></div><p class="note">單位：公噸 CO₂。</p></details>`;
}

function niceMax(v) {
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 2, 2.5, 5, 10]) if (m * p >= v) return m * p;
  return 10 * p;
}
function ticks(max) { return [0, max / 4, max / 2, (max * 3) / 4, max]; }
function shortT(v) { return v >= 10000 ? `${t1(v / 10000)}萬` : t0(v); }

export { PLANTS };
