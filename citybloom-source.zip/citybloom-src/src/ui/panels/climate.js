// 氣候面板：本月天氣、全球暖化情境、熱島，以及「減緩」與「調適」兩條路

import { SCENARIOS, WORLD_ANNUAL_CO2_T } from '../../data/climate.js';
import { scenarioCurve } from '../../climate/scenario.js';
import { wk } from '../wiki.js';

const f1 = (v) => (+v).toLocaleString('zh-TW', { maximumFractionDigits: 1, minimumFractionDigits: 1 });
const SC_COLOR = { low: '#199e70', mid: '#c98500', high: '#d95926' };

export function createClimatePanel(root, game) {
  const el = document.createElement('aside');
  el.className = 'side-panel climate-panel';
  el.hidden = true;
  el.setAttribute('aria-label', '氣候');
  root.appendChild(el);

  function render() {
    if (el.hidden || !game.world) return;
    const c = game.world.city;
    const cl = c.climate;
    const head = `<header><h3>氣候 <small>${c.year} 年 ${c.month} 月</small></h3><button type="button" class="x" data-act="close" aria-label="關閉">×</button></header>`;
    if (cl.temp == null) { el.innerHTML = head + '<p class="muted">時間開始走之後，這裡會顯示每個月的天氣與暖化情形。</p>'; return; }
    const sc = SCENARIOS[cl.scenario];
    const dT = cl.temp - cl.tempNormal;
    const rainPct = Math.round((cl.rain / Math.max(1, cl.rainNormal)) * 100);
    const share = c.carbon ? c.carbon.annual / WORLD_ANNUAL_CO2_T : 0;
    el.innerHTML = head + `
      <div class="kpis">
        <div><span>本月氣溫</span><b>${f1(cl.temp)} °C</b><em class="${dT >= 0 ? 'warm' : 'cool'}">比平常${dT >= 0 ? '高' : '低'} ${f1(Math.abs(dT))} °C</em></div>
        <div><span>本月雨量</span><b>${Math.round(cl.rain)} mm</b><em>平常的 ${rainPct}%</em></div>
        <div><span>${wk('heatIsland', '熱島強度')}</span><b>${f1(cl.heatIsland || 0)} °C</b><em>市中心比郊區熱</em></div>
        <div><span>今年高溫日（≥35 °C）</span><b>${Math.round(cl.hotDaysYear || 0)} 天</b><em>郊區約 ${Math.round(cl.hotDaysYearRural || 0)} 天</em></div>
      </div>
      <h4>全球暖化：${wk('warming', '世界的情境')}</h4>
      <p class="note">目前設定：<b style="color:${SC_COLOR[cl.scenario]}">${sc.name}（${sc.ssp}）</b>・${sc.desc}。今年全球比工業化前熱了 <b>${f1(cl.globalDT)} °C</b>。</p>
      <div class="chart">${curves(c.year, cl.scenario)}</div>
      <div class="viz-legend">${Object.values(SCENARIOS).map((s) => `<span><i style="background:${SC_COLOR[s.id]}"></i>${s.name}</span>`).join('')}<span><i style="background:#fff;width:2px"></i>今年</span></div>
      <div class="two-paths">
        <div class="path mitigate">
          <b>${wk('mitigation', '減緩')}：少排一點</b>
          <p>${share > 0
            ? `我們城市一年排放約 ${Math.round(c.carbon.annual).toLocaleString('zh-TW')} 公噸，大約是全世界的百萬分之 ${(share * 1e6).toFixed(2)}。`
            : '城市還沒有開始排碳。'}一座城市改變不了全球，但每座城市都減碳，世界才會走向低排放情境。</p>
        </div>
        <div class="path adapt">
          <b>${wk('adaptation', '調適')}：準備好面對</b>
          <p>不管世界怎麼走，城市都會變熱，極端天氣也會變多。公園、行道樹、綠屋頂、冷屋頂讓市中心涼一點；工具列的「調適」有滯洪池、堤防、再生水廠、避難中心等設施，幫城市撐過颱風、豪雨和乾旱。</p>
        </div>
      </div>
      <p class="note">冷氣用電：${Math.round(c.power?.coolingMWh || 0).toLocaleString('zh-TW')} MWh，占本月用電 ${c.power?.demandMWh ? Math.round(((c.power.coolingMWh || 0) / c.power.demandMWh) * 100) : 0}%。${wk('heatIsland', '熱島越嚴重，冷氣越耗電')}。</p>`;
  }

  el.addEventListener('click', (e) => { if (e.target.closest('[data-act="close"]')) toggle(false); });
  game.bus.on('tick', render);
  game.bus.on('world', render);
  function toggle(force) {
    el.hidden = force === undefined ? !el.hidden : !force;
    if (!el.hidden) { game.powerPanel?.toggle(false); game.hazardPanel?.toggle(false); }
    render();
  }
  return { toggle, render };
}

// 三種情境 2020–2100 升溫曲線，標出今年
function curves(year, current) {
  const W = 320, H = 150, pl = 30, pr = 10, pt = 10, pb = 22;
  const x = (y) => pl + ((W - pl - pr) * (y - 2020)) / 80;
  const yv = (v) => pt + (H - pt - pb) * (1 - (v - 1) / 4);
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="三種暖化情境的全球升溫">`;
  for (const g of [1, 2, 3, 4, 5]) svg += `<line x1="${pl}" x2="${W - pr}" y1="${yv(g)}" y2="${yv(g)}" class="grid"/><text x="${pl - 5}" y="${yv(g) + 4}" class="ax" text-anchor="end">${g}°</text>`;
  for (const id of ['low', 'mid', 'high']) {
    const pts = scenarioCurve(id).map(([yy, v]) => `${x(yy)},${yv(v)}`).join(' ');
    svg += `<polyline points="${pts}" fill="none" stroke="${SC_COLOR[id]}" stroke-width="${id === current ? 2.5 : 1.5}" opacity="${id === current ? 1 : 0.55}" stroke-linejoin="round"/>`;
  }
  const yy = Math.min(2100, Math.max(2020, year));
  svg += `<line x1="${x(yy)}" x2="${x(yy)}" y1="${pt}" y2="${H - pb}" stroke="#fff" stroke-width="1.5"/>`;
  svg += `<text x="${pl}" y="${H - 6}" class="ax">2020</text><text x="${x(2060)}" y="${H - 6}" class="ax" text-anchor="middle">2060</text><text x="${W - pr}" y="${H - 6}" class="ax" text-anchor="end">2100</text>`;
  return svg + '</svg>';
}
