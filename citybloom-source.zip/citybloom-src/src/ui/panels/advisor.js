// AI 市政顧問面板：四位只在乎單一目標的顧問 + 「AI 的好處與代價」帳本
// 顧問是規則式程式（不是真正的 AI），畫面上會清楚說明。

import { ADVISORS, advise, aiLedger } from '../../sim/advisor.js';
import { TOOLS } from '../toolbar.js';
import { wk } from '../wiki.js';
import { fmtDu } from '../hud.js';

const pct = (v) => `${Math.round(v * 100)}%`;
const SVC_NAME = { aiSignals: '智慧號誌', aiGrid: '智慧電網', aiWeather: '氣象預警', aiWater: '水資源管理' };

export function createAdvisorPanel(root, game) {
  const el = document.createElement('aside');
  el.className = 'side-panel advisor-panel';
  el.hidden = true;
  el.setAttribute('aria-label', 'AI 市政顧問');
  root.appendChild(el);
  let who = 'economy';
  let last = null;

  function render() {
    if (el.hidden || !game.world) return;
    const res = advise(game.world, who);
    last = res;
    const ledger = aiLedger(game.world);
    el.innerHTML = `
      <header><h3>AI 市政顧問</h3><button type="button" class="x" data-act="close" aria-label="關閉">×</button></header>
      <div class="adv-tabs" role="tablist">${Object.entries(ADVISORS).map(([k, a]) => `<button type="button" role="tab" aria-selected="${k === who}" class="${k === who ? 'on' : ''}" data-who="${k}">${a.name.replace('顧問', '')}</button>`).join('')}</div>
      <div class="adv-goal"><b>${res.advisor.name}</b>只在乎：${res.advisor.goal}。<br><span>不考慮：${res.advisor.ignores}</span></div>
      ${res.recs.length ? `<ol class="adv-recs">${res.recs.map((r, i) => `
        <li>
          <b>${r.title}</b>
          <p class="why"><span>根據</span>${r.why}</p>
          <p class="blind"><span>沒考慮到</span>${r.blind}</p>
          <div class="adv-act">
            ${r.tiles?.length ? `<button type="button" class="btn" data-show="${i}">在地圖上標示</button>` : ''}
            ${r.inspect ? `<button type="button" class="btn" data-inspect="${i}">查看資料中心</button>` : ''}
            ${r.tool && TOOLS[r.tool] ? `<button type="button" class="btn" data-tool="${r.tool}">選「${TOOLS[r.tool].name}」工具</button>` : ''}
          </div>
        </li>`).join('')}</ol>` : '<p class="note">目前沒有建議。城市再長大一點後再問問看。</p>'}
      <p class="adv-note">這是<b>規則式程式</b>，依照寫好的規則讀城市數據，不是真正的 AI。比一比不同顧問的建議：為什麼不一樣？哪些建議互相衝突？你們會怎麼決定？${wk('aiAdvisor', '（小百科）')}</p>

      <h4>${wk('dataCenter', 'AI 的好處與代價')}</h4>
      ${ledger ? `<div class="ledger">
        <div class="lg-good"><span>好處</span>
          <p>稅收每月約 <b>${Math.round(ledger.income / 10).toLocaleString('zh-TW')} 萬</b></p>
          <p>高薪工作 <b>${ledger.jobs}</b> 個</p>
          <p>${wk('compute', '算力')} <b>${Math.round(ledger.compute?.supply || 0)}</b>（智慧設施用了 ${Math.round(Math.min(ledger.compute?.supply || 0, ledger.compute?.demand || 0))}）</p>
          ${Object.entries(ledger.compute?.services || {}).filter(([, v]) => v > 0).map(([k, v]) => `<p class="svc">${SVC_NAME[k]} ${pct(v)}</p>`).join('')}
        </div>
        <div class="lg-cost"><span>代價</span>
          <p>用電 <b>${fmtDu(ledger.mwh)}</b>（全市 ${pct(ledger.mwhShare)}）</p>
          <p>碳排放約 <b>${Math.round(ledger.co2).toLocaleString('zh-TW')} 公噸</b>（全市 ${pct(ledger.co2Share)}）</p>
          <p>冷卻用水 <b>${Math.round(ledger.water / 1000).toLocaleString('zh-TW')} 千立方公尺</b>（全市 ${pct(ledger.waterShare)}）</p>
          <p>${wk('pue', 'PUE')} ${ledger.pue.toFixed(2)}・周圍地表變熱</p>
        </div>
      </div>
      <p class="note small">讓 AI 更環保：點資料中心可以升級「遠端綠電契約」、「液冷技術」、「廢熱回收」。</p>`
      : `<p class="note">城市還沒有 AI 資料中心。按 <kbd>X</kbd> 打開「智慧」工具，可以在工業區引進資料中心；有了它的算力，才能使用智慧號誌、智慧電網、AI 氣象預警與水資源管理。</p>`}`;
  }

  el.addEventListener('click', (e) => {
    if (e.target.closest('[data-act="close"]')) { toggle(false); return; }
    const w = e.target.closest('[data-who]');
    if (w) { who = w.dataset.who; game.clearHighlight?.(); render(); return; }
    const sh = e.target.closest('[data-show]');
    if (sh && last) { game.highlightTiles(last.recs[Number(sh.dataset.show)].tiles); return; }
    const ins = e.target.closest('[data-inspect]');
    if (ins && last) { const d = last.recs[Number(ins.dataset.inspect)].inspect; game.inspectInstance(d); return; }
    const t = e.target.closest('[data-tool]');
    if (t) { game.setTool(t.dataset.tool); }
  });
  game.bus.on('tick', render);
  game.bus.on('world', render);
  function toggle(force) {
    el.hidden = force === undefined ? !el.hidden : !force;
    if (!el.hidden) { game.powerPanel?.toggle(false); game.climatePanel?.toggle(false); game.hazardPanel?.toggle(false); }
    else game.clearHighlight?.();
    render();
  }
  return { toggle, render };
}
