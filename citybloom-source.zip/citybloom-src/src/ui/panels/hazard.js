// 防災面板：天氣預報、本月極端天氣、水庫與供水、氣候韌性指數、海平面、災情紀錄

import { WATER } from '../../data/hazards.js';
import { EVENT_NAME } from '../../climate/events.js';
import { wk } from '../wiki.js';

const LIKELY = { high: ['很可能', 'hi'], mid: ['可能', 'mid'], low: ['有機會', 'lo'] };
const PART_NAME = { flood: ['淹水防護', 'urbanFlood'], water: ['備用水源', 'recycledWater'], power: ['備用電力', 'roofSolar'], shelter: ['避難中心', 'shelter'], cooling: ['涼爽中心', 'coolingCenter'], warning: ['災害預警', 'earlyWarning'] };
const k = (v) => Math.round(v / 1000).toLocaleString('zh-TW');

export function createHazardPanel(root, game) {
  const el = document.createElement('aside');
  el.className = 'side-panel hazard-panel';
  el.hidden = true;
  el.setAttribute('aria-label', '防災與水資源');
  root.appendChild(el);

  function render() {
    if (el.hidden || !game.world) return;
    const c = game.world.city;
    const cl = c.climate;
    const fc = cl.forecast;
    const w = c.water;
    const res = c.resilience;
    const lv = w ? WATER.levels[w.level] : WATER.levels[0];
    const nextM = fc ? `${fc.y} 年 ${fc.m} 月` : '';
    const active = (cl.activeEvents || []).map((e) => e.name || EVENT_NAME[e.type]);
    const reps = [...(c.reports || [])].reverse().slice(0, 10);
    el.innerHTML = `
      <header><h3>防災與水資源 <small>${c.year} 年 ${c.month} 月</small></h3><button type="button" class="x" data-act="close" aria-label="關閉">×</button></header>
      <h4>${wk('forecast', '天氣預報')}：${nextM}</h4>
      ${fc && fc.shown.length ? `<ul class="fc-list">${fc.shown.map((s) => `<li><span class="lk ${LIKELY[s.likelihood][1]}">${LIKELY[s.likelihood][0]}</span>${s.text}</li>`).join('')}</ul>` : '<p class="note">目前沒有特別需要注意的天氣。</p>'}
      <p class="note small">${fc?.hasWarning ? '有災害預警中心：預報比較準確，也比較少虛驚一場。' : `預報不一定準。蓋一座${wk('earlyWarning', '災害預警中心')}，預報會更準確。`}</p>
      ${active.length ? `<p class="note">本月：<b>${active.join('、')}</b></p>` : ''}

      <h4>${wk('drought', '水庫')}與供水</h4>
      <div class="gauge">
        <div class="g-track"><i style="width:${Math.round((w?.storage ?? WATER.startStorage) * 100)}%;background:${lv.color}"></i>
          ${[0.5, 0.35, 0.2].map((t) => `<b style="left:${t * 100}%"></b>`).join('')}</div>
        <div class="g-read"><strong>${Math.round((w?.storage ?? WATER.startStorage) * 100)}%</strong><span style="color:${lv.color}">${lv.name}</span></div>
      </div>
      ${w ? `<dl class="mini-dl">
        <dt>城市每月用水</dt><dd>${k(w.demandM3)} 千立方公尺</dd>
        <dt>本地水源</dt><dd>${Math.round(w.localShare * 100)}%（不受限水影響）</dd>
        ${w.recycledM3 ? `<dt>${wk('recycledWater', '再生水')}</dt><dd>${k(w.recycledM3)} 千立方公尺</dd>` : ''}
        ${w.desalM3 ? `<dt>${wk('desalination', '海水淡化')}</dt><dd>${k(w.desalM3)} 千立方公尺</dd>` : ''}
        ${w.harvestM3 ? `<dt>${wk('rainHarvest', '雨水回收')}</dt><dd>${k(w.harvestM3)} 千立方公尺</dd>` : ''}
        ${w.shortageM3 > 0 ? `<dt class="warn">本月缺水</dt><dd class="warn">${k(w.shortageM3)} 千立方公尺</dd>` : ''}
      </dl>` : ''}

      <h4>${wk('resilience', '氣候韌性指數')}</h4>
      ${res ? `<div class="res-score"><strong>${res.score}</strong><span>/ 100</span></div>
      <div class="res-bars">${Object.entries(res.parts).map(([key, v]) => `<div class="rb"><span>${wk(PART_NAME[key][1], PART_NAME[key][0])}</span><i><b style="width:${Math.round(v * 100)}%"></b></i><em>${Math.round(v * 100)}</em></div>`).join('')}</div>` : '<p class="note">時間開始走之後會計算。</p>'}

      ${cl.coastal ? `<h4>${wk('seaLevel', '海平面上升')}</h4>
      <p class="note">比 2025 年高 <b>${Math.round((cl.seaRiseM || 0) * 100)} 公分</b>${(cl.seaLevelSpeed ?? 1) !== 1 ? `<span class="speed-tag">已加速 ${cl.seaLevelSpeed} 倍，非真實速度</span>` : ''}<br>被海水淹沒 ${cl.coastal.submerged} 公頃・漲潮會淹 ${cl.coastal.tidal} 公頃</p>` : ''}

      <h4>災情紀錄</h4>
      ${reps.length ? `<ul class="rep-list">${reps.map((r) => `<li><button type="button" data-rep="${r.id}"><span>${r.y}/${r.m}</span><b>${r.title}</b><em>${r.lossK ? Math.round(r.lossK / 10).toLocaleString('zh-TW') + ' 萬' : ''}</em></button></li>`).join('')}</ul>` : '<p class="note">還沒有發生災害。</p>'}`;
  }

  el.addEventListener('click', (e) => {
    if (e.target.closest('[data-act="close"]')) toggle(false);
    const r = e.target.closest('[data-rep]');
    if (r) game.reportCard.show(Number(r.dataset.rep));
  });
  game.bus.on('tick', render);
  game.bus.on('world', render);
  function toggle(force) {
    el.hidden = force === undefined ? !el.hidden : !force;
    if (!el.hidden) { game.powerPanel?.toggle(false); game.climatePanel?.toggle(false); game.advisorPanel?.toggle(false); }
    render();
  }
  return { toggle, render };
}
