// 頂部資訊列、左下格子資訊、右下視角控制、提示訊息

import { ICONS } from './icons.js';
import { SURFACE_NAME, ZOOM_LEVELS, NET, UTIL } from '../core/constants.js';
import { worldToView } from '../render/iso.js';
import { TOOLS } from './toolbar.js';
import { ZONE_INFO } from '../data/buildings/zones.js';
import { PLANTS } from '../data/energy.js';
import { AQI_LEVELS, aqiLevel } from '../data/environment.js';
import { TRAFFIC } from '../data/transport.js';
import { OVERLAYS } from '../render/overlays.js';
import { wk } from './wiki.js';
import { ADAPT, ADAPT_LINE, WATER } from '../data/hazards.js';
import { COVER, STATE, DEFENSE } from '../core/constants.js';
import { DATACENTER, SMART } from '../data/ai.js';

export function seasonOf(month) {
  if (month === 12 || month <= 2) return '冬';
  if (month <= 5) return '春';
  if (month <= 8) return '夏';
  return '秋';
}

// 資金以千元儲存，畫面顯示「萬」
export function formatFunds(k) {
  const wan = Math.round(k / 10);
  return wan.toLocaleString('zh-TW') + ' 萬';
}
const fmt = (v, d = 0) => (+v).toLocaleString('zh-TW', { maximumFractionDigits: d, minimumFractionDigits: d });
// 電量：1 MWh = 1,000 度（台灣常用「度」= 千瓦小時）
export function fmtDu(mwh) {
  const du = mwh * 1000;
  if (du >= 1e8) return `${fmt(du / 1e8, 2)} 億度`;
  if (du >= 1e4) return `${fmt(du / 1e4, du >= 1e6 ? 0 : 1)} 萬度`;
  return `${fmt(du)} 度`;
}

const SPEEDS = [
  { v: 0, icon: 'pause', label: '暫停' },
  { v: 1, icon: 'play1', label: '慢' },
  { v: 2, icon: 'play2', label: '中' },
  { v: 3, icon: 'play3', label: '快' },
];

export function createHud(root, game) {
  // ---- 頂部 ----
  const top = document.createElement('header');
  top.className = 'topbar';
  top.innerHTML = `
    <div class="brand"><b>築城物語</b><small>STAGE 7</small></div>
    <div class="speeds" role="group" aria-label="時間速度">
      ${SPEEDS.map((s) => `<button type="button" class="spd" data-speed="${s.v}" title="${s.label}${s.v === 0 ? '（P）' : ''}" aria-label="${s.label}">${ICONS[s.icon]}</button>`).join('')}
    </div>
    <div class="chips">
      <div class="chip date-chip"><strong data-k="date"></strong><span class="season" data-k="season"></span></div>
      <button type="button" class="chip temp-chip" data-act="climate" title="氣候：天氣、暖化、熱島">${ICONS.thermo}<strong data-k="temp">—</strong></button>
      <button type="button" class="chip fc-chip" data-act="hazard" title="天氣預報與防災">
        <span class="fc-ic" data-k="fcIcon"></span><span class="lbl-s">下月</span><strong data-k="fc"></strong>
      </button>
      <button type="button" class="chip water-chip" data-act="hazard" title="水庫蓄水率與限水">
        ${ICONS.drop}<strong data-k="water"></strong><i class="dot" data-k="waterDot"></i>
      </button>
      <div class="chip funds-chip"><span>資金</span><strong data-k="funds"></strong><em data-k="net"></em></div>
      <div class="chip pop-chip"><span>人口</span><strong data-k="pop"></strong></div>
      <div class="chip rci" title="住宅、商業、工業的需求：往上表示缺、會成長；往下表示太多、會衰退">
        ${['r', 'c', 'i'].map((k) => `<span class="rci-bar zc-${k}"><i data-k="d${k}"></i></span>`).join('')}
        <span class="rci-lbl">需求</span>
      </div>
      <button type="button" class="chip co2-chip" data-act="dash" title="永續儀表板：碳排放、綠電、空氣">
        <span>碳排</span><strong data-k="co2"></strong><em>公噸/月</em>
      </button>
      <div class="chip air-chip" title="居民平均吸到的空氣"><i class="dot" data-k="airDot"></i><span>空氣</span><strong data-k="air"></strong></div>
      <button type="button" class="chip power-chip" data-act="power" title="本月電力">
        ${ICONS.bolt}<strong data-k="renew"></strong><span data-k="powerState"></span>
      </button>
    </div>
    <div class="spacer"></div>
    <div class="fps" data-k="fps" hidden title="畫面更新速度（按 F 顯示或隱藏）"></div>
    <button class="btn advisor-btn" type="button" data-act="advisor" title="AI 市政顧問（規則式程式）">${ICONS.advisor}<span class="lbl">AI 顧問</span></button>
    <button class="btn sound-btn" type="button" data-act="sound" title="聲音：天氣音效與配景音樂" aria-label="聲音">${ICONS.speakerOff}</button>
    <button class="btn" type="button" data-act="wiki" title="小百科">${ICONS.book}<span class="lbl">小百科</span></button>
    <button class="btn" type="button" data-act="help" title="操作說明">${ICONS.help}<span class="lbl">說明</span></button>
    <button class="btn" type="button" data-act="newmap">${ICONS.map}<span class="lbl">新地圖</span></button>`;
  root.appendChild(top);
  top.addEventListener('click', (e) => {
    const a = e.target.closest('[data-act]')?.dataset.act;
    if (a === 'newmap') game.openNewMap();
    if (a === 'help') game.openHelp();
    if (a === 'power') game.powerPanel.toggle();
    if (a === 'dash') game.dashboard.toggle(true);
    if (a === 'climate') game.climatePanel.toggle();
    if (a === 'wiki') game.wiki.showAll();
    if (a === 'hazard') game.hazardPanel.toggle();
    if (a === 'advisor') game.advisorPanel.toggle();
    if (a === 'sound') game.broadcast.toggleMenu(e.target.closest('[data-act]'));
    const sp = e.target.closest('[data-speed]');
    if (sp) game.setSpeed(Number(sp.dataset.speed));
  });
  const q = (k) => top.querySelector(`[data-k="${k}"]`);

  function syncCity() {
    const c = game.world.city;
    q('date').textContent = `${c.year} 年 ${c.month} 月`;
    q('season').textContent = seasonOf(c.month);
    q('funds').textContent = formatFunds(c.funds);
    const net = c.lastMonth?.net ?? 0;
    const netEl = q('net');
    netEl.textContent = c.lastMonth ? `${net >= 0 ? '+' : '−'}${fmt(Math.abs(net / 10), 1)} 萬/月` : '';
    netEl.className = net >= 0 ? 'up' : 'down';
    q('pop').textContent = fmt(c.population);
    for (const k of ['r', 'c', 'i']) {
      const d = c.demandRCI[k] || 0;
      const el = q('d' + k);
      el.style.height = `${Math.abs(d) * 50}%`;
      el.style.bottom = d >= 0 ? '50%' : `${50 - Math.abs(d) * 50}%`;
      el.classList.toggle('neg', d < 0);
    }
    const cl = c.climate;
    q('temp').textContent = cl && cl.temp != null ? `${cl.temp.toFixed(1)} °C` : '—';
    top.querySelector('.temp-chip').classList.toggle('hot', !!cl && cl.tempMax >= 34);
    q('co2').textContent = c.carbon ? Math.round(c.carbon.net).toLocaleString('zh-TW') : '—';
    const lvl = c.air ? AQI_LEVELS[aqiLevel(c.air.avgExposure)] : AQI_LEVELS[0];
    q('air').textContent = c.population ? lvl.name : '—';
    q('airDot').style.background = lvl.color;
    const f = c.demandFactors;
    if (f) {
      const parts = [['空氣', f.air], ['治安', f.crime], ['塞車', f.traffic], ['找不到工作', f.jobs]].filter(([, v]) => v < -0.01).map(([k, v]) => `${k} −${Math.round(-v * 100)}%`);
      top.querySelector('.rci').title = `住宅、商業、工業的需求（往上＝缺、會成長；往下＝太多、會衰退）${parts.length ? '\n影響住宅需求：' + parts.join('、') : ''}`;
    }
    const p = c.power;
    q('renew').textContent = p && p.generationMWh > 0 ? `綠電 ${Math.round(p.renewableShare * 100)}%` : '尚無電廠';
    const st = q('powerState');
    if (!p || p.demandMWh === 0) { st.textContent = ''; st.className = ''; }
    else if (p.unservedMWh > p.demandMWh * 0.001) { st.textContent = `缺電 ${Math.round((p.unservedMWh / p.demandMWh) * 100)}%`; st.className = 'warn'; }
    else { st.textContent = '供電正常'; st.className = 'ok'; }

    // 預報與水庫
    const fc = cl?.forecast;
    const top1 = fc?.shown?.find((x) => x.likelihood !== 'low') || fc?.shown?.[0];
    const icon = { typhoon: 'storm', heavyRain: 'rain', heatwave: 'sun', drought: 'drop' }[top1?.type] || 'cloud';
    q('fcIcon').innerHTML = ICONS[icon];
    q('fc').textContent = top1 ? ({ typhoon: '颱風', heavyRain: '豪雨', heatwave: '高溫', drought: '少雨' }[top1.type] + (top1.likelihood === 'low' ? '？' : '')) : '平穩';
    top.querySelector('.fc-chip').classList.toggle('warn', !!top1 && top1.likelihood !== 'low');
    top.querySelector('.fc-chip').title = fc?.shown?.length ? `天氣預報（${fc.y} 年 ${fc.m} 月）：${fc.shown.map((x) => x.text).join('；')}` : '天氣預報：下個月沒有特別需要注意的天氣';
    const w = c.water;
    const wl = WATER.levels[w?.level ?? 0];
    q('water').textContent = `${Math.round((w?.storage ?? WATER.startStorage) * 100)}%`;
    q('waterDot').style.background = wl.color;
    top.querySelector('.water-chip').title = `水庫蓄水率：${wl.name}`;
  }
  function syncSound() {
    const on = (game.sound.settings.music || game.sound.settings.sfx) && game.sound.settings.volume > 0;
    top.querySelector('.sound-btn').innerHTML = on ? ICONS.speaker : ICONS.speakerOff;
    top.querySelector('.sound-btn').classList.toggle('on', game.sound.settings.music);
  }
  game.bus.on('sound', syncSound);
  setTimeout(syncSound, 0);
  function syncSpeed() {
    top.querySelectorAll('[data-speed]').forEach((b) => b.classList.toggle('active', Number(b.dataset.speed) === game.speed));
  }

  // ---- 左下格子資訊 ----
  const info = document.createElement('section');
  info.className = 'info';
  info.setAttribute('aria-live', 'polite');
  root.appendChild(info);
  info.addEventListener('click', (e) => {
    const b = e.target.closest('[data-upgrade]');
    if (b) game.send({ op: 'upgradeDC', id: Number(b.dataset.id), upgrade: b.dataset.upgrade });
  });

  function syncInfo() {
    if (!game.world) return;
    const tool = TOOLS[game.tool];
    const tile = game.selected ?? game.hoverTile;
    let html = `<div class="hint">${tool ? tool.hint : ''}</div>`;
    if (tile) html += tileDetails(game.world, tile, !!game.selected);
    info.innerHTML = html;
  }

  // ---- 右下視角控制 ----
  const ctl = document.createElement('div');
  ctl.className = 'viewctl';
  ctl.innerHTML = `
    <div class="compass" title="北方"><div class="ring"></div><div class="needle"></div><span class="n">北</span></div>
    <button class="icon-btn" type="button" data-act="rotL" title="向左旋轉（Q）" aria-label="向左旋轉">${ICONS.rotL}</button>
    <button class="icon-btn" type="button" data-act="rotR" title="向右旋轉（E）" aria-label="向右旋轉">${ICONS.rotR}</button>
    <button class="icon-btn" type="button" data-act="zoomOut" title="縮小（−）" aria-label="縮小">${ICONS.zoomOut}</button>
    <span class="zoom-read" data-k="zoom"></span>
    <button class="icon-btn" type="button" data-act="zoomIn" title="放大（+）" aria-label="放大">${ICONS.zoomIn}</button>
    <button class="icon-btn" type="button" data-act="grid" title="格線（G）" aria-label="格線">${ICONS.grid}</button>
    <button class="icon-btn" type="button" data-act="layers" title="資料圖層（L）" aria-label="資料圖層">${ICONS.layers}</button>`;
  root.appendChild(ctl);
  ctl.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const a = b.dataset.act;
    if (a === 'rotL') game.rotate(-1);
    if (a === 'rotR') game.rotate(1);
    if (a === 'zoomIn') game.zoom(1);
    if (a === 'zoomOut') game.zoom(-1);
    if (a === 'grid') game.toggleGrid();
    if (a === 'layers') { menu.hidden = !menu.hidden; syncOverlay(); }
  });

  // ---- 資料圖層選單與圖例 ----
  const menu = document.createElement('div');
  menu.className = 'overlay-menu';
  menu.hidden = true;
  menu.innerHTML = `<div class="fly-title">資料圖層</div>` +
    [['none', '不顯示'], ...Object.entries(OVERLAYS).map(([k, o]) => [k, o.name])]
      .map(([k, n]) => `<button type="button" class="ov-item" data-ov="${k}">${n}</button>`).join('');
  root.appendChild(menu);
  menu.addEventListener('click', (e) => {
    const b = e.target.closest('[data-ov]');
    if (!b) return;
    game.setOverlay(b.dataset.ov);
    menu.hidden = true;
  });
  document.addEventListener('pointerdown', (e) => {
    if (!menu.hidden && !menu.contains(e.target) && !ctl.contains(e.target)) menu.hidden = true;
  });
  const legend = document.createElement('div');
  legend.className = 'legend';
  legend.hidden = true;
  root.appendChild(legend);
  function syncOverlay() {
    const mode = game.renderer.overlay;
    menu.querySelectorAll('[data-ov]').forEach((b) => b.classList.toggle('active', b.dataset.ov === mode));
    ctl.querySelector('[data-act="layers"]').classList.toggle('on', mode !== 'none');
    const o = OVERLAYS[mode];
    legend.hidden = !o;
    if (!o) return;
    const scale = o.gradient
      ? `<div class="lg-grad" style="background:linear-gradient(90deg,${o.gradient.join(',')})"></div><div class="lg-ends"><span>${o.low}</span><span>${o.high}</span></div>`
      : `<div class="lg-keys">${o.legend.map(([c, n]) => `<span><i style="background:${c}"></i>${n}</span>`).join('')}</div>`;
    const extra = mode === 'pollution' && game.world.city.air ? `<div class="lg-wind">本月風向：${game.world.city.air.wind}</div>` : '';
    legend.innerHTML = `<b>${o.name}</b>${scale}${extra}<p>${o.note}</p>`;
  }
  game.bus.on('overlay', syncOverlay);
  game.bus.on('tick', syncOverlay);

  function syncView() {
    const cam = game.camera;
    ctl.querySelector('[data-k="zoom"]').textContent = `×${ZOOM_LEVELS[cam.zoomIndex]}`;
    ctl.querySelector('[data-act="grid"]').classList.toggle('on', game.renderer.grid);

    // 指北針：世界的北方 = y 減少的方向，換算到目前視角的畫面方向
    const n = game.world.size;
    const [ax, ay] = worldToView(0, 1, cam.rot, n);
    const [bx, by] = worldToView(0, 0, cam.rot, n);
    const dvx = bx - ax, dvy = by - ay;
    const sx = (dvx - dvy) * 32, sy = (dvx + dvy) * 16;
    const deg = (Math.atan2(sx, -sy) * 180) / Math.PI;
    ctl.querySelector('.needle').style.transform = `rotate(${deg}deg)`;
    const rad = (deg * Math.PI) / 180;
    ctl.querySelector('.n').style.transform = `translate(${Math.sin(rad) * 15}px, ${-Math.cos(rad) * 15}px)`;
  }

  // ---- 提示訊息 ----
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.setAttribute('role', 'status');
  root.appendChild(toast);
  let toastTimer = 0;
  game.bus.on('toast', (msg) => {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
  });

  // ---- FPS ----
  const fpsEl = q('fps');
  game.bus.on('fps', ({ fps, ms, visible }) => {
    fpsEl.hidden = !visible;
    if (!visible) return;
    fpsEl.innerHTML = `<b>${fps}</b> fps · 繪製 ${ms.toFixed(1)} ms`;
    fpsEl.classList.toggle('slow', fps < 50);
  });

  game.bus.on('city', syncCity);
  game.bus.on('speed', syncSpeed);
  game.bus.on('tool', syncInfo);
  game.bus.on('hover', syncInfo);
  game.bus.on('view', syncView);
  game.bus.on('world', () => { syncCity(); syncInfo(); syncView(); syncSpeed(); });
  syncCity(); syncInfo(); syncView(); syncSpeed();
}

// 格子詳細資料
function tileDetails(w, tile, pinned) {
  const L = w.layers;
  const i = tile.i;
  const rows = [];
  const add = (k, v, zh = false) => rows.push(`<dt>${k}</dt><dd${zh ? ' class="zh"' : ''}>${v}</dd>`);
  add(`位置${pinned ? '<span class="pinned">已選取</span>' : ''}`, `${tile.x}, ${tile.y}`);
  const alt = w.altitudeM(i);
  add('海拔', `${alt >= 0 ? '' : '−'}${Math.abs(alt).toFixed(1)} 公尺`);

  const bid = L.bld[i];
  const inst = bid && w.instances.get(bid);
  if (inst && inst.kind === 'plant') {
    const p = PLANTS[inst.def];
    add('建築', p.name, true);
    add('裝置容量', `${p.mw} MW${p.mwh ? ` · ${p.mwh} MWh` : ''}`);
    if (p.kind === 'storage') add('目前電量', `${fmtDu(inst.soc || 0)}／${fmtDu(p.mwh)}`);
    else {
      add('本月發電', fmtDu(inst.lastGenMWh || 0));
      add(wk('capacityFactor', '容量因數'), `${Math.round((inst.lastCF || 0) * 100)}%`);
      add('本月碳排', `${fmt(inst.lastCO2t || 0, 1)} 公噸`);
    }
    add('啟用', `${inst.builtYear} 年 ${inst.builtMonth} 月`);
    if (!(L.util[i] & UTIL.POWERED)) rows.push('<dt class="warn">尚未接上用電的地方</dt><dd></dd>');
    return `<dl>${rows.join('')}</dl><div class="side-fx">${p.sideEffects.map((s) => `<span>${s}</span>`).join('')}</div>`;
  }

  if (inst && inst.def === 'dataCenter') {
    const D = DATACENTER;
    const up = inst.upgrades || {};
    add('建築', 'AI 資料中心', true);
    add('運轉', (inst.operating ?? 1) >= 1 ? '<span class="ok">全速運轉</span>' : (inst.operating ?? 1) > 0 ? '<span class="warn">限水降載中</span>' : '<span class="warn">停電，停止運轉</span>', true);
    add('本月用電', fmtDu(inst.lastMWh || 0));
    add(wk('pue', 'PUE'), (inst.lastPue || D.pue.air).toFixed(2));
    add('冷卻用水', `${Math.round((inst.lastWaterM3 || 0) / 1000).toLocaleString('zh-TW')} 千立方公尺／月`);
    add('稅收', `每月約 ${Math.round(D.taxPerMonth / 10)} 萬`);
    add(wk('compute', '提供算力'), `${D.compute}`);
    const btns = Object.entries(D.upgrades).map(([k, u]) => up[k]
      ? `<span class="up-done">✓ ${u.name}</span>`
      : `<button type="button" class="btn up-btn" data-upgrade="${k}" data-id="${inst.id}" title="${u.desc}">${u.name}・${Math.round(u.cost / 10)} 萬</button>`).join('');
    return `<dl>${rows.join('')}</dl><div class="side-fx">${D.side.map((x) => `<span>${x}</span>`).join('')}</div><div class="up-row">${btns}</div><div class="hint">${wk('dataCenter', '小百科：AI 資料中心')}</div>`;
  }
  if (inst && SMART[inst.def]) {
    const d = SMART[inst.def];
    const svc = w.city.compute?.services?.[inst.def] ?? 0;
    add('建築', d.name, true);
    add('效果', d.effects, true);
    add(wk('compute', '算力'), svc >= 1 ? '<span class="ok">足夠，全力運作</span>' : svc > 0 ? `<span class="warn">不夠，只發揮 ${Math.round(svc * 100)}%</span>` : '<span class="warn">沒有算力（需要 AI 資料中心）</span>', true);
    return `<dl>${rows.join('')}</dl><div class="hint">${wk(d.wiki, '小百科：' + d.name)}</div>`;
  }
  if (inst && inst.kind === 'adapt') {
    const d = ADAPT[inst.def];
    add('建築', d.name, true);
    add('效果', d.effects, true);
    add('對抗', d.against.join('、'), true);
    if (d.powerMWh) add('電力', L.util[i] & UTIL.POWERED && !(L.util[i] & (UTIL.BLACKOUT | UTIL.STORM_OUTAGE)) ? '<span class="ok">有電，可以運作</span>' : '<span class="warn">沒有電，不能運作</span>', true);
    add('啟用', `${inst.builtYear} 年 ${inst.builtMonth} 月`);
    return `<dl>${rows.join('')}</dl>${d.side.length ? `<div class="side-fx">${d.side.map((x) => `<span>${x}</span>`).join('')}</div>` : ''}<div class="hint">${wk(d.wiki, '小百科：' + d.name)}</div>`;
  }
  stateRows(L, i, add);

  const z = L.zone[i];
  if (z) {
    const info = ZONE_INFO[z];
    add('分區', info.name, true);
    const lv = L.devLevel[i];
    add('建築', lv ? `第 ${lv} 級` : '空地（等待開發）', true);
    if (lv) add(info.kind === 'r' ? '居民' : '工作', fmt(info.kind === 'r' ? L.pop[i] : L.jobs[i]));
    const u = L.util[i];
    add('電力', !(u & UTIL.POWERED) ? '<span class="warn">沒有電</span>' : u & UTIL.BLACKOUT ? '<span class="warn">輪流停電中</span>' : '<span class="ok">有電</span>', true);
    add('道路', nearRoad(w, tile.x, tile.y) ? '<span class="ok">3 格內有路</span>' : '<span class="warn">太遠，不會發展</span>', true);
    if (L.cover[i] & 2) add('屋頂', '綠屋頂', true);
    else if (L.cover[i] & 4) add('屋頂', '冷屋頂', true);
    coverRows(L, i, add);
    envRows(L, i, add);
  } else {
    const net = L.net[i];
    const parts = [];
    if (net & NET.ROAD) parts.push('道路');
    if (net & NET.POWERLINE) parts.push('電線');
    add('地表', parts.length ? parts.join('＋') : SURFACE_NAME[L.surface[i]], true);
    if (net & NET.POWERLINE) add('電力', L.util[i] & UTIL.POWERED ? '<span class="ok">有電</span>' : '<span class="warn">沒接上電廠</span>', true);
    if (net & NET.ROAD) {
      const ratio = L.traffic[i] / 128;
      const st = ratio < 0.5 ? '<span class="ok">順暢</span>' : ratio < 1 ? '車多' : ratio < 1.5 ? '<span class="warn">擁擠</span>' : '<span class="warn">塞車</span>';
      add('車流', `${st} · 約 ${fmt(ratio * TRAFFIC.roadCapacity)} 輛`, true);
      if (net & NET.BIKE) add('自行車道', '有', true);
      if (L.cover[i] & 8) add('行道樹', '有', true);
      if (net & NET.STORM_DRAIN) add(wk('stormDrain', '下水道'), '已擴建', true);
      coverRows(L, i, add);
      add(wk('surfaceTemp', '地表溫度'), `${L.surfTemp[i].toFixed(1)} °C`);
    }
    if (L.defense[i] & DEFENSE.LEVEE) add(wk('levee', '堤防'), '有', true);
    if (L.defense[i] & DEFENSE.SEAWALL) add(wk('seawall', '海堤'), '有', true);
    if (L.cover[i] & COVER.RAIN_GARDEN) add(wk('rainGarden', '雨水花園'), '有', true);
    if (!net && L.surface[i] !== 2) envRows(L, i, add);
  }
  if (inst && inst.kind === 'park') {
    return `<dl>${rows.join('')}<dt>建築</dt><dd class="zh">${inst.def === 'bigPark' ? '公園' : '小公園'}</dd><dt>${wk('surfaceTemp', '地表溫度')}</dt><dd>${L.surfTemp[i].toFixed(1)} °C</dd></dl>`;
  }
  if (inst && inst.kind === 'transit') {
    return `<dl>${rows.join('')}<dt>建築</dt><dd class="zh">公車站</dd><dt>服務範圍</dt><dd class="zh">附近 600 公尺</dd></dl>`;
  }
  return `<dl>${rows.join('')}</dl>`;
}

function stateRows(L, i, add) {
  const st = L.state[i];
  const u = L.util[i];
  if (st & STATE.SUBMERGED) add('狀態', '<span class="warn">已被海水淹沒，不能使用</span>', true);
  else if (st & STATE.TIDAL) add('狀態', '<span class="warn">漲潮時會被海水倒灌</span>', true);
  if (L.floodDepth[i] >= 10) add('本月淹水', `<span class="warn">${L.floodDepth[i]} 公分</span>`);
  if (st & STATE.DAMAGED) add('建築', '<span class="warn">受損，修理中</span>', true);
  if (u & UTIL.STORM_OUTAGE) add('電力', '<span class="warn">颱風吹斷電線，停電中</span>', true);
  if (u & UTIL.BACKUP_POWER) add('電力', '<span class="ok">停電中，靠屋頂光電供電</span>', true);
  if (u & UTIL.WATER_RESTRICTED) add('供水', '<span class="warn">限水中</span>', true);
}

function coverRows(L, i, add) {
  const cv = L.cover[i];
  const parts = [];
  if (cv & COVER.PERMEABLE) parts.push(ADAPT_LINE.permeable.name);
  if (cv & COVER.RAIN_HARVEST) parts.push(ADAPT_LINE.rainHarvest.name);
  if (cv & COVER.ROOF_SOLAR) parts.push(ADAPT_LINE.roofSolar.name);
  if (cv & COVER.UNDERGROUND_GRID) parts.push(ADAPT_LINE.undergroundGrid.name);
  if (cv & COVER.RAIN_GARDEN) parts.push(ADAPT_LINE.rainGarden.name);
  if (parts.length) add(wk('adaptation', '調適設施'), parts.join('、'), true);
}

function envRows(L, i, add) {
  const lv = AQI_LEVELS[aqiLevel(L.pollution[i])];
  if (L.surfTemp[i]) add(wk('surfaceTemp', '地表溫度'), `${L.surfTemp[i].toFixed(1)} °C`);
  add(wk('landValue', '地價'), `${fmt(L.landValue[i])}<span class="mini-bar"><i style="width:${Math.min(100, L.landValue[i] / 2)}%"></i></span>`);
  add(wk('aqi', '空氣'), `<i class="dot" style="background:${lv.color}"></i>${lv.name}`, true);
  if (L.zone[i]) add('治安', L.crime[i] < 30 ? '<span class="ok">良好</span>' : L.crime[i] < 70 ? '普通' : '<span class="warn">需要關注</span>', true);
  const fr = L.floodRisk[i];
  add(wk('urbanFlood', '淹水潛勢'), fr < 10 ? '<span class="ok">低</span>' : fr < 50 ? `中（約 ${fr} 公分）` : `<span class="warn">高（約 ${fr} 公分）</span>`, true);
}

function nearRoad(w, x, y) {
  for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
    if (Math.abs(dx) + Math.abs(dy) > 3) continue;
    const nx = x + dx, ny = y + dy;
    if (w.inBounds(nx, ny) && w.layers.net[w.index(nx, ny)] & NET.ROAD) return true;
  }
  return false;
}
