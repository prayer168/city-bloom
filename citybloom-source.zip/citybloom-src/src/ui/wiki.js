// 小百科彈出卡：任何帶有 data-wiki="條目" 的元素被點到時打開

import { WIKI } from '../data/wiki.js';

export const wk = (key, text) => `<button type="button" class="wk" data-wiki="${key}">${text ?? WIKI[key]?.title ?? key}</button>`;

export function createWiki(root, game) {
  const back = document.createElement('div');
  back.className = 'modal-back wiki-back';
  back.hidden = true;
  back.innerHTML = '<div class="modal wiki-card" role="dialog" aria-modal="true" aria-labelledby="wiki-title"></div>';
  root.appendChild(back);
  const card = back.firstElementChild;

  function show(key) {
    const e = WIKI[key];
    if (!e) return;
    card.innerHTML = `
      <div class="wiki-head"><span class="wiki-tag">小百科</span><button type="button" class="x" data-act="close" aria-label="關閉">×</button></div>
      <h2 id="wiki-title">${e.title}</h2>
      <p class="wiki-body">${e.body}</p>
      ${e.diagram ? DIAGRAMS[e.diagram] : ''}
      ${e.fact ? `<p class="wiki-fact"><b>小知識</b>${e.fact}</p>` : ''}
      ${e.related?.length ? `<div class="wiki-rel"><span>相關：</span>${e.related.map((k) => wk(k)).join('')}</div>` : ''}
      <div class="actions"><button type="button" class="btn" data-act="all">所有條目</button><button type="button" class="btn primary" data-act="close">知道了</button></div>`;
    open();
  }

  function showAll() {
    card.innerHTML = `
      <div class="wiki-head"><span class="wiki-tag">小百科</span><button type="button" class="x" data-act="close" aria-label="關閉">×</button></div>
      <h2 id="wiki-title">所有條目</h2>
      <div class="wiki-list">${Object.keys(WIKI).map((k) => wk(k)).join('')}</div>`;
    open();
  }

  function open() {
    back.hidden = false;
    game.modalOpen = true;
    card.querySelector('[data-act="close"]').focus();
  }
  function close() {
    back.hidden = true;
    game.modalOpen = false;
  }

  back.addEventListener('click', (e) => {
    if (e.target === back) return close();
    const a = e.target.closest('[data-act]')?.dataset.act;
    if (a === 'close') close();
    if (a === 'all') showAll();
  });
  back.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); e.stopPropagation(); });
  // 整個畫面任何地方的小百科連結
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-wiki]');
    if (!t) return;
    e.preventDefault();
    show(t.dataset.wiki);
  });

  return { show, showAll, close };
}

// 熱島正回饋圖解：四個步驟圍成一圈，中間標出打破循環的方法
const DIAGRAMS = {
  heatLoop: `<figure class="wiki-fig"><svg viewBox="0 0 440 230" role="img" aria-label="熱島正回饋：城市變熱、開更多冷氣、用電與廢熱增加、城市更熱">
    <defs><marker id="arw" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#f4c04f"/></marker></defs>
    <g font-size="14" text-anchor="middle" fill="#edf1f8">
      <rect x="150" y="10" width="140" height="40" rx="10" fill="#3a2320" stroke="#d95926"/><text x="220" y="35">城市變熱</text>
      <rect x="290" y="95" width="140" height="40" rx="10" fill="#232c3f" stroke="#3987e5"/><text x="360" y="120">開更多冷氣</text>
      <rect x="150" y="180" width="140" height="40" rx="10" fill="#232c3f" stroke="#9085e9"/><text x="220" y="198" font-size="12.5">用電增加</text><text x="220" y="214" font-size="12.5">排出廢熱與碳</text>
      <rect x="10" y="95" width="140" height="40" rx="10" fill="#3a2320" stroke="#d95926"/><text x="80" y="120">廢熱讓城市更熱</text>
    </g>
    <g fill="none" stroke="#f4c04f" stroke-width="2" marker-end="url(#arw)">
      <path d="M290,35 Q360,40 360,90"/><path d="M360,140 Q360,195 296,200"/><path d="M150,200 Q80,195 80,140"/><path d="M80,90 Q80,40 144,32"/>
    </g>
    <g font-size="12" fill="#7fd1a1" text-anchor="middle"><text x="220" y="98">打破循環：</text><text x="220" y="116">公園、行道樹</text><text x="220" y="134">綠屋頂、冷屋頂</text></g>
  </svg></figure>`,
};
