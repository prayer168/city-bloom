// 城市廣播：畫面上方的文字通知，依事件種類用不同顏色的發光邊框（沒有人聲）
// 沒有災害消息時，輪播「城市消息」：好人好事、市政宣導、科學榮譽、科學小故事（src/data/news.js）
// 也負責聲音選單（配景音樂、天氣音效、音量）

import { ICONS } from './icons.js';
import { NEWS_CAT, newsContext, pickNews } from '../data/news.js';

export function createBroadcast(root, game) {
  const sound = game.sound;
  const bar = document.createElement('div');
  bar.className = 'broadcast';
  bar.setAttribute('role', 'status');
  bar.setAttribute('aria-live', 'polite');
  bar.hidden = true;
  bar.innerHTML = `<span class="bc-tag">${ICONS.alert}城市廣播</span><span class="bc-text"></span><button type="button" class="x" aria-label="關閉廣播">×</button>`;
  root.appendChild(bar);
  const textEl = bar.querySelector('.bc-text');
  const tagEl = bar.querySelector('.bc-tag');
  const queue = [];
  let timer = 0;
  let current = null;
  const recentNews = [];
  let newsOff = false; // 按 × 關掉消息輪播：到下個月再恢復

  function nextNews() {
    if (newsOff || !game.world || game.world.city.climate?.temp == null) return null;
    const n = pickNews(newsContext(game.world), Math.random, recentNews);
    recentNews.push(n.id);
    while (recentNews.length > 20) recentNews.shift();
    return n;
  }

  function next() {
    clearTimeout(timer);
    current = queue.shift() || nextNews();
    if (!current) { bar.classList.remove('show'); setTimeout(() => { if (!current) bar.hidden = true; }, 300); return; }
    const news = current.kind === 'news';
    bar.hidden = false;
    bar.dataset.kind = current.kind;
    bar.dataset.type = current.type || '';
    bar.dataset.cat = current.cat || '';
    if (news) bar.style.setProperty('--glow', NEWS_CAT[current.cat].color);
    else bar.style.removeProperty('--glow');
    tagEl.innerHTML = news ? `${ICONS.news}${NEWS_CAT[current.cat].name}` : `${ICONS.alert}城市廣播`;
    textEl.innerHTML = '<span class="bc-run"></span>';
    const run = textEl.firstChild;
    run.textContent = current.text;
    bar.classList.toggle('clickable', !!current.reportId);
    bar.classList.remove('show');
    requestAnimationFrame(() => bar.classList.add('show'));
    // 太長放不下時，文字慢慢往左捲動（跑馬燈）；看得完才換下一則
    let dur = Math.max(news ? 12000 : 6000, 3500 + current.text.length * 140);
    requestAnimationFrame(() => {
      const over = run.scrollWidth - textEl.clientWidth;
      textEl.classList.toggle('marquee', over > 4);
      if (over > 4) {
        const scrollMs = Math.max(6000, over * 45);
        run.style.setProperty('--dist', `-${over + 16}px`);
        run.style.animationDuration = `${scrollMs}ms`;
        dur = Math.max(dur, scrollMs + 4000);
      }
      clearTimeout(timer);
      timer = setTimeout(next, dur);
    });
  }

  game.bus.on('broadcast', (items) => {
    // 同一批只留最重要的：災情報告 > 事件 > 預報
    const order = { report: 0, event: 1, forecast: 2 };
    const sorted = [...items].sort((a, b) => (order[a.kind] ?? 3) - (order[b.kind] ?? 3));
    for (const it of sorted.slice(0, 3)) queue.push(it);
    while (queue.length > 4) queue.shift();
    // 重要的消息（災害發生、災情報告）插隊，不用等預報唸完
    if (!current || current.kind === 'news' || (current.kind === 'forecast' && sorted[0] && sorted[0].kind !== 'forecast')) next();
    // 有新的災情報告：彈出報告（不暫停遊戲）
    const rep = items.filter((x) => x.reportId).pop();
    if (rep) game.reportCard?.show(rep.reportId);
  });
  bar.addEventListener('click', (e) => {
    if (e.target.closest('.x')) {
      if (current?.kind === 'news' && !queue.length) newsOff = true;
      queue.length = 0; next(); return;
    }
    if (current?.reportId) game.reportCard?.show(current.reportId);
  });

  // ---- 聲音選單 ----
  const menu = document.createElement('div');
  menu.className = 'sound-menu';
  menu.hidden = true;
  root.appendChild(menu);
  function renderMenu() {
    const s = sound.settings;
    menu.innerHTML = `
      <div class="fly-title">聲音</div>
      <label class="sw"><input type="checkbox" data-k="sfx" ${s.sfx ? 'checked' : ''}><span>天氣音效<small>下雨、颱風、雷聲、熱浪蟬鳴</small></span></label>
      <label class="sw"><input type="checkbox" data-k="music" ${s.music ? 'checked' : ''}><span>配景音樂</span></label>
      <label class="vol"><span>音量</span><input type="range" min="0" max="1" step="0.05" value="${s.volume}" data-k="volume" aria-label="音量"></label>
      <button type="button" class="btn" data-act="test">試聽雨聲</button>`;
  }
  menu.addEventListener('input', (e) => {
    const k = e.target.dataset.k;
    if (!k) return;
    sound.ensure();
    sound.set(k, e.target.type === 'checkbox' ? e.target.checked : Number(e.target.value));
    game.bus.emit('sound');
  });
  menu.addEventListener('click', (e) => {
    if (e.target.closest('[data-act="test"]')) {
      sound.ensure();
      const keep = { ...sound.weather };
      sound.setWeather({ rain: 0.8, wind: 0.6 });
      setTimeout(() => sound.setWeather(keep), 4000);
    }
  });
  document.addEventListener('pointerdown', (e) => {
    if (!menu.hidden && !menu.contains(e.target) && !e.target.closest('[data-act="sound"]')) menu.hidden = true;
  });
  // 第一次點畫面時準備好音訊（瀏覽器規定：使用者互動後才能出聲）
  const unlock = () => {
    sound.ensure();
    if (sound.settings.music) sound.startMusic();
    game.bus.emit('sound');
    window.removeEventListener('pointerdown', unlock);
    window.removeEventListener('keydown', unlock);
  };
  window.addEventListener('pointerdown', unlock);
  window.addEventListener('keydown', unlock);

  // 依天氣換音樂氣氛與天氣音效
  game.bus.on('tick', () => {
    newsOff = false;
    if (!current) next();
    const ev = game.world.city.climate.activeEvents || [];
    sound.setMood(ev.some((e) => e.type === 'typhoon' || e.type === 'heavyRain') ? 'storm' : ev.some((e) => e.type === 'heatwave') ? 'heat' : 'calm');
  });

  return {
    toggleMenu(anchor) {
      menu.hidden = !menu.hidden;
      if (menu.hidden) return;
      renderMenu();
      const r = anchor.getBoundingClientRect();
      menu.style.top = r.bottom + 8 + 'px';
      menu.style.right = Math.max(8, window.innerWidth - r.right) + 'px';
    },
    say(text, kind = 'event') { queue.push({ kind, text }); if (!current) next(); },
  };
}
