// 小百科：國小高年級看得懂的名詞解釋
// 每則：title 標題、body 說明、fact 小知識（選填）、related 相關條目

export const WIKI = {
  co2: {
    title: '碳排放',
    body: '燒煤、燒天然氣、開汽油車的時候，會排出二氧化碳（CO₂）。二氧化碳會留在大氣中，像一件越穿越厚的外套，讓地球慢慢變熱。我們把排出的二氧化碳量叫做「碳排放」，單位常用「公噸」。',
    fact: '1 公噸二氧化碳在常溫下大約可以裝滿 500 立方公尺的空間，差不多是一間教室的兩倍大。',
    related: ['greenhouse', 'perCapita', 'netZero'],
  },
  greenhouse: {
    title: '溫室效應',
    body: '太陽的熱照到地球後，有一部分會被大氣中的二氧化碳等「溫室氣體」留住。適量的溫室效應讓地球保持溫暖、適合生物生活；但溫室氣體太多，熱就散不出去，地球會越來越熱，這就是全球暖化。',
    related: ['co2', 'netZero'],
  },
  perCapita: {
    title: '人均碳排放',
    body: '把整座城市一年的碳排放，除以城市的人口，就是「平均每個人一年排放多少」。這樣才能公平比較大城市和小城市。',
    fact: '全世界平均每人每年約排放 4.7 公噸二氧化碳（化石燃料與工業，2023 年，Our World in Data）。',
    related: ['co2'],
  },
  netZero: {
    title: '淨零排放',
    body: '「淨零」不是完全不排放，而是排放出去的二氧化碳，和被樹林等吸收回來的一樣多，加起來等於零。要做到淨零，最重要的是先大幅減少排放，再用吸收來抵銷剩下一點點。',
    related: ['carbonSink', 'co2'],
  },
  carbonSink: {
    title: '碳吸收（碳匯）',
    body: '樹木在行光合作用時，會把空氣中的二氧化碳變成自己的身體。森林、海洋、濕地都能吸收二氧化碳，叫做「碳匯」。樹木長大的這幾十年吸收最多；已經很成熟的老森林，每年新吸收的量比較少，但它把大量的碳「存」在樹裡。砍掉樹林，存著的碳就會跑回空氣中。',
    fact: '遊戲為了簡化，只計算你新種的樹林：1 公頃每年約吸收 8 公噸；砍掉 1 公頃成熟樹林約釋放 150 公噸。一座燃煤電廠一個月就可能排放上千公噸，所以種樹很好，但不能取代減少排放。',
    related: ['netZero'],
  },
  renewable: {
    title: '再生能源與綠電比例',
    body: '太陽能、風力、水力的能量來自大自然，用了還會再有，叫做「再生能源」，發電時幾乎不排放二氧化碳。「綠電比例」就是再生能源發的電占全部發電量的百分之幾。',
    fact: '核能發電時也幾乎不排碳，但它用的鈾礦會用完，所以不算再生能源。',
    related: ['capacityFactor', 'storage'],
  },
  capacityFactor: {
    title: '容量因數',
    body: '一座電廠如果整個月都用最大力氣發電，叫做 100%。實際上太陽能晚上不發電、風有時候很小，所以實際發的電只有最大值的一部分，這個百分比就是「容量因數」。',
    fact: '在台灣，太陽能大約 12%–17%，冬天的風力可以到 40% 以上，核能大約 90%。',
    related: ['renewable', 'baseload'],
  },
  storage: {
    title: '儲能',
    body: '儲能電池像一個超大的行動電源：中午太陽能發的電用不完時先存起來，晚上再放出來用。充電再放電的過程會損失一些電（遊戲裡約 15%）。',
    related: ['curtail', 'renewable'],
  },
  curtail: {
    title: '棄電',
    body: '電廠發出來的電，如果沒有人用、也沒有地方存，就只好浪費掉，叫做「棄電」。多蓋儲能，或讓用電時間配合發電時間，都可以減少棄電。',
    related: ['storage'],
  },
  rollingBlackout: {
    title: '輪流停電',
    body: '電不夠用的時候，電力公司會讓不同地區輪流停電，避免整個電網一起當機。在遊戲裡，離電廠最遠的地方會先停電。',
    related: ['storage', 'baseload'],
  },
  baseload: {
    title: '基載電力',
    body: '不管白天晚上都穩定發電、出力固定的電廠，叫做基載電廠，例如核能。它很穩定，但不容易隨著用電多少調整。燃煤、燃氣電廠則可以依需要增加或減少發電。',
    related: ['capacityFactor'],
  },
  nuclearWaste: {
    title: '核廢料',
    body: '核能電廠用過的燃料仍然有很強的輻射，需要非常長的時間（數千年以上）安全保存。要把核廢料放在哪裡，是許多國家都在討論的問題。',
    related: ['baseload'],
  },
  kwh: {
    title: '度（電的單位）',
    body: '台灣電費單上的「1 度電」就是 1 千瓦小時（kWh）：一台 1000 瓦的電器用 1 小時。1,000 度 = 1 MWh（百萬瓦小時）。',
    fact: '台灣一個人在家裡每年大約用 2,000 度電。',
  },
  aqi: {
    title: '空氣品質指標',
    body: '用顏色告訴大家今天的空氣好不好：綠色良好、黃色普通、橘色對敏感族群不健康、紅色不健康。空氣不好的時候，氣喘的同學要特別小心。',
    fact: '遊戲裡的污染值是 0–255 的相對指標，只借用空氣品質指標的顏色分級，不是真實的 AQI 數字。',
    related: ['pm25', 'monsoon'],
  },
  pm25: {
    title: '細懸浮微粒（PM2.5）',
    body: '飄在空氣中、比頭髮直徑小約 30 倍的小顆粒，主要來自工廠、電廠、汽機車排氣。它可以跑進肺部深處，對健康不好。',
    related: ['aqi'],
  },
  monsoon: {
    title: '季風',
    body: '台灣冬天（約 10 月到隔年 4 月）吹東北季風，夏天（約 5 到 9 月）吹西南季風。風會把空氣污染吹向下風處，所以工廠蓋在住宅區的哪一邊很重要。',
    fact: '冬天東北季風也是台灣風力發電最多的季節。',
    related: ['aqi', 'capacityFactor'],
  },
  landValue: {
    title: '地價',
    body: '一塊土地值多少錢。靠近水邊、公園、市中心、交通方便的地方比較貴；有污染、治安不好、常塞車的地方比較便宜。地價高的地方才會蓋高樓。',
    related: ['zoning'],
  },
  zoning: {
    title: '都市計畫分區',
    body: '政府規劃每塊土地可以做什麼用：住宅區給人住、商業區開店和辦公、工業區設工廠。在台灣的都市計畫圖上，住宅區是黃色、商業區是紅色、工業區是紫色，遊戲也用同樣的顏色。',
    related: ['landValue'],
  },
  commute: {
    title: '通勤',
    body: '每天從家裡到學校或上班地點，再回家的移動。住家和工作地點離得越遠，通勤越久，交通產生的碳排放也越多。',
    related: ['transit'],
  },
  transit: {
    title: '大眾運輸',
    body: '公車、捷運、火車等大家一起搭的交通工具。一輛公車可以載幾十個人，平均每個人排放的二氧化碳比各自開車少很多，路上也比較不會塞車。',
    fact: '在遊戲裡，開車每人每公里約排放 0.12 公斤二氧化碳，搭公車約 0.03 公斤，騎腳踏車是 0。',
    related: ['commute'],
  },
  heatIsland: {
    title: '都市熱島效應',
    body: '城市裡有很多柏油路、水泥建築，白天吸收大量太陽熱，晚上慢慢放出來；冷氣和汽機車還會排出廢熱。所以市中心常常比郊區熱好幾度，就像一座「熱的島」。',
    diagram: 'heatLoop',
    fact: '這是一個「正回饋」：越熱越開冷氣，冷氣排出的廢熱又讓城市更熱。種樹、蓋公園、做綠屋頂或冷屋頂，可以打破這個循環。',
    related: ['surfaceTemp', 'greenRoof', 'coolRoof', 'streetTrees'],
  },
  surfaceTemp: {
    title: '地表溫度',
    body: '地面本身的溫度，也就是你中午摸地板感覺到的熱度。夏天中午的柏油路可能超過 50 °C，草地和樹蔭下則涼很多。地表溫度通常比氣溫變化大。',
    related: ['heatIsland'],
  },
  streetTrees: {
    title: '行道樹',
    body: '種在道路兩旁的樹。樹蔭擋住陽光，葉子蒸散水分也會帶走熱，所以有行道樹的路比較涼，走路和騎車也比較舒服。',
    related: ['heatIsland'],
  },
  greenRoof: {
    title: '綠屋頂',
    body: '在建築屋頂種草、種花或小灌木。植物和土壤可以隔熱，讓樓下比較涼；下大雨時還能先吸住一些雨水。',
    related: ['coolRoof', 'heatIsland'],
  },
  coolRoof: {
    title: '冷屋頂',
    body: '把屋頂塗成白色或淺色的反光材料，太陽光被反射回去，屋頂就不會那麼燙。做法簡單、價格便宜。',
    fact: '穿白衣服比穿黑衣服涼，也是同樣的道理。',
    related: ['greenRoof', 'heatIsland'],
  },
  warming: {
    title: '暖化情境',
    body: '科學家用電腦模擬「如果全世界未來這樣排放，地球會變多熱」。IPCC（聯合國政府間氣候變遷專門委員會）用幾種情境來比較：大家一起大幅減碳是「低排放」，延續現在的做法是「中排放」，大量使用化石燃料是「高排放」。',
    fact: '依照 IPCC 第六次評估報告，到 2081–2100 年，全球平均溫度會比工業化前高約 1.8 °C（低排放）、2.7 °C（中排放）或 4.4 °C（高排放）。',
    related: ['mitigation', 'adaptation', 'greenhouse'],
  },
  mitigation: {
    title: '減緩',
    body: '想辦法「少排放」溫室氣體，讓地球不要變得那麼熱。例如改用再生能源、多搭大眾運輸、節約用電。減緩需要全世界一起做，才看得到效果。',
    related: ['adaptation', 'netZero'],
  },
  adaptation: {
    title: '調適',
    body: '氣候已經在改變，城市要「準備好」面對更熱的夏天、更強的大雨和颱風。例如多種樹降溫、蓋滯洪池防淹水、準備備用水源。調適可以保護城市裡的人，就算全世界還沒減碳成功也有用。',
    related: ['mitigation', 'heatIsland', 'resilience', 'spongeCity'],
  },

  // ---------------- 階段六：極端天氣與調適 ----------------
  extremeWeather: {
    title: '極端天氣',
    body: '比平常少見、而且很強烈的天氣，例如連續好幾天的高溫、一天下好幾百毫米的大雨、強烈颱風、好幾個月都不下雨。全球暖化讓空氣更熱、能裝更多水氣，所以很多極端天氣變得更常發生、也更強。',
    fact: '依 IPCC 第六次評估報告：全球比工業化前熱 2 °C 時，原本「十年一遇」的極端高溫大約會變成十年 5.6 次；十年一遇的強降雨約 1.7 次，而且雨量多約 14%。',
    related: ['heatwave', 'typhoon', 'heavyRain', 'drought', 'warming'],
  },
  typhoon: {
    title: '颱風',
    body: '在溫暖海面上形成的強大熱帶氣旋，會帶來強風、大雨，靠近海岸時還會讓海水面升高（暴潮）。強風會吹斷電線、吹壞屋頂；大雨會讓河水暴漲、低窪地區淹水。',
    fact: '科學家評估：全球暖化不一定讓颱風變多，但強烈颱風的比例會增加，颱風帶來的雨也會更多（全球升溫 2 °C 時約多 14%）。遊戲裡颱風次數不變，但強颱與雨量會隨年代增加。',
    related: ['urbanFlood', 'undergroundGrid', 'seawall', 'shelter'],
  },
  heavyRain: {
    title: '豪雨',
    body: '短時間下非常多的雨。中央氣象署把 24 小時累積雨量 200 毫米以上叫做「大豪雨」。5、6 月的梅雨鋒面和夏天的颱風，是台灣豪雨最常見的原因。',
    related: ['urbanFlood', 'runoff', 'spongeCity'],
  },
  urbanFlood: {
    title: '都市淹水',
    body: '雨下得太快、太多，地面吸不了、下水道排不掉，水就會往低的地方流，在低窪處積起來。水泥、柏油鋪面越多，雨水越不能滲進地下，越容易淹水。河水暴漲漫過河岸、颱風把海水推上岸，也會造成淹水。',
    fact: '遊戲用「淹水潛勢」圖層顯示：如果一天下 350 毫米的雨，哪裡會淹。真實的城市也會公布淹水潛勢圖，讓大家知道哪裡要特別小心。',
    related: ['runoff', 'detentionPond', 'pumpStation', 'levee', 'spongeCity'],
  },
  runoff: {
    title: '地表逕流',
    body: '雨落到地面後，沒有滲進土裡、也沒有被植物接住，而是在地面上流動的水。草地和森林會讓大部分的雨滲進地下；柏油路、屋頂幾乎全部變成逕流，一下子流進下水道和低處。',
    diagram: 'sponge',
    related: ['spongeCity', 'permeablePaving', 'urbanFlood'],
  },
  spongeCity: {
    title: '海綿城市',
    body: '讓城市像海綿一樣：下雨時先把雨水吸起來、存起來，再慢慢排出去或留著用。透水鋪面、雨水花園、綠屋頂、滯洪池、雨水回收，都是海綿城市的做法。',
    fact: '海綿城市不只防淹水：存下來的水可以澆花、沖馬桶，濕潤的土地和植物也能讓城市變涼。',
    related: ['permeablePaving', 'rainGarden', 'greenRoof', 'detentionPond', 'rainHarvest', 'runoff'],
  },
  detentionPond: {
    title: '滯洪池',
    body: '一個比地面低的大池子。下大雨時，附近的雨水先流進池子暫時存起來，等河水退了再慢慢排出去，下游就不會一下子淹水。平常沒下雨時，滯洪池可以是公園或運動場。',
    fact: '遊戲裡一座滯洪池約可存 6 萬立方公尺的水，差不多是 24 座標準游泳池。',
    related: ['urbanFlood', 'spongeCity', 'pumpStation'],
  },
  pumpStation: {
    title: '抽水站',
    body: '用大型抽水機把低窪地區的積水抽到河裡或海裡。抽水站需要電，所以颱風把電線吹斷時，抽水站也可能停擺——這就是為什麼防洪也要搭配供電韌性。',
    related: ['urbanFlood', 'undergroundGrid', 'roofSolar'],
  },
  levee: {
    title: '堤防',
    body: '沿著河岸堆高的土堤，河水暴漲時可以擋住河水，不讓它漫進城市。堤防要連成一整排才有用，中間缺一段，水就會從缺口流進來。',
    related: ['urbanFlood', 'seawall'],
  },
  seawall: {
    title: '海堤',
    body: '沿著海岸蓋的堅固牆，可以擋住颱風帶來的暴潮，以及因為海平面上升而越來越高的漲潮。不過海堤很貴，也會改變海岸的生態，所以有些地方會選擇把低地留給濕地，把房子蓋在比較高的地方。',
    related: ['seaLevel', 'typhoon', 'levee'],
  },
  stormDrain: {
    title: '雨水下水道',
    body: '道路底下的大水管，把路面的雨水收集起來，排到河裡或海裡。下水道的大小決定一場雨能排掉多少水；雨下得比設計的還大，水就會冒出來淹到路面。',
    related: ['urbanFlood', 'runoff'],
  },
  permeablePaving: {
    title: '透水鋪面',
    body: '有很多小孔或縫隙的鋪面，雨水可以穿過去滲進地下，不會全部留在路面。泥土保持濕潤，水分蒸發時還能帶走一些熱，所以也有一點降溫效果。',
    related: ['spongeCity', 'runoff', 'heatIsland'],
  },
  rainGarden: {
    title: '雨水花園',
    body: '比地面稍微低一點的花圃，種著耐濕又耐旱的植物。下雨時，附近的雨水先流進來，被植物和土壤慢慢吸收，減少流到路上的水。',
    related: ['spongeCity', 'runoff'],
  },
  rainHarvest: {
    title: '雨水回收',
    body: '在建築的屋頂收集雨水，存在水塔或地下水槽裡，用來沖馬桶、澆花、洗地。這樣下雨時少一些水流到地面，乾旱時也能少用一點自來水。',
    related: ['drought', 'spongeCity', 'recycledWater'],
  },
  drought: {
    title: '乾旱',
    body: '很長一段時間雨下得比平常少很多，水庫的水越來越少，河流變小，甚至需要限水。台灣雖然雨量多，但雨集中在夏天，而且山高河短，水很快流進海裡，所以梅雨或颱風不來時，就可能缺水。',
    fact: '2021 年台灣遇到數十年來最嚴重的乾旱之一，中南部多個水庫蓄水率降到一成以下，部分地區實施分區輪流供水。',
    related: ['waterRestriction', 'recycledWater', 'desalination', 'rainHarvest'],
  },
  waterRestriction: {
    title: '限水',
    body: '水庫的水不夠時，政府會依嚴重程度實施限水。遊戲參考水利署的燈號：黃燈是夜間減壓供水，橙燈是減少供應工業用水，紅燈是分區輪流供水（有些日子停水）。',
    related: ['drought', 'recycledWater'],
  },
  recycledWater: {
    title: '再生水',
    body: '把家庭和工廠用過的污水，經過好幾道處理變乾淨，再拿給工廠冷卻、沖洗或澆灌使用。污水每天都有，所以不怕沒下雨，是很穩定的水源。缺點是處理需要用電。',
    related: ['drought', 'desalination', 'waterRestriction'],
  },
  desalination: {
    title: '海水淡化',
    body: '把海水裡的鹽分去掉，變成可以用的淡水。常用的方法是用高壓把海水擠過很細的薄膜。好處是不受乾旱影響；代價是非常耗電（耗電就可能增加碳排放），還會排出很鹹的濃鹽水。',
    fact: '海水淡化每生產 1 噸淡水，大約要用 3 到 4 度電。遊戲裡一座海水淡化廠每月約用 160 MWh，差不多是 900 位居民一個月的用電。',
    related: ['drought', 'recycledWater', 'co2'],
  },
  undergroundGrid: {
    title: '電線地下化',
    body: '把電線埋到地底下的管道裡。颱風的強風吹不到，比較不會斷電，街景也比較整齊。缺點是施工很貴，維修時要挖開道路。',
    related: ['typhoon', 'roofSolar', 'resilience'],
  },
  roofSolar: {
    title: '屋頂光電與儲電',
    body: '在建築屋頂裝太陽能板，再搭配家用電池。平常白天自己發電，減少碳排放；颱風或用電尖峰停電時，這棟建築還能靠電池繼續用電，像一座小型的「微電網」。',
    related: ['undergroundGrid', 'resilience', 'renewable'],
  },
  heatwave: {
    title: '熱浪',
    body: '連續好幾天異常的高溫。熱浪時大家冷氣開更多，用電可能超過電廠能供應的量而停電；長者、小朋友和在戶外工作的人也比較容易中暑。熱島嚴重的市中心，熱浪時升溫最多。',
    fact: '中央氣象署的高溫資訊：氣溫 36 °C 以上發布黃色燈號，38 °C 以上是橙色，連續三天 38 °C 以上是紅色。',
    related: ['heatIsland', 'coolingCenter', 'extremeWeather'],
  },
  coolingCenter: {
    title: '涼爽中心',
    body: '熱浪時開放給民眾避暑的地方，例如圖書館、活動中心，有冷氣、飲水和座位。特別照顧家裡沒有冷氣的長者和需要幫忙的人。',
    related: ['heatwave', 'heatIsland'],
  },
  shelter: {
    title: '避難中心',
    body: '淹水、颱風、地震時，讓需要撤離的居民暫時居住的地方，通常是學校或活動中心。避難中心要蓋在不容易淹水的地方，而且要離住宅區夠近。',
    related: ['urbanFlood', 'typhoon', 'earlyWarning'],
  },
  earlyWarning: {
    title: '災害預警',
    body: '用氣象雷達、衛星、雨量站和電腦模擬，提早預測颱風、豪雨或熱浪，再透過手機、廣播通知大家準備。預報不可能百分之百準確，但越早知道，越能減少損失。',
    fact: '遊戲中，沒有預警中心時大約一成的極端天氣不會被預報到，而且比較常「虛驚一場」。',
    related: ['forecast', 'shelter', 'resilience'],
  },
  forecast: {
    title: '天氣預報',
    body: '根據現在的大氣狀況，推測未來的天氣。預報會說「可能」、「很可能」，是因為大氣很複雜，總有一些不確定。看預報的重點不是「一定會怎樣」，而是「要不要先做準備」。',
    related: ['earlyWarning', 'extremeWeather'],
  },
  seaLevel: {
    title: '海平面上升',
    body: '全球暖化讓海水受熱膨脹，陸地上的冰河和冰原也在融化，所以海平面慢慢升高。海岸低地會越來越常在漲潮時淹水，最後可能永遠泡在海裡。',
    fact: 'IPCC 評估：到 2100 年，全球平均海平面在中排放情境下約上升 0.56 公尺。遊戲預設把海平面上升加速 3 倍，讓你在幾十年的遊戲時間內就看得到變化，這不是真實的速度。',
    related: ['seawall', 'warming', 'adaptation'],
  },
  resilience: {
    title: '氣候韌性',
    body: '城市遇到極端天氣時「撐得住、恢復得快」的能力。遊戲的氣候韌性指數看六件事：住宅區淹水風險、本地備用水源、備用電力、避難中心、涼爽中心、災害預警。',
    related: ['adaptation', 'spongeCity', 'earlyWarning'],
  },

  // ---------------- 階段七：AI 與智慧城市 ----------------
  dataCenter: {
    title: 'AI 資料中心',
    body: '放了很多台電腦（伺服器）的大建築，24 小時不停地運算，讓 AI 可以回答問題、辨認影像、預測天氣。它能帶來稅收和高薪工作，但非常耗電、冷卻要用很多水，還會排出大量廢熱。',
    fact: '國際能源總署（IEA）估計，全世界資料中心的用電量正在快速增加，AI 是主要原因之一。遊戲裡一座縮小版的資料中心，每月就用掉約 600 多萬度電，比一座數千人小鎮的用電還多。',
    related: ['compute', 'pue', 'liquidCooling', 'wasteHeat', 'greenPower', 'aiAdvisor'],
  },
  compute: {
    title: '算力',
    body: '電腦能做多少計算的能力。遊戲裡，資料中心提供算力，智慧號誌、智慧電網、AI 氣象預警、AI 水資源管理都要用算力才能運作；算力不夠時，這些設施只能發揮一部分效果。',
    related: ['dataCenter', 'smartSignals', 'smartGrid'],
  },
  pue: {
    title: '電力使用效率（PUE）',
    body: '資料中心的總用電 ÷ 電腦本身的用電。PUE 是 1.5 代表每 1 度電給電腦用，另外還要 0.5 度電給冷卻和其他設備。數字越接近 1 越省電。熱浪時冷卻變吃力，PUE 會變高。',
    related: ['dataCenter', 'liquidCooling'],
  },
  liquidCooling: {
    title: '液冷技術',
    body: '用封閉管路裡的液體直接帶走晶片的熱，比吹冷氣、灑水蒸發的方式省電，也幾乎不用消耗冷卻水，乾旱時比較不怕限水。',
    related: ['dataCenter', 'pue', 'drought'],
  },
  wasteHeat: {
    title: '廢熱回收',
    body: '電腦運算時產生的熱，通常直接排到戶外。如果用管路把熱收集起來，可以拿去加熱附近住宅的熱水，少燒一些瓦斯，也讓周圍不會那麼熱。北歐有些城市用資料中心的廢熱替整區住宅供暖。',
    related: ['dataCenter', 'heatIsland'],
  },
  greenPower: {
    title: '綠電契約',
    body: '用電大戶和風力、太陽能發電業者簽約，買下他們發的電。電還是從同一個電網送過來，但多出來的再生能源發電，讓整個電網的碳排放變少。',
    related: ['dataCenter', 'renewable'],
  },
  smartSignals: {
    title: 'AI 智慧號誌',
    body: '用攝影機和感測器偵測各路口的車流，由 AI 即時調整紅綠燈的秒數，讓車子少停幾次。塞車變少，走走停停浪費的油和排放也變少。',
    fact: '國外自適應號誌的試辦結果，旅行時間與排放約可減少一到兩成；但車子變順，也可能讓更多人選擇開車。',
    related: ['commute', 'transit', 'compute'],
  },
  smartGrid: {
    title: 'AI 智慧電網',
    body: '用 AI 預測明天會有多少太陽能和風力，並請熱水器、電動車這類「晚一點用也沒關係」的設備，改在電多的時候用電。這叫做「需量反應」，可以減少停電，也減少再生能源用不完被浪費。',
    related: ['renewable', 'storage', 'compute'],
  },
  aiWeather: {
    title: 'AI 氣象預警',
    body: '用 AI 分析大量的雷達、衛星和觀測資料，更早、更準地預測極端天氣。遊戲裡可以提早兩個月看到可能的天氣，災害損失再減少一些。',
    related: ['forecast', 'earlyWarning', 'compute'],
  },
  aiWater: {
    title: 'AI 水資源管理',
    body: '用智慧水表和 AI 分析水管裡的流量與壓力，找出哪裡在漏水。台灣自來水的漏水率約一成多，找到並修好漏水，就等於多出一個小水庫。',
    related: ['drought', 'recycledWater', 'compute'],
  },
  aiAdvisor: {
    title: 'AI 的建議從哪裡來？',
    body: '遊戲裡的「AI 市政顧問」其實是寫好規則的程式：每位顧問只被設定了一個目標，所以經濟顧問會叫你引進資料中心、減碳顧問會叫你先不要。真正的 AI 也一樣，它的建議取決於它被設定要達成什麼、用了哪些資料。做決定的時候，要問：它在乎什麼？沒考慮到什麼？',
    related: ['dataCenter', 'mitigation', 'adaptation'],
  },
};
