// 極端天氣與氣候調適係數
//
// 【資料來源】
//   IPCC AR6 WG1 決策者摘要圖 SPM.6（相對 1850–1900，「十年一遇」事件的發生倍數）：
//     極端高溫  +1 °C 2.8 倍、+1.5 °C 4.1 倍、+2 °C 5.6 倍、+4 °C 9.4 倍；強度 +1.2 / +1.9 / +2.6 / +5.1 °C
//     （五十年一遇高溫 8.6 / 13.9 / 39.2 倍，已與其他轉載資料交叉核對）
//     強降雨    +1 °C 1.3 倍、+1.5 °C 1.5 倍、+2 °C 1.7 倍、+4 °C 2.7 倍；雨量 +6.7% / +10.5% / +14% / +30.2%
//     農業與生態乾旱（變乾的地區）+1 °C 1.7 倍、+1.5 °C 2.0 倍、+2 °C 2.4 倍、+4 °C 4.1 倍
//   IPCC AR6 WG1 第 11 章表 11.2（熱帶氣旋，相對現今氣候）：
//     強烈颱風（4–5 級）比例 +1.5 °C 約 +10%、+2 °C 約 +13%、+4 °C 約 +20%
//     颱風降雨強度     +1.5 °C 約 +11%、+2 °C 約 +14%、+4 °C 約 +28%
//   颱風總數：AR6 評估全球熱帶氣旋總數「不會增加或略減」，所以遊戲維持次數不變（設計決策 Q5）。
//
// 【簡化說明】
//   1. 遊戲以 2025 年的氣候為「現在」，事件機率 = 現在的機率 × 倍數(當年升溫) ÷ 倍數(2025 年升溫)。
//   2. 每月機率是為了教學而設定的「遊戲頻率」：大約每年遇到 1 次颱風、1 次強降雨、0.6 次熱浪，
//      乾旱約 7–8 年一次（台灣近年 2002、2015、2021 年都有嚴重缺水）。不是真實氣象統計。
//   3. 金額是遊戲單位（千元），只保持設施之間、設施與災損之間的相對關係。

export const AR6 = {
  hotFreq: [[0, 1], [1, 2.8], [1.5, 4.1], [2, 5.6], [4, 9.4]],
  hotIntensity: [[0, 0], [1, 1.2], [1.5, 1.9], [2, 2.6], [4, 5.1]],
  rainFreq: [[0, 1], [1, 1.3], [1.5, 1.5], [2, 1.7], [4, 2.7]],
  rainIntensityPct: [[0, 0], [1, 6.7], [1.5, 10.5], [2, 14], [4, 30.2]],
  droughtFreq: [[0, 1], [1, 1.7], [1.5, 2.0], [2, 2.4], [4, 4.1]],
  // 下面兩項是「相對現今」，現今約 +1 °C
  tcStrongSharePct: [[1, 0], [1.5, 10], [2, 13], [4, 20]],
  tcRainPct: [[1, 0], [1.5, 11], [2, 14], [4, 28]],
};

export function interpPts(points, x) {
  if (x <= points[0][0]) return points[0][1];
  for (let k = 1; k < points.length; k++) {
    if (x <= points[k][0]) {
      const [x0, y0] = points[k - 1], [x1, y1] = points[k];
      return y0 + ((y1 - y0) * (x - x0)) / (x1 - x0);
    }
  }
  // 超出表格：沿最後一段的斜率外推
  const [x0, y0] = points[points.length - 2], [x1, y1] = points[points.length - 1];
  return y1 + ((y1 - y0) * (x - x1)) / (x1 - x0);
}

// 現在（2025 年）的每月機率
export const EVENT_P = {
  typhoon: [0, 0, 0, 0, 0.02, 0.05, 0.2, 0.3, 0.25, 0.08, 0.02, 0],
  heavyRain: [0, 0, 0.02, 0.05, 0.15, 0.25, 0.1, 0.12, 0.08, 0.03, 0, 0],
  heatwave: [0, 0, 0, 0.02, 0.06, 0.12, 0.2, 0.18, 0.08, 0.02, 0, 0],
  // 乾旱：梅雨不來（5 月開始）、夏天沒有颱風帶來雨水（7–8 月開始），或秋冬持續少雨
  drought: [0.02, 0, 0, 0, 0.05, 0, 0.03, 0.02, 0, 0.02, 0, 0],
};
export const MAX_MONTH_P = 0.85;

// 颱風：依中央氣象署的強度分級（近中心最大風速）
export const TYPHOON = {
  share: { mild: 0.5, moderate: 0.35, strong: 0.15 }, // 現在的比例
  cats: {
    mild: { name: '輕度颱風', windMs: [17, 32], rain: [150, 300], surgeM: 0.3, lineP: 0.01, bldP: 0.002, turbineDamageP: 0 },
    moderate: { name: '中度颱風', windMs: [33, 50], rain: [250, 450], surgeM: 0.6, lineP: 0.05, bldP: 0.01, turbineDamageP: 0.05 },
    strong: { name: '強烈颱風', windMs: [51, 62], rain: [350, 650], surgeM: 1.0, lineP: 0.12, bldP: 0.03, turbineDamageP: 0.25 },
  },
  windCutoutMs: 25, // 風機超過這個風速要停機保護
  daysAffected: 2,
};

export const HEAVY_RAIN = { rain: [130, 300], name: '豪雨' };
export const HEATWAVE = { days: [5, 12], baseDT: 2.0, name: '熱浪', thresholdC: 36, // 中央氣象署高溫資訊：36 °C 以上發布黃色燈號
  // 熱浪和熱島會互相加強：越熱的地方，熱浪時升溫越多（Li & Bou-Zeid 2013 的觀測）
  uhiSynergy: 0.12,
  vulnerableShare: 0.2, // 長者、幼兒、戶外工作者約占兩成
};
export const DROUGHT = { months: [6, 10], rainMult: 0.25, name: '乾旱' };

// ---------------- 淹水模型 ----------------
// 逕流係數：落在地面的雨有多少比例變成地面逕流（其餘滲入地下或被植物留住）
// 初期損失（mm）：雨剛開始下時，被土壤吸收、被植物接住、填滿地面小凹處的雨量。自然地面大、鋪面小。
export const INITIAL_LOSS = { natural: 70, forest: 110, sand: 90, mudflat: 30, paved: 5, lot: 15, park: 60 };
// 積水後一兩天內還會繼續滲進地下的量（公尺）：泥土地面滲得多，水泥地面幾乎不滲
export const PONDED_INFIL_M = { natural: 0.15, forest: 0.2, sand: 0.25, mudflat: 0.05, paved: 0, lot: 0.02, park: 0.12, permeable: 0.08, rainGarden: 0.2 };
export const RUNOFF = {
  road: 0.9,
  lotLight: 0.7, lotDense: 0.85, // 已開發的分區
  lotEmpty: 0.45,               // 劃了分區但還是空地
  plant: 0.8,                   // 電廠廠區、水泥地
  grass: 0.35, forest: 0.15, sand: 0.2, mudflat: 0.5, park: 0.2,
  // 海綿城市設施
  permeableMult: 0.45, // 透水鋪面讓逕流變成原本的 45%
  greenRoofMult: 0.7,  // 綠屋頂吸住一部分雨水
  rainGardenStoreMm: 60, rainGardenMult: 0.5,
  rainHarvestStoreMm: 25,
};
// 雨水下水道：靠近道路的格子有基本排水能力（一場雨可以排掉的雨量，公釐）
// 台南的雨水下水道約以每小時 80 毫米左右設計；颱風、豪雨的雨會下一兩天，最大的雨集中在幾個小時。
// 簡化成「一場雨可以排掉約 200 毫米」，擴建後約 360 毫米。
// 下水道的進水口也會收集從別處流過來的水，所以本格沒用完的排水能力，可以排掉流進來的積水。
export const DRAIN = { baseMm: 200, upgradedMm: 360, reach: 2 };
export const FLOOD = {
  iterations: 140,
  floodedCm: 10,        // 超過 10 公分算淹水
  evacuateCm: 50,       // 超過 50 公分要撤離
  designStormMm: 350,   // 淹水潛勢圖層用的「設計暴雨」
  // 河川水位：一場雨超過 150 mm 後，每 100 mm 上升約 1.2 m
  riverStageStartMm: 150, riverStagePer100Mm: 0.8, riverStageMaxM: 2.5,
  riverSlopeCmPerTile: 10, // 洪水往外漫的水面坡降（溢出的水量有限，離河越遠越淺）
  tideHighM: 0.5,        // 每月大潮的高潮位
  kingTideExtraM: 0.15,  // 8–10 月的大潮再高一點
  damageMaxFrac: 0.75,
};
// 淹水深度與建築損失比例（簡化的「深度—損失曲線」）
export function depthDamage(m) {
  if (m < FLOOD.floodedCm / 100) return 0;
  return Math.min(FLOOD.damageMaxFrac, 0.12 + 0.36 * m);
}

// 每格建築的價值（千元），用來算災損
export const BUILDING_VALUE = {
  r: { light: 120, dense: 360 },
  c: { light: 150, dense: 400 },
  i: { light: 200, dense: 450 },
};
export const PUBLIC_SHARE_OF_LOSS = 0.4; // 市府負擔的重建與救助（其餘由民眾與保險負擔）
export const REPAIR = { powerlinePerTile: 6, roadPerTile: 2 };
export const WARNING_DAMAGE_CUT = 0.15; // 有預警系統，居民提早準備，損失少 15%

// ---------------- 供水 ----------------
// 城市先由「區域水庫」供水；蓄水率看雨量變化。用水量依台灣的平均值簡化。
export const WATER = {
  perResidentM3Day: 0.25,     // 每人每天約 250 公升
  perCommercialJobM3Day: 0.08,
  perIndustrialJobM3Day: 0.4, // 工業最耗水
  // 區域水庫每月的進水（乘上本月雨量 ÷ 平年雨量）與出水，單位：蓄水率
  inflow: [0.02, 0.02, 0.03, 0.04, 0.08, 0.18, 0.15, 0.2, 0.1, 0.03, 0.02, 0.02],
  outflow: 0.075,
  startStorage: 0.8,
  // 經濟部水利署的限水燈號（簡化）
  levels: [
    { id: 0, name: '正常供水', color: '#3cc87a', below: 1.01, resCut: 0, indCut: 0 },
    { id: 1, name: '黃燈：夜間減壓供水', color: '#f2c94c', below: 0.5, resCut: 0.03, indCut: 0.05 },
    { id: 2, name: '橙燈：減量供應工業', color: '#f2994a', below: 0.35, resCut: 0.06, indCut: 0.2 },
    { id: 3, name: '紅燈：分區輪流供水', color: '#eb5757', below: 0.2, resCut: 0.2, indCut: 0.35 },
  ],
  roofCatchM2: 1500,          // 每棟建築可收集雨水的屋頂面積
  rainHarvestMaxShare: 0.25,  // 雨水回收最多供應這棟建築 1/4 的用水（沖馬桶、澆花）
};

// ---------------- 調適設施 ----------------
// against：對抗哪種極端天氣；effects：效果；side：副作用（畫面上會顯示）
export const ADAPT = {
  detentionPond: {
    id: 'detentionPond', name: '滯洪池', kind: 'adapt', footprint: [2, 2], cost: 1500, upkeep: 4, group: 'flood',
    capacityM3: 60000, catchR: 5,
    against: ['豪雨', '颱風'], effects: '下大雨時先把附近 500 公尺的雨水存起來，慢慢排掉。平時可以當公園。',
    side: ['占用土地'], wiki: 'detentionPond',
  },
  pumpStation: {
    id: 'pumpStation', name: '抽水站', kind: 'adapt', footprint: [1, 1], cost: 800, upkeep: 5, group: 'flood',
    pumpM3: 40000, r: 6, powerMWh: 8,
    against: ['豪雨', '颱風'], effects: '把低窪處的積水抽到河裡或海裡（半徑 600 公尺）。',
    side: ['需要電，停電時不能運作'], wiki: 'pumpStation',
  },
  recycledWater: {
    id: 'recycledWater', name: '再生水廠', kind: 'adapt', footprint: [2, 2], cost: 2500, upkeep: 10, group: 'water',
    supplyM3Day: 900, powerMWh: 16,
    against: ['乾旱'], effects: '把用過的水處理乾淨，再給工廠和沖洗用，不怕沒下雨。',
    side: ['需要電'], wiki: 'recycledWater',
  },
  desalination: {
    id: 'desalination', name: '海水淡化廠', kind: 'adapt', footprint: [2, 2], cost: 6000, upkeep: 18, group: 'water',
    supplyM3Day: 1500, powerMWh: 160, needsSea: true,
    against: ['乾旱'], effects: '把海水變成淡水，乾旱時也能穩定供水。',
    side: ['非常耗電（間接增加碳排放）', '濃鹽水排回海中', '必須蓋在海邊'], wiki: 'desalination',
  },
  shelter: {
    id: 'shelter', name: '避難中心', kind: 'adapt', footprint: [1, 1], cost: 600, upkeep: 2, group: 'safety',
    capacity: 600, r: 8,
    against: ['颱風', '豪雨', '海水倒灌'], effects: '淹水或颱風時，附近 800 公尺的居民可以到這裡避難。',
    side: [], wiki: 'shelter',
  },
  coolingCenter: {
    id: 'coolingCenter', name: '涼爽中心', kind: 'adapt', footprint: [1, 1], cost: 400, upkeep: 3, group: 'safety',
    capacity: 400, r: 7, powerMWh: 6,
    against: ['熱浪'], effects: '熱浪時開放有冷氣的空間，照顧附近 700 公尺的長者和需要的人。',
    side: ['熱浪時用電增加'], wiki: 'coolingCenter',
  },
  warningCenter: {
    id: 'warningCenter', name: '災害預警中心', kind: 'adapt', footprint: [1, 1], cost: 1500, upkeep: 8, group: 'safety',
    unique: true,
    against: ['所有極端天氣'], effects: '預報更準確、提早通知市民準備，災害損失減少 15%。',
    side: ['一座城市只需要一座'], wiki: 'earlyWarning',
  },
};

// 線狀與覆蓋型設施（每格價格）
export const ADAPT_LINE = {
  levee: { name: '堤防', cost: 30, upkeep: 0.05, against: ['河川氾濫'], desc: '沿著河岸築高的土堤，河水暴漲時擋住不溢出。', wiki: 'levee' },
  seawall: { name: '海堤', cost: 60, upkeep: 0.1, against: ['暴潮', '海平面上升'], desc: '沿著海岸的混凝土牆，擋住颱風暴潮與漲潮。', wiki: 'seawall' },
  drain: { name: '下水道擴建', cost: 15, upkeep: 0.03, against: ['豪雨'], desc: '把道路下的雨水下水道加大，附近 200 公尺排水能力加倍。', wiki: 'stormDrain' },
  permeable: { name: '透水鋪面', cost: 4, against: ['豪雨', '熱浪'], desc: '讓雨水滲進地下的鋪面，可以鋪在道路或建築基地。', wiki: 'permeablePaving' },
  rainGarden: { name: '雨水花園', cost: 3, against: ['豪雨'], desc: '略低於地面的花圃，下雨時先接住雨水再慢慢滲入。', wiki: 'rainGarden' },
  rainHarvest: { name: '雨水回收', cost: 5, against: ['乾旱', '豪雨'], desc: '在建築設儲水槽，收集屋頂的雨水沖馬桶、澆花。', wiki: 'rainHarvest' },
  roofSolar: { name: '屋頂光電＋儲電', cost: 40, against: ['颱風停電', '熱浪停電'], desc: '屋頂太陽能板加家用電池，停電時這棟還能用電。', wiki: 'roofSolar' },
  undergroundGrid: { name: '電線地下化', cost: 20, upkeep: 0.01, against: ['颱風'], desc: '把電線埋到地下，颱風強風吹不斷。', wiki: 'undergroundGrid' },
};
export const ROOF_SOLAR_MW = 0.12; // 每棟屋頂光電約 120 kW（約 1,200 平方公尺屋頂）
