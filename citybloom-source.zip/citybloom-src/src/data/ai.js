// AI 資料中心與智慧城市係數
//
// 【資料與簡化】
//   - 資料中心規模縮成「城市級」（與電廠同樣約 1/10–1/15）：IT 用電 6 MW。
//     真實的大型 AI 資料中心常在 100 MW 以上，一座就可能比一整座中型城市還耗電。
//   - PUE（電力使用效率）＝ 總用電 ÷ IT 用電。氣冷（蒸發冷卻）約 1.4–1.5；液冷約 1.1–1.2。
//   - 用水：蒸發式冷卻每度電約 1.8 公升（WUE ≈ 1.8 L/kWh，業界常見值）；封閉式液冷大幅減少。
//   - 熱浪時冷卻變吃力，PUE 上升；限水時蒸發式冷卻的資料中心要降載。
//   - 智慧號誌：自適應號誌控制在實際案例中可減少約 1–2 成的旅行時間與排放（例如匹茲堡 Surtrac 試辦）；
//     遊戲取保守值：道路容量 +15%；塞車時走走停停多出的排放少六成，一般路段少 5%。
//   - 智慧電網：預測再生能源並調整可延後的用電（需量反應），把一部分用電移到電多的時段。
//   - AI 水資源管理：偵測漏水（台灣自來水的漏水率約一成多），用水量減少 10%。
// 金額為遊戲單位（千元）。

export const DATACENTER = {
  id: 'dataCenter', name: 'AI 資料中心', footprint: [3, 3],
  cost: 2000,            // 市府負擔的整地、道路、電力接線（建築本身由企業出資）
  itMW: 6,
  pue: { air: 1.45, liquid: 1.15 },
  heatwavePueAdd: 0.12,  // 熱浪時冷卻更吃力
  waterM3PerMWh: { air: 1.8, liquid: 0.25 },
  taxPerMonth: 700,      // 每月稅收（70 萬）
  jobs: 120,             // 高薪工作（工程師、維運）
  commercialBoost: 350,  // 高薪員工消費，讓商業需求增加（相當於多 350 個商業工作的需求）
  compute: 100,          // 提供給智慧城市設施的算力（遊戲單位）
  heat: { self: 4.0, r: 4, c: 2.4 }, // 排出的廢熱（地表溫度加成）
  droughtThrottle: 0.3,  // 橙燈以上限水時，蒸發式冷卻的資料中心降載 30%
  upgrades: {
    green: { name: '遠端綠電契約', cost: 1500, desc: '和城外的風電、太陽能簽約，替資料中心買綠電（約供應六成用電）。', windMW: 12, solarMW: 16 },
    liquid: { name: '液冷技術', cost: 1200, desc: '用封閉的液體管路直接冷卻晶片：省電，也幾乎不用蒸發冷卻水。' },
    heatRecovery: { name: '廢熱回收', cost: 800, desc: '把伺服器的熱回收來加熱附近住宅的熱水，少燒瓦斯，也少排一半的熱到戶外。', r: 8, gasCut: 0.3 },
  },
  side: ['用電非常多', '冷卻要用很多水', '排出廢熱，周圍變熱'],
};

export const SMART = {
  aiSignals: {
    id: 'aiSignals', name: 'AI 智慧號誌', footprint: [1, 1], cost: 600, upkeep: 4, compute: 20, powerMWh: 3,
    capacityBoost: 0.15,
    effects: '依即時車流調整紅綠燈，塞車變少、走走停停的排放減少。', wiki: 'smartSignals',
  },
  aiGrid: {
    id: 'aiGrid', name: 'AI 智慧電網', footprint: [1, 1], cost: 900, upkeep: 5, compute: 30, powerMWh: 3,
    flexShare: 0.12,
    effects: '預測太陽能與風力，把可以延後的用電（熱水器、電動車充電）移到電多的時段，減少停電與棄電。', wiki: 'smartGrid',
  },
  aiWeather: {
    id: 'aiWeather', name: 'AI 氣象預警', footprint: [1, 1], cost: 800, upkeep: 4, compute: 25, powerMWh: 2,
    lossCut: 0.1,
    effects: '用 AI 分析雷達與衛星資料：提早兩個月看到可能的極端天氣，預報更準，災害損失再少 10%。', wiki: 'aiWeather',
  },
  aiWater: {
    id: 'aiWater', name: 'AI 水資源管理', footprint: [1, 1], cost: 700, upkeep: 4, compute: 15, powerMWh: 2,
    demandCut: 0.1,
    effects: '智慧水表與 AI 偵測漏水，城市用水量減少 10%。', wiki: 'aiWater',
  },
};
export const SMART_TYPES = Object.keys(SMART);
