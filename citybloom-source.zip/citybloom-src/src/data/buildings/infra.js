// 基礎設施與工具的價格（千元，遊戲單位）

export const COSTS = {
  road: 10,          // 每格
  powerline: 4,
  zone: 5,
  clearForest: 3,    // 在樹林上建設要先清除
  bulldoze: 1,
  terrain: 0,        // 地形工具（財政系統在階段八才接上）
};

export const UPKEEP = {
  roadPerTile: 0.05, // 每月
  powerlinePerTile: 0.01,
};

// 簡易稅收（階段八會換成完整預算系統）：每人或每個工作每月繳的錢，稅率 7% 時
export const TAX = {
  perResident: 0.08,
  perJob: 0.06,
  baseRate: 7,
};
