// 分區與自動成長的建築
// 顏色依台灣都市計畫圖慣例：住宅區黃色、商業區紅色、工業區紫色

import { ZONE } from '../../core/constants.js';

export const ZONE_INFO = {
  [ZONE.R1]: { kind: 'r', dense: false, name: '輕度住宅區', short: '住宅', maxLevel: 2 },
  [ZONE.R2]: { kind: 'r', dense: true, name: '高密度住宅區', short: '住宅', maxLevel: 4 },
  [ZONE.C1]: { kind: 'c', dense: false, name: '輕度商業區', short: '商業', maxLevel: 2 },
  [ZONE.C2]: { kind: 'c', dense: true, name: '高密度商業區', short: '商業', maxLevel: 4 },
  [ZONE.I1]: { kind: 'i', dense: false, name: '輕度工業區', short: '工業', maxLevel: 2 },
  [ZONE.I2]: { kind: 'i', dense: true, name: '高密度工業區', short: '工業', maxLevel: 4 },
};

// 每一格（1 公頃）在各等級的人口或工作數
// 參考：低密度住宅約每公頃 50–100 人；高密度公寓區可達每公頃 300–500 人
export const OCCUPANCY = {
  r: { light: [0, 40, 90], dense: [0, 90, 180, 300, 450] },
  c: { light: [0, 20, 45], dense: [0, 60, 120, 200, 320] },
  i: { light: [0, 30, 60], dense: [0, 70, 130, 200, 280] },
};

export function occupancy(zone, level) {
  const z = ZONE_INFO[zone];
  if (!z || level <= 0) return 0;
  const arr = OCCUPANCY[z.kind][z.dense ? 'dense' : 'light'];
  return arr[Math.min(level, arr.length - 1)];
}

// 成長規則
export const GROWTH = {
  roadReach: 3,          // 道路 3 格內才會長出建築
  baseChance: 0.06,      // 每月每格基本成長機率
  demandChance: 0.22,    // 需求越高，機率越高
  upgradeChance: 0.05,
  unpoweredDecline: 0.2, // 沒電時每月衰退機率
  blackoutDecline: 0.06, // 輪流停電時每月衰退機率
  negDemandDecline: 0.05,
  noAccessDecline: 0.03, // 到不了工作（或找不到員工）時的衰退機率
  pollutionDecline: 0.05, // 住宅空污超過門檻時的衰退機率
  pollutionLimit: 150,
};

// 升級需要的地價（0–255）：高樓只會蓋在地價高的地方
export const LAND_VALUE_NEEDED = {
  r: { light: [0, 0, 70], dense: [0, 0, 80, 105, 140] },
  c: { light: [0, 0, 75], dense: [0, 0, 85, 110, 150] },
  i: { light: [0, 0, 0], dense: [0, 0, 0, 0, 0] },
};
