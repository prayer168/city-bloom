// 能源係數：電廠、容量因數、一天四時段分布、用電需求
//
// 【給老師】這裡的數字都可以改。改的時候請保持「相對大小」符合真實世界：
//   碳排放：燃煤 > 燃氣 >> 太陽能 > 水力 > 核能 ≈ 風力
//   建造成本（每 MW）：核能最貴；太陽能與儲能逐年變便宜
//   容量因數：核能最穩定；太陽能夏強冬弱、晚上為 0；風力冬強夏弱
//
// 【簡化說明】
//   1. 電廠容量縮小成「城市級」。真實燃煤電廠動輒 600 MW 以上，可供上百萬人用電；
//      遊戲城市約一到數萬人，若照真實規模，一座電廠就永遠用不完，學生感受不到取捨。
//      所以這裡的容量約為真實的 1/10–1/15，但「每 MW 的發電特性與碳排放」維持真實值。
//   2. 太陽能與風力占地接近真實：太陽光電約每公頃 0.9 MW（3×3 格 = 9 公頃 ≈ 8 MW）。
//   3. 金額是遊戲單位（千元），只保持各電廠之間的相對關係，不是真實價格。

// 碳排放係數：IPCC AR5 WG3 Annex III 生命週期排放中位數（gCO₂e/kWh）
// 燃煤 820、燃氣（複循環）490、太陽光電（大型）48、水力 24、核能 12、陸域風力 11

export const SLOT_NAMES = ['夜', '晨', '午', '晚'];
export const SLOT_HOURS = ['00–06', '06–12', '12–18', '18–24'];
export const HOURS_PER_MONTH = 730;
export const HOURS_PER_SLOT_MONTH = HOURS_PER_MONTH / 4; // 每個時段每月約 182.5 小時

// 月容量因數（台灣西部參考）：太陽能夏強、風力冬強，兩者互補
export const SOLAR_CF = [0.12, 0.13, 0.15, 0.16, 0.15, 0.13, 0.17, 0.16, 0.16, 0.15, 0.13, 0.12];
export const WIND_CF = [0.42, 0.38, 0.32, 0.22, 0.16, 0.14, 0.15, 0.14, 0.25, 0.38, 0.44, 0.45];
// 川流式水力：雨季（梅雨、颱風季）水量大，冬季乾季小
export const HYDRO_CF = [0.2, 0.2, 0.25, 0.3, 0.45, 0.6, 0.55, 0.65, 0.5, 0.3, 0.2, 0.2];

// 一天四時段的發電分布（占全日比例）
export const SOLAR_SLOT = [0, 0.4, 0.6, 0];
export const FLAT_SLOT = [0.25, 0.25, 0.25, 0.25];

// 用電分布：夏天午後冷氣尖峰，冬天晚上照明尖峰
export const DEMAND_SLOT_SUMMER = [0.17, 0.25, 0.33, 0.25];
export const DEMAND_SLOT_WINTER = [0.19, 0.26, 0.27, 0.28];
export function demandSlotShare(month) {
  // 5–10 月用夏季分布，其餘用冬季分布
  return month >= 5 && month <= 10 ? DEMAND_SLOT_SUMMER : DEMAND_SLOT_WINTER;
}

// 住商用電的季節倍數（只在沒有氣候資料時使用，例如單元測試）。
// 正式遊戲中改用每格的當地氣溫計算冷氣用電（climate.js 的 COOLING），熱島越嚴重越耗電。
export const SEASONAL_DEMAND = [0.9, 0.88, 0.9, 0.95, 1.05, 1.15, 1.22, 1.22, 1.12, 1.0, 0.92, 0.93];

// 每月用電量（MWh）：台灣住宅用電約每人每年 2,000 度
export const DEMAND_PER_RESIDENT = 0.17;
export const DEMAND_PER_COMMERCIAL_JOB = 0.35;
export const DEMAND_PER_INDUSTRIAL_JOB = 0.9;

// 可調度電廠的可用率（定期維修等）
export const DISPATCH_AVAILABILITY = 0.9;
export const STORAGE_EFFICIENCY = 0.85; // 充放電來回效率

export const PLANT_TYPES = ['coal', 'gas', 'nuclear', 'hydro', 'wind', 'solar', 'battery'];
export const RENEWABLE = new Set(['hydro', 'wind', 'solar']);

// kind:
//   'dispatch' 可依需要調整出力（燃煤、燃氣）
//   'baseload' 一直以固定出力運轉（核能）
//   'variable' 依天氣與時段決定（太陽能、風力、水力）
//   'storage'  儲能
export const PLANTS = {
  coal: {
    id: 'coal', name: '燃煤電廠', kind: 'dispatch', mw: 40, footprint: [4, 4],
    co2: 820, pollution: 9, cost: 6000, upkeep: 40, fuel: 0.012, life: 40,
    sideEffects: ['碳排放最高', '空氣污染最嚴重', '需要燃料費'],
    desc: '可以隨時增減發電量，但燒煤會排放大量二氧化碳和空氣污染物。',
  },
  gas: {
    id: 'gas', name: '燃氣電廠', kind: 'dispatch', mw: 30, footprint: [3, 3],
    co2: 490, pollution: 3, cost: 3500, upkeep: 30, fuel: 0.025, life: 30,
    sideEffects: ['碳排放約燃煤的六成', '燃料費較貴'],
    desc: '燒天然氣，比燃煤乾淨，也能快速調整發電量。',
  },
  nuclear: {
    id: 'nuclear', name: '核能電廠', kind: 'baseload', mw: 100, footprint: [4, 4], cf: 0.9,
    co2: 12, pollution: 0, cost: 20000, upkeep: 120, fuel: 0.004, life: 40, wastePerMWh: 0.00003,
    sideEffects: ['建造費最高', '產生需要長期保存的核廢料', '發電量固定，不能隨需要調整'],
    desc: '發電時幾乎不排碳，而且日夜穩定，但會累積核廢料。',
  },
  hydro: {
    id: 'hydro', name: '水力電廠', kind: 'variable', mw: 10, footprint: [2, 2], cfByMonth: HYDRO_CF, slot: FLAT_SLOT,
    co2: 24, pollution: 0, cost: 5000, upkeep: 20, fuel: 0, life: 60, needsRiver: true,
    sideEffects: ['必須蓋在河邊', '乾季與乾旱時發電量下降'],
    desc: '利用河水的流動發電，雨季發得多、乾季發得少。',
  },
  wind: {
    id: 'wind', name: '風力發電場', kind: 'variable', mw: 6, footprint: [3, 3], cfByMonth: WIND_CF, slot: FLAT_SLOT,
    co2: 11, pollution: 0, cost: 1500, upkeep: 12, fuel: 0, life: 25,
    sideEffects: ['夏天風小、發電少', '強烈颱風時必須停機'],
    desc: '冬天東北季風強，發電最多；夏天風小，發電較少。',
  },
  solar: {
    id: 'solar', name: '太陽光電場', kind: 'variable', mw: 8, footprint: [3, 3], cfByMonth: SOLAR_CF, slot: SOLAR_SLOT,
    co2: 48, pollution: 0, cost: 1600, upkeep: 8, fuel: 0, life: 25, costDeclinePerYear: 0.04, costFloorYear: 2040,
    sideEffects: ['晚上不發電', '需要很大的土地'],
    desc: '白天有陽光才發電，中午最多，晚上是零。價格每年都在下降。',
  },
  battery: {
    id: 'battery', name: '儲能電池', kind: 'storage', mw: 8, mwh: 32, footprint: [2, 2],
    co2: 0, pollution: 0, cost: 1200, upkeep: 6, fuel: 0, life: 15, costDeclinePerYear: 0.05, costFloorYear: 2040,
    sideEffects: ['本身不發電', '充放電會損失約 15% 的電'],
    desc: '電太多時先存起來，晚上或缺電時再放出來，可以搭配太陽能。',
  },
};

// 依年份計算建造費（太陽能、儲能逐年變便宜）
export function plantCost(type, year) {
  const p = PLANTS[type];
  if (!p.costDeclinePerYear) return p.cost;
  const yrs = Math.max(0, Math.min(year, p.costFloorYear) - 2025);
  return Math.round(p.cost * Math.pow(1 - p.costDeclinePerYear, yrs));
}
