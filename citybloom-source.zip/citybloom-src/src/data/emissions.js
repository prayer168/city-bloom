// 非電力的碳排放與吸收係數（公噸 CO₂）
// 電力的碳排放在 energy.js（IPCC AR5 生命週期中位數）。
//
// 【給老師】數字是教學簡化值，但相對大小對齊真實世界：
//   - 汽機車通勤每公里約 0.12 公斤（汽車約 0.17、機車約 0.06 的混合）
//   - 公車每位乘客每公里約 0.03 公斤（滿載時更低）
//   - 腳踏車、走路為 0
//   - 住宅瓦斯（煮飯、熱水）每人每年約 0.25 公噸
//   - 樹林每公頃每年約吸收 8 公噸 CO₂（生長旺盛的森林；成熟老林較少）
// 學生會發現：一整片樹林只抵得過幾十位開車通勤的人，所以「種樹」不能取代「減少排放」。

export const EMISSIONS = {
  carKgPerKm: 0.12,
  stopGoExtra: 0.3,                 // 塞車走走停停時每公里多排的比例（教學簡化值）
  busKgPerPassengerKm: 0.03,
  workDaysPerMonth: 22,
  nonCommuteKmPerResidentDay: 10,   // 上學、購物、休閒等通勤以外的移動（每人每天）
  freightPerJobMonth: 0.05,         // 商業與工業的貨運卡車（每個工作每月）
  residentPerMonth: 0.021,          // 住宅瓦斯
  commercialJobPerMonth: 0.02,      // 商業的瓦斯、鍋爐
  industrialJobPerMonth: { light: 0.12, dense: 0.4 }, // 工業製程與燃料（不含用電）
  forestPerTileMonth: -0.67,        // 每公頃「新種」樹林每月吸收
  clearingReleaseT: 150,            // 砍掉 1 公頃成熟樹林，樹木裡存的碳約釋放 150 公噸
  // 【簡化】已經很成熟的原生森林，每年新吸收的量比較少，遊戲只計算玩家新種的樹林；
  // 但砍掉任何樹林都會把樹裡存的碳放出來。
};

// 世界平均：Our World in Data／Global Carbon Project，化石燃料與工業 CO₂，
// 近十年每人每年略低於 5 公噸（2023 年約 4.7–4.8 公噸）。
export const WORLD_PER_CAPITA_T = 4.7;

export const CARBON_SOURCES = [
  { id: 'power', name: '發電', color: '#d95926' },
  { id: 'transport', name: '交通', color: '#3987e5' },
  { id: 'buildings', name: '住商', color: '#c98500' },
  { id: 'industry', name: '工業', color: '#9085e9' },
  { id: 'landuse', name: '砍伐樹林', color: '#e66767' },
];
export const ABSORB = { id: 'absorb', name: '新種樹林吸收', color: '#199e70' };
