// 空氣污染、地價、犯罪的係數
// 【簡化說明】污染值 0–255 是遊戲內的相對指標，不是真實的 AQI 數值；
// 但分成綠、黃、橘、紅四級，對應環境部空氣品質指標的顏色概念。

export const POLLUTION = {
  perIndustrialJob: 3.0,     // 每個工業工作的排放
  perPlantLevel: 40,         // 電廠「空污 0–10」× 這個值 = 滿載時每格排放（發電越多，污染越多）
  plantFullCF: 0.7,
  perCar: 0.1,               // 每輛通勤車經過一格的排放
  diffusionPasses: 8,        // 擴散範圍約 8 格（800 公尺）
  keep: 0.5,                 // 每次擴散保留在原格的比例
  decay: 0.94,               // 每次擴散後自然消散
  forestAbsorb: 0.82,        // 樹林格的污染再乘以這個值（樹木吸附微粒）
  waterAbsorb: 0.9,
  windShare: 0.18,           // 往下風處多送的比例
};

// 台灣季風：10–4 月東北季風（往西南吹），5–9 月西南季風（往東北吹）
// 地圖上方是北：x 往右是東、y 往下是南
export function windOf(month) {
  return month >= 5 && month <= 9
    ? { name: '西南季風', dx: 1, dy: -1 }   // 往東北吹
    : { name: '東北季風', dx: -1, dy: 1 };  // 往西南吹
}

export const AQI_LEVELS = [
  { max: 50, name: '良好', color: '#3ccf6e' },
  { max: 100, name: '普通', color: '#f2d33c' },
  { max: 150, name: '對敏感族群不健康', color: '#f28b30' },
  { max: 256, name: '不健康', color: '#e5483c' },
];
export function aqiLevel(v) {
  return AQI_LEVELS.findIndex((l) => v < l.max);
}

export const LAND_VALUE = {
  base: 50,
  water: 45,        // 水岸景觀（4 格內遞減）
  waterReach: 4,
  forest: 18,       // 樹林綠地（3 格內）
  center: 55,       // 靠近市中心
  centerReach: 45,
  road: 10,         // 有道路可以到
  pollution: 0.55,  // 每點污染扣多少地價
  crime: 0.3,
  congestion: 22,   // 門口道路塞車
};

export const CRIME = {
  density: 0.06,    // 每位居民或工作者
  poverty: 0.55,    // 地價低於 120 的部分
  base: 4,
};
