// 城市消息輪播：好人好事、市政宣導、科學獎項、科學小故事
//
// 寫作原則（給之後修改的人）：
//   1. 市民與本市的獎項都是虛構的遊戲角色（「本市」＝玩家的城市），不寫真實人物的虛構事蹟。
//   2. 真實的學者與獎項只放在「科學小故事」，一定寫出真實年份與真實內容，不說成「今年」。
//   3. 宣導內容依台灣主管機關的公開建議（疾管署、能源署、水利署、環境部、氣象署），數字保守。
//   4. 有 when() 的消息只在符合城市狀況時出現（例如熱浪、梅雨季、有資料中心），權重比較高。
//
// cat：good 好人好事、policy 市政宣導、award 科學榮譽（本市虛構獎項）、story 科學小故事（真實歷史）

export const NEWS_CAT = {
  good: { name: '好人好事', color: '#3dd68c' },
  policy: { name: '市政宣導', color: '#6ab8ff' },
  award: { name: '科學榮譽', color: '#ffcc44' },
  story: { name: '科學小故事', color: '#c79bff' },
};

import { aqiLevel } from './environment.js';

const pct = (v) => Math.round(v * 100);
const summer = (x) => x.month >= 5 && x.month <= 10;
const winter = (x) => x.month === 12 || x.month <= 2;

export const NEWS = [
  // ---------------- 好人好事（虛構市民） ----------------
  { id: 'g-tree', cat: 'good', text: '河濱社區的志工媽媽們帶著孩子種下 40 棵原生樹苗，說好每個週末輪流來澆水。' },
  { id: 'g-gauge', cat: 'good', text: '五年級的小芸用寶特瓶做了雨量筒，每天記錄雨量，已經連續記了 100 天。' },
  { id: 'g-repair', cat: 'good', text: '退休的電器行林伯伯每月開一次「修理咖啡館」，幫鄰居修好壞掉的電扇和檯燈，少丟了好多垃圾。' },
  { id: 'g-fridge', cat: 'good', text: '市場旁的「社區共享冰箱」上線，店家把賣不完但還新鮮的蔬果放進去，需要的人可以免費拿。' },
  { id: 'g-bike', cat: 'good', text: '一群高中生組成單車修理社，免費幫同學調整剎車和打氣，鼓勵大家騎車上學。' },
  { id: 'g-rainbarrel', cat: 'good', text: '陳阿嬤在屋簷下接了兩個雨水桶，菜園一整個夏天幾乎不用自來水。' },
  { id: 'g-birds', cat: 'good', text: '國小自然社的孩子在校園裝了鳥巢箱，今年春天有一對白頭翁在裡面孵出三隻雛鳥。' },
  { id: 'g-library', cat: 'good', text: '圖書館志工開設「星空說故事」，帶親子用望遠鏡看月亮的坑洞和木星的衛星。' },
  { id: 'g-lights', cat: 'good', text: '商店街店家約好打烊後關掉招牌燈，夜裡的街道暗了一點，但省下了不少電，也讓夜空的星星更清楚。' },
  { id: 'g-elder-heat', cat: 'good', weight: 3, when: (x) => x.ev.heatwave, text: '熱浪來襲，里長和志工挨家挨戶探訪獨居長輩，提醒多喝水，也幫忙開電扇、拉窗簾遮陽。' },
  { id: 'g-cool-ride', cat: 'good', weight: 3, when: (x) => x.ev.heatwave && x.has.coolingCenter, text: '志工車隊這幾天載了好幾位長輩到涼爽中心避暑，大家一起喝綠豆湯、下象棋。' },
  { id: 'g-mud', cat: 'good', weight: 4, when: (x) => x.recentFlood, text: '大雨過後，上百位志工自備雨鞋和鏟子幫忙清淤泥，學校也開放體育館讓居民暫住。' },
  { id: 'g-drain', cat: 'good', weight: 3, when: (x) => x.fc.typhoon || x.fc.heavyRain, text: '颱風雨要來了，社區巡守隊先把水溝蓋上的落葉和垃圾清乾淨，讓雨水排得掉。' },
  { id: 'g-beach', cat: 'good', weight: 2, when: (x) => x.coastal, text: '淨灘活動撿回 300 多公斤垃圾，最多的是寶特瓶蓋和塑膠吸管。' },
  { id: 'g-water-save', cat: 'good', weight: 3, when: (x) => x.waterLevel >= 1, text: '水庫水位偏低，國小學生發起「洗手關水龍頭」挑戰，全校一週省下約 20 公噸的水。' },
  { id: 'g-solar-coop', cat: 'good', weight: 2, when: (x) => x.has.solar || x.has.roofSolar, text: '幾戶鄰居合資在活動中心屋頂裝了太陽能板，賣電的收入用來辦社區活動。' },
  { id: 'g-bus', cat: 'good', weight: 2, when: (x) => x.has.busStop, text: '公車司機李大哥每天提醒乘客：「慢慢來，我等你坐好再開。」被乘客票選為最暖心司機。' },

  // ---------------- 市政宣導（依主管機關公開建議） ----------------
  { id: 'p-dengue', cat: 'policy', weight: 2, when: summer, text: '防登革熱：病媒蚊會在積水的容器裡產卵。家裡記得「巡、倒、清、刷」，把花盆底盤、廢輪胎的積水倒掉。' },
  { id: 'p-ac', cat: 'policy', weight: 2, when: summer, text: '夏天冷氣建議設在 26–28 °C，再搭配電扇讓空氣流動，一樣涼快，也比較省電。' },
  { id: 'p-heat', cat: 'policy', weight: 4, when: (x) => x.ev.heatwave || x.hot, text: '高溫提醒：多喝水不要等口渴，上午 10 點到下午 2 點盡量避免在大太陽下活動，小心熱傷害。' },
  { id: 'p-peak', cat: 'policy', weight: 2, when: (x) => summer(x) && x.month >= 6 && x.month <= 9, text: '夏季傍晚是用電尖峰，洗衣、烘衣這類耗電的家事，可以改在其他時間做。' },
  { id: 'p-typhoon', cat: 'policy', weight: 4, when: (x) => x.fc.typhoon || x.ev.typhoon, text: '防颱準備：固定陽台盆栽和招牌、清理排水孔，準備手電筒、飲用水和防災包，留意氣象署的颱風警報。' },
  { id: 'p-rain', cat: 'policy', weight: 3, when: (x) => x.fc.heavyRain || x.ev.heavyRain, text: '豪雨期間不要靠近河邊、溪邊和地下道；車子不要開進積水的路段。' },
  { id: 'p-plum', cat: 'policy', when: (x) => x.month === 5 || x.month === 6, text: '梅雨季到了：鋒面帶來連續降雨，是台灣重要的水庫補水來源，但也要小心短時間的強降雨。' },
  { id: 'p-save-water', cat: 'policy', weight: 3, when: (x) => x.waterLevel >= 1, text: '水情吃緊，請一起節約用水：洗菜水可以澆花、選購有「省水標章」的水龍頭和馬桶。' },
  { id: 'p-water', cat: 'policy', text: '台灣雨量雖然多，但河川又短又急，大部分的雨很快流進大海，所以水庫和節約用水都很重要。' },
  { id: 'p-recycle', cat: 'policy', text: '資源回收小提醒：寶特瓶倒乾淨、壓扁再回收，回收的塑膠可以做成衣服的纖維。' },
  { id: 'p-cup', cat: 'policy', text: '自備水壺和環保杯：一年少用幾百個一次性杯子，也少了做杯子、運杯子產生的碳排放。' },
  { id: 'p-bike', cat: 'policy', text: '短距離出門試試走路或騎腳踏車，不排放廢氣，也是很好的運動。' },
  { id: 'p-aqi', cat: 'policy', weight: 3, when: (x) => x.aqiLevel >= 2, text: '空氣品質不佳：敏感族群減少戶外劇烈運動，外出可以戴口罩，回家記得洗手洗臉。' },
  { id: 'p-co', cat: 'policy', weight: 3, when: winter, text: '冬天洗澡注意一氧化碳：瓦斯熱水器要裝在室外或通風良好的地方，洗澡時窗戶不要關緊。' },
  { id: 'p-cold', cat: 'policy', weight: 2, when: winter, text: '寒流來時要多穿一件、戴帽子圍巾，家中長輩起床、洗澡前後要特別注意保暖。' },
  { id: 'p-arbor', cat: 'policy', weight: 4, when: (x) => x.month === 3, text: '3 月 12 日植樹節：一棵大樹的樹蔭可以讓樹下的地面涼好幾度，也能吸收二氧化碳。' },
  { id: 'p-earthhour', cat: 'policy', weight: 4, when: (x) => x.month === 3, text: '3 月最後一個星期六晚上是「關燈一小時」（Earth Hour），邀請全市一起關燈，想一想能源怎麼用。' },
  { id: 'p-waterday', cat: 'policy', weight: 3, when: (x) => x.month === 3, text: '3 月 22 日世界水資源日：地球上的水大部分是海水，能直接使用的淡水不到 1%。' },
  { id: 'p-earthday', cat: 'policy', weight: 4, when: (x) => x.month === 4, text: '4 月 22 日世界地球日：本市邀請大家一起做一件對地球好的事，例如多走路、少用一次性餐具。' },
  { id: 'p-envday', cat: 'policy', weight: 4, when: (x) => x.month === 6, text: '6 月 5 日世界環境日：減少塑膠垃圾，也就少了流進海洋、被海龜和海鳥誤吃的塑膠。' },
  { id: 'p-drr', cat: 'policy', weight: 4, when: (x) => x.month === 10, text: '10 月 13 日國際減災日：和家人約好颱風、地震時在哪裡集合，把重要電話寫在紙上。' },
  { id: 'p-netzero', cat: 'policy', text: '台灣的目標是 2050 年淨零排放：排放的溫室氣體，要和被吸收、移除的一樣多。' },
  { id: 'p-greenshare', cat: 'policy', weight: 2, when: (x) => x.renew > 0, text: (x) => `能源小報：本市上個月的電有 ${pct(x.renew)}% 來自太陽能、風力、水力這些再生能源。` },
  { id: 'p-grid', cat: 'policy', weight: 2, when: (x) => x.has.aiGrid, text: '智慧電網上線：用電尖峰時，部分可以延後的用電會自動挪到電比較多的時段。' },
  { id: 'p-shelter', cat: 'policy', weight: 2, when: (x) => x.has.shelter, text: '本市已設立避難中心。颱風或淹水時，住在低窪地區的市民可以提早過去。' },

  // ---------------- 科學榮譽（本市虛構獎項與虛構市民） ----------------
  { id: 'a-sensor', cat: 'award', text: '本市科學創新獎揭曉：高中生團隊用便宜的感測器做出「淹水警報器」，水淹到 10 公分就會傳訊息給里長。' },
  { id: 'a-roof', cat: 'award', text: '本市環境研究獎：社區大學團隊量了一整個夏天，發現綠屋頂下的頂樓房間，比沒有綠屋頂的涼了好幾度。' },
  { id: 'a-fair', cat: 'award', text: '國小科展冠軍：學生比較不同顏色的屋頂，發現白色屋頂在大太陽下溫度最低，得到評審一致好評。' },
  { id: 'a-compost', cat: 'award', text: '本市永續創新獎：營養午餐的廚餘做成堆肥，再拿去種學校菜園的蔬菜，一年少了好幾公噸垃圾。' },
  { id: 'a-wind', cat: 'award', weight: 2, when: (x) => x.has.wind, text: '本市青年工程師獎：風機維修團隊改良葉片檢查方法，讓風機少停機好幾天。' },
  { id: 'a-dc', cat: 'award', weight: 2, when: (x) => x.has.dataCenter, text: '本市科學創新獎：工程師團隊調整資料中心的冷卻方式，在不影響運算的情況下省下一成用電。' },
  { id: 'a-weather', cat: 'award', weight: 2, when: (x) => x.has.aiWeather || x.has.warningCenter, text: '本市防災貢獻獎：預警中心團隊提早兩天發出豪雨提醒，讓低窪地區居民來得及把車子移到高處。' },

  // ---------------- 科學小故事（真實人物與真實年份） ----------------
  { id: 's-manabe', cat: 'story', text: '2021 年諾貝爾物理獎：真鍋淑郎與哈塞爾曼用物理模型模擬地球氣候，可靠地預測了全球暖化（與研究複雜系統的帕里西共同得獎）。' },
  { id: 's-hinton', cat: 'story', when: (x) => x.has.dataCenter || x.month % 2 === 0, text: '2024 年諾貝爾物理獎：霍普菲爾德與辛頓研究「人工神經網路」，奠定了今天 AI 機器學習的基礎。' },
  { id: 's-alphafold', cat: 'story', when: (x) => x.has.dataCenter || x.month % 2 === 1, text: '2024 年諾貝爾化學獎：貝克設計出全新的蛋白質；哈薩比斯與江珀用 AI 預測蛋白質的立體結構。' },
  { id: 's-ozone', cat: 'story', text: '1995 年諾貝爾化學獎：克魯岑、莫利納、羅蘭發現氟氯碳化物會破壞臭氧層；各國簽了《蒙特婁議定書》，臭氧層正在慢慢恢復。' },
  { id: 's-led', cat: 'story', text: '2014 年諾貝爾物理獎：赤崎勇、天野浩、中村修二發明藍光 LED，讓省電的白光 LED 燈得以普及。' },
  { id: 's-battery', cat: 'story', text: '2019 年諾貝爾化學獎：古德諾、惠廷翰、吉野彰發展出鋰離子電池，手機、電動車和儲能電池都要靠它。' },
  { id: 's-keeling', cat: 'story', text: '科學家基林從 1958 年起在夏威夷的茂納羅亞山測量空氣中的二氧化碳，這條逐年上升的曲線被稱為「基林曲線」。' },
  { id: 's-carson', cat: 'story', text: '1962 年，生物學家瑞秋・卡森出版《寂靜的春天》，讓大家注意到農藥對鳥類和環境的傷害。' },
  { id: 's-lee', cat: 'story', text: '1986 年，李遠哲獲得諾貝爾化學獎，他用「交叉分子束」看清楚化學反應中分子怎麼碰撞，是第一位得到諾貝爾獎的台灣出生科學家。' },
  { id: 's-ipcc', cat: 'story', text: '2007 年諾貝爾和平獎頒給聯合國政府間氣候變遷專門委員會（IPCC）與高爾，表彰他們讓世界更了解氣候變遷。' },
  { id: 's-paris', cat: 'story', text: '2015 年《巴黎協定》：各國同意把全球升溫控制在遠低於 2 °C，並努力限制在 1.5 °C 以內。' },
  { id: 's-mrna', cat: 'story', text: '2023 年諾貝爾生理醫學獎：卡里科與魏斯曼的 mRNA 研究，幫助科學家很快做出新冠肺炎疫苗。' },
];

// 從城市狀態整理出消息需要的條件
export function newsContext(world) {
  const c = world.city;
  const cl = c.climate || {};
  const has = {};
  for (const inst of world.instances?.values?.() || []) has[inst.def] = true;
  const ev = {};
  for (const e of cl.activeEvents || []) ev[e.type] = true;
  if (cl.drought) ev.drought = true;
  const fc = {};
  for (const e of cl.forecast?.events || []) fc[e.type] = true;
  const last = (c.reports || [])[c.reports?.length - 1];
  const monthsAgo = last ? (c.year - last.y) * 12 + (c.month - last.m) : 99;
  return {
    month: c.month,
    has, ev, fc,
    hot: (cl.tempMax ?? 0) >= 35,
    coastal: !!cl.coastal,
    waterLevel: c.water?.level ?? 0,
    aqiLevel: c.air ? Math.max(0, aqiLevel(c.air.avgExposure)) : 0,
    renew: c.power?.renewableShare ?? 0,
    recentFlood: monthsAgo <= 1 && !!last && (last.type === 'typhoon' || last.type === 'heavyRain') && (last.floodTiles?.length || 0) > 20,
  };
}

// 挑一則消息：符合條件的才列入，最近出現過的不重複；有條件的（跟城市現況有關）權重較高
export function pickNews(ctx, rng = Math.random, recent = []) {
  const avoid = new Set(recent);
  let pool = NEWS.filter((n) => (!n.when || n.when(ctx)) && !avoid.has(n.id));
  if (!pool.length) pool = NEWS.filter((n) => !n.when || n.when(ctx));
  const w = (n) => n.weight ?? (n.when ? 1.5 : 1);
  let r = rng() * pool.reduce((s, n) => s + w(n), 0);
  for (const n of pool) { r -= w(n); if (r <= 0) return render(n, ctx); }
  return render(pool[pool.length - 1], ctx);
}

const render = (n, ctx) => ({ id: n.id, cat: n.cat, kind: 'news', text: typeof n.text === 'function' ? n.text(ctx) : n.text });
