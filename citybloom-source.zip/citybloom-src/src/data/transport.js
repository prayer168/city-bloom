// 交通係數
// 【簡化說明】每個月算一次「典型的上班日」：每位上班族從家裡沿道路走到最近的工作地點。
// 道路負載 = 經過這一格的汽機車通勤人數。容量以一般市區雙向道路的尖峰量簡化而來。

export const TRAFFIC = {
  workersPerResident: 0.5,   // 約一半居民需要通勤（其餘是孩子、長輩、在家工作）
  baseCarShare: 0.8,         // 沒有大眾運輸時，八成通勤靠汽機車
  roadCapacity: 360,         // 每格道路可以順暢通過的通勤車輛數
  maxCommute: 60,            // 最遠通勤距離（格；1 格 ≈ 100 m，約 6 公里）
  congestionCost: 3,         // 壅塞時，路線成本增加的倍數（讓車流分散到其他道路）
  kmPerTile: 0.1,
};

export const TRANSIT = {
  busStop: {
    id: 'busStop', name: '公車站', footprint: [1, 1], cost: 150, upkeep: 2,
    radius: 6,               // 步行 6 格（約 600 m）內的居民會考慮搭公車
    carShareCut: 0.3,        // 汽機車比例下降 30 個百分點
    desc: '附近 600 公尺內的居民會改搭公車，路上的車變少。要蓋在道路旁邊。',
  },
  bikeLane: {
    cost: 4,                 // 每格（加在既有道路上）
    radius: 3,
    carShareCut: 0.12,       // 住在自行車道附近，短程通勤改騎腳踏車
    maxBikeTiles: 25,        // 通勤距離 2.5 公里內才會騎車
    desc: '在道路上畫自行車道。住在附近、通勤距離短的人會改騎腳踏車。',
  },
};
