// 暖化情境：依年份內插全球升溫與海平面

import { SCENARIOS, REFERENCE_YEAR } from '../data/climate.js';
import { interpPts } from '../data/hazards.js';

function interp(points, year) {
  if (year <= points[0][0]) return points[0][1];
  for (let k = 1; k < points.length; k++) {
    const [y1, v1] = points[k];
    if (year <= y1) {
      const [y0, v0] = points[k - 1];
      return v0 + ((v1 - v0) * (year - y0)) / (y1 - y0);
    }
  }
  return points[points.length - 1][1];
}

// 全球平均升溫（相對工業化前）
export function globalWarming(scenario, year) {
  return interp((SCENARIOS[scenario] ?? SCENARIOS.mid).points, year);
}

// 本地氣溫比「現在（2025）」多幾度
export function localWarming(scenario, year) {
  return globalWarming(scenario, year) - globalWarming(scenario, REFERENCE_YEAR);
}

// 全球平均海平面比 2025 年高幾公尺；speed = 教師設定的加速倍數（預設 ×3）
// 2100 年以後沿最後一段的速度繼續上升（AR6：海平面在 2100 年後仍會持續上升好幾個世紀）
export function seaLevelRise(scenario, year, speed = 1) {
  const s = (SCENARIOS[scenario] ?? SCENARIOS.mid).sea;
  const effYear = REFERENCE_YEAR + (year - REFERENCE_YEAR) * speed;
  return Math.max(0, interpPts(s, effYear) - interpPts(s, REFERENCE_YEAR));
}

export function scenarioCurve(scenario, from = 2020, to = 2100, step = 5) {
  const out = [];
  for (let y = from; y <= to; y += step) out.push([y, globalWarming(scenario, y)]);
  return out;
}
