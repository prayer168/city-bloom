// 海平面上升：每個月重新判斷海岸低地
//   SUBMERGED（被海水淹沒）：比「平均海平面」還低、又和海相連的陸地，不能再使用
//   TIDAL（漲潮會淹）：比「大潮高潮位」低的陸地，每個月漲潮時會被海水倒灌
// 海堤會擋住海水；之後再蓋海堤，被淹的地也會重新露出來（像荷蘭的圩田）。

import { SURFACE, STATE, SEA_LEVEL_CM, DEFENSE } from '../core/constants.js';
import { WATER_BODY } from '../sim/world.js';
import { seaLevelRise } from './scenario.js';
import { spreadWater } from '../sim/systems/flood.js';
import { FLOOD } from '../data/hazards.js';

export function tideHighM(month) {
  return FLOOD.tideHighM + (month >= 8 && month <= 10 ? FLOOD.kingTideExtraM : 0);
}

export function updateSeaLevel(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const c = world.city;
  const cl = c.climate;
  const rise = seaLevelRise(cl.scenario, c.year + (c.month - 1) / 12, cl.seaLevelSpeed ?? 1);
  cl.seaRiseM = rise;
  const sources = [];
  for (let i = 0; i < n; i++) if (L.surface[i] === SURFACE.WATER && L.waterBody[i] === WATER_BODY.SEA) sources.push(i);
  const changed = [];
  const result = { submerged: 0, tidal: 0, newSubmerged: [], tidalDev: 0, rise };
  if (!sources.length) {
    for (let i = 0; i < n; i++) if (L.state[i] & (STATE.SUBMERGED | STATE.TIDAL)) { L.state[i] &= ~(STATE.SUBMERGED | STATE.TIDAL); changed.push(i); }
    result.changed = changed;
    return result;
  }
  const elevM = new Float32Array(n);
  for (let i = 0; i < n; i++) elevM[i] = L.elev[i] / 100;
  const base = SEA_LEVEL_CM / 100 + rise;
  const permanent = new Float32Array(n);
  spreadWater(world, elevM, permanent, sources.map((i) => [i, base]), 0, DEFENSE.SEAWALL, null, null);
  const tide = new Float32Array(n);
  spreadWater(world, elevM, tide, sources.map((i) => [i, base + tideHighM(c.month)]), 0.01, DEFENSE.SEAWALL, null, null);
  for (let i = 0; i < n; i++) {
    if (L.surface[i] === SURFACE.WATER) continue;
    const old = L.state[i] & (STATE.SUBMERGED | STATE.TIDAL);
    let st = 0;
    if (permanent[i] > 0.02) st = STATE.SUBMERGED;
    else if (tide[i] > 0.05) st = STATE.TIDAL;
    if (st !== old) {
      L.state[i] = (L.state[i] & ~(STATE.SUBMERGED | STATE.TIDAL)) | st;
      changed.push(i);
      if (st === STATE.SUBMERGED) result.newSubmerged.push(i);
    }
    if (st === STATE.SUBMERGED) result.submerged++;
    else if (st === STATE.TIDAL) { result.tidal++; if (L.zone[i] && L.devLevel[i]) result.tidalDev++; }
  }
  result.changed = changed;
  cl.coastal = { submerged: result.submerged, tidal: result.tidal, tidalDev: result.tidalDev };
  return result;
}
