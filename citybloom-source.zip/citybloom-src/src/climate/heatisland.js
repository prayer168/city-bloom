// 都市熱島：每格午後地表溫度
//   地表溫度 = 氣溫 + 晴天地表加熱 + 熱島加成 × 季節係數 + 周圍降溫
// 熱島加成：道路與鋪面、建築、電廠廠區、交通廢熱、冷氣廢熱（上個月的冷氣用電）
// 降溫：樹林、水體、公園（周圍遞減）；行道樹、綠屋頂、冷屋頂（本格）；通風廊道
// 冷氣廢熱用的是上個月的用電，形成「熱 → 開冷氣 → 廢熱 → 更熱」的正回饋。

import { NET, SURFACE, COVER } from '../core/constants.js';
import { ZONE_INFO } from '../data/buildings/zones.js';
import { HEAT, DAILY_MAX_SD } from '../data/climate.js';
import { windOf } from '../data/environment.js';

const H = HEAT;

export function updateHeatIsland(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const cl = world.city.climate;
  const air = cl.temp ?? 25;
  // 夏天陽光強，熱島明顯；冬天比較弱
  const sf = 0.6 + 0.4 * Math.max(0, Math.min(1, (air - 18) / 11));
  const ac = world.coolingLoad;
  const traffic = L.traffic;

  const heat = new Float32Array(n);
  const cool = new Float32Array(n);
  const coolSrc = []; // [i, r, c]
  for (let i = 0; i < n; i++) {
    const s = L.surface[i];
    let h = 0;
    if (s === SURFACE.WATER) { cool[i] += H.waterSelf; coolSrc.push([i, H.water.r, H.water.c]); heat[i] = 0; continue; }
    if (s === SURFACE.SAND) h += H.sand;
    const net = L.net[i];
    const z = L.zone[i];
    const bid = L.bld[i];
    if (bid) {
      const inst = world.instances.get(bid);
      if (inst?.kind === 'park') { coolSrc.push([i, H.park.r, H.park.c]); cool[i] += -H.park.c; }
      else if (inst?.def === 'solar') h += H.solarPanel;
      else if (inst && inst.def !== 'wind') h += H.plantPaved;
    } else if (s === SURFACE.FOREST && !z && !net) {
      cool[i] += H.forestSelf;
      coolSrc.push([i, H.forest.r, H.forest.c]);
    }
    if (net & NET.ROAD) {
      h += H.road;
      if (L.cover[i] & COVER.STREET_TREES) h += H.streetTrees;
      if (traffic[i]) h += H.trafficMax * Math.min(1, (traffic[i] / 255) * 2);
    }
    if (z && L.devLevel[i]) {
      const info = ZONE_INFO[z];
      h += H.lot + (info.dense ? H.buildingDense : H.buildingLight) * (0.6 + 0.1 * L.devLevel[i]);
      if (L.cover[i] & COVER.GREEN_ROOF) h += H.greenRoof;
      if (L.cover[i] & COVER.COOL_ROOF) h += H.coolRoof;
      if (ac && ac[i] > 0) h += H.acMax * Math.min(1, ac[i] / H.acMWhFull);
    }
    heat[i] = Math.max(0, h);
  }

  // 周圍降溫（距離遞減）
  for (const [i, r, c] of coolSrc) {
    const x = i % size, y = (i / size) | 0;
    for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (!dx && !dy) continue;
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= size || ny >= size) continue;
      const d = Math.max(Math.abs(dx), Math.abs(dy));
      cool[ny * size + nx] -= (c * (1 - d / (r + 1))) / 3; // 很多來源疊加時不會過量
    }
  }

  // 通風廊道：上風處有連續 3 格開放空間，熱比較容易散掉
  const wind = windOf(world.city.month);
  const open = (j) => !L.zone[j] && !L.bld[j] && !(L.net[j] & NET.ROAD) || L.surface[j] === SURFACE.WATER;
  const surf = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = i % size, y = (i / size) | 0;
    let h = heat[i];
    if (h > 0) {
      let run = 0;
      for (let k = 1; k <= 3; k++) {
        const ux = x - wind.dx * k, uy = y - wind.dy * k;
        if (ux < 0 || uy < 0 || ux >= size || uy >= size) break;
        if (open(uy * size + ux)) run++; else break;
      }
      if (run >= 3) h *= H.ventilation;
    }
    surf[i] = air + H.sunnySurface * sf + h * H.intensity * sf + Math.max(H.coolingFloor, cool[i]) * sf;
  }

  // 平滑兩次，讓熱度自然暈開
  const tmp = new Float32Array(n);
  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < n; i++) {
      const x = i % size, y = (i / size) | 0;
      let s = surf[i] * 2, c = 2;
      if (x > 0) { s += surf[i - 1]; c++; }
      if (x < size - 1) { s += surf[i + 1]; c++; }
      if (y > 0) { s += surf[i - size]; c++; }
      if (y < size - 1) { s += surf[i + size]; c++; }
      tmp[i] = s / c;
    }
    surf.set(tmp);
  }
  L.surfTemp.set(surf);

  // 郊區基準 = 草地晴天的地表溫度；市中心 = 最密集 25% 已開發格子的平均
  const rural = air + H.sunnySurface * sf;
  const dev = [];
  for (let i = 0; i < n; i++) if (L.zone[i] && L.devLevel[i]) dev.push(i);
  dev.sort((a, b) => L.pop[b] + L.jobs[b] - (L.pop[a] + L.jobs[a]));
  const core = dev.slice(0, Math.max(1, Math.ceil(dev.length * 0.25)));
  const coreSurf = dev.length ? core.reduce((a, i) => a + surf[i], 0) / core.length : rural;
  const strength = Math.max(0, coreSurf - rural);

  // 每格的「當地氣溫」：給冷氣用電使用
  const local = world.localTemp && world.localTemp.length === n ? world.localTemp : (world.localTemp = new Float32Array(n));
  for (let i = 0; i < n; i++) local[i] = air + H.airCoupling * (surf[i] - rural);

  // 高溫日數：日最高溫 ≥ 35 °C 的天數（以常態分布估計）
  const days = (tmax) => 30.4 * (1 - phi((35 - tmax) / DAILY_MAX_SD));
  const coreMax = cl.tempMax + H.airCoupling * strength;
  const hotCore = days(coreMax), hotRural = days(cl.tempMax);
  if (world.city.month === 1) { cl.hotDaysLastYear = cl.hotDaysYear ?? null; cl.hotDaysYear = 0; cl.hotDaysYearRural = 0; }
  cl.hotDaysYear = (cl.hotDaysYear || 0) + hotCore;
  cl.hotDaysYearRural = (cl.hotDaysYearRural || 0) + hotRural;
  Object.assign(cl, { heatIsland: strength, coreSurf, ruralSurf: rural, hotDaysCore: hotCore, hotDaysRural: hotRural, coreAir: air + H.airCoupling * strength });
  return cl;
}

// 標準常態累積分布（近似）
function phi(z) {
  const t = 1 / (1 + 0.2316419 * Math.abs(z));
  const d = 0.3989423 * Math.exp((-z * z) / 2);
  const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return z > 0 ? 1 - p : p;
}
