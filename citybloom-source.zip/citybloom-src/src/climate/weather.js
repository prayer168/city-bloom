// 每月天氣：氣候基準 + 暖化 + 年際變化（固定種子）

import { Rng } from '../core/rng.js';
import { BASE_TEMP, BASE_RAIN, DAILY_MAX_OFFSET, WEATHER_VAR } from '../data/climate.js';
import { globalWarming, localWarming } from './scenario.js';

function gauss(rng) {
  const u = Math.max(1e-9, rng.next()), v = rng.next();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

export function updateWeather(world) {
  const c = world.city;
  const cl = c.climate;
  const m = c.month - 1;
  const rng = new Rng((c.seed * 977 + c.year * 12 + c.month * 7 + 13) >>> 0);
  const dLocal = localWarming(cl.scenario, c.year + m / 12);
  // 一般月份的雨量只有年際變化；暖化讓「強降雨事件」變強的效果在階段六的極端天氣處理
  const temp = BASE_TEMP[m] + dLocal + gauss(rng) * WEATHER_VAR.tempSd;
  const rainMult = Math.exp(gauss(rng) * WEATHER_VAR.rainLogSd - (WEATHER_VAR.rainLogSd ** 2) / 2);
  const rain = BASE_RAIN[m] * rainMult;
  // 水庫與河川反映最近幾個月的雨量（比較平滑）
  const prev = cl.rainIndex ?? 1;
  const rainIndex = prev * 0.5 + (rain / BASE_RAIN[m]) * 0.5;
  Object.assign(cl, {
    globalDT: globalWarming(cl.scenario, c.year + m / 12),
    localDT: dLocal,
    temp, tempNormal: BASE_TEMP[m],
    tempMax: temp + DAILY_MAX_OFFSET[m],
    rain, rainNormal: BASE_RAIN[m], rainIndex,
  });
  return cl;
}
