// 極端天氣事件：每個月底先「擲骰子」決定下個月會發生什麼，做成預報；
// 下個月月初事件真的發生（改變雨量、氣溫、風速），月中由 disaster.js 結算災情。
// 同一個地圖編號一定得到同一串天氣，全班可以比較誰的城市準備得比較好。

import { Rng } from '../core/rng.js';
import { globalWarming } from './scenario.js';
import { REFERENCE_YEAR } from '../data/climate.js';
import {
  AR6, interpPts, EVENT_P, MAX_MONTH_P, TYPHOON, HEAVY_RAIN, HEATWAVE, DROUGHT,
} from '../data/hazards.js';

export const EVENT_NAME = { typhoon: '颱風', heavyRain: '豪雨', heatwave: '熱浪', drought: '乾旱' };

// 某一年、某種事件相對 2025 年的倍數與強度增量
export function hazardFactors(scenario, year) {
  const T = globalWarming(scenario, year);
  const T0 = globalWarming(scenario, REFERENCE_YEAR);
  const ratio = (pts) => interpPts(pts, T) / interpPts(pts, T0);
  return {
    T,
    heatFreq: ratio(AR6.hotFreq),
    heatExtraC: interpPts(AR6.hotIntensity, T) - interpPts(AR6.hotIntensity, T0),
    rainFreq: ratio(AR6.rainFreq),
    rainMult: (1 + interpPts(AR6.rainIntensityPct, T) / 100) / (1 + interpPts(AR6.rainIntensityPct, T0) / 100),
    droughtFreq: ratio(AR6.droughtFreq),
    // 颱風：次數不變；強颱比例與降雨增加
    strongShareMult: (1 + interpPts(AR6.tcStrongSharePct, T) / 100) / (1 + interpPts(AR6.tcStrongSharePct, T0) / 100),
    tcRainMult: (1 + interpPts(AR6.tcRainPct, T) / 100) / (1 + interpPts(AR6.tcRainPct, T0) / 100),
  };
}

// 本月各種事件的機率
export function monthProbabilities(scenario, year, month) {
  const f = hazardFactors(scenario, year);
  const m = month - 1;
  const cap = (p) => Math.min(MAX_MONTH_P, p);
  return {
    typhoon: EVENT_P.typhoon[m],
    heavyRain: cap(EVENT_P.heavyRain[m] * f.rainFreq),
    heatwave: cap(EVENT_P.heatwave[m] * f.heatFreq),
    drought: cap(EVENT_P.drought[m] * f.droughtFreq),
  };
}

export function typhoonShares(scenario, year) {
  const f = hazardFactors(scenario, year);
  const strong = Math.min(0.6, TYPHOON.share.strong * f.strongShareMult);
  const moderate = TYPHOON.share.moderate;
  return { strong, moderate, mild: Math.max(0, 1 - strong - moderate) };
}

const between = (rng, [a, b]) => a + (b - a) * rng.next();

// 擲出某年某月的事件（純函式：同樣的輸入一定得到同樣的結果）
export function rollEvents(seed, scenario, year, month, { droughtActive = false, disabled = [] } = {}) {
  const rng = new Rng((seed * 7919 + year * 131 + month * 17 + 4049) >>> 0);
  const p = monthProbabilities(scenario, year, month);
  const f = hazardFactors(scenario, year);
  const events = [];
  const on = (t) => !disabled.includes(t);

  const rTy = rng.next();
  if (on('typhoon') && rTy < p.typhoon) {
    const sh = typhoonShares(scenario, year);
    const r = rng.next();
    const cat = r < sh.strong ? 'strong' : r < sh.strong + sh.moderate ? 'moderate' : 'mild';
    const def = TYPHOON.cats[cat];
    events.push({
      type: 'typhoon', cat, name: def.name,
      windMs: Math.round(between(rng, def.windMs)),
      rainMm: Math.round(between(rng, def.rain) * f.tcRainMult),
      surgeM: def.surgeM,
      days: TYPHOON.daysAffected,
    });
  } else rng.next();

  const rRain = rng.next();
  if (on('heavyRain') && rRain < p.heavyRain && !events.some((e) => e.type === 'typhoon')) {
    events.push({ type: 'heavyRain', name: HEAVY_RAIN.name, rainMm: Math.round(between(rng, HEAVY_RAIN.rain) * f.rainMult), days: 2 });
  } else rng.next();

  const rHeat = rng.next();
  if (on('heatwave') && rHeat < p.heatwave) {
    const days = Math.round(between(rng, HEATWAVE.days));
    events.push({ type: 'heatwave', name: HEATWAVE.name, days, dT: +(HEATWAVE.baseDT + Math.max(0, f.heatExtraC) + rng.next()).toFixed(1) });
  } else rng.next();

  const rDry = rng.next();
  if (on('drought') && !droughtActive && rDry < p.drought) {
    events.push({ type: 'drought', name: DROUGHT.name, months: Math.round(between(rng, DROUGHT.months)) });
  } else rng.next();

  return events;
}

// 月底：擲出下個月的事件，並做成玩家看得到的預報
// 預報有不確定性：沒有預警中心時，約一成的事件沒被預報到，也比較常「虛驚一場」
export function prepareForecast(world) {
  const c = world.city;
  const cl = c.climate;
  const disabled = c.disabledHazards || [];
  const events = rollEvents(c.seed, cl.scenario, c.year, c.month, { droughtActive: !!cl.drought, disabled });
  const ai = c.compute?.services?.aiWeather || 0;
  const hasWarning = [...world.instances.values()].some((x) => x.def === 'warningCenter') || ai >= 0.5;
  const rng = new Rng((c.seed * 104729 + c.year * 977 + c.month * 31 + 7) >>> 0);
  const p = monthProbabilities(cl.scenario, c.year, c.month);
  const shown = [];
  for (const e of events) {
    if (!hasWarning && rng.chance(0.1)) continue; // 沒預報到
    shown.push({ type: e.type, likelihood: hasWarning ? 'high' : 'mid', text: forecastText(e, hasWarning) });
  }
  for (const t of ['typhoon', 'heavyRain', 'heatwave']) {
    if (events.some((e) => e.type === t) || disabled.includes(t)) continue;
    if (rng.chance(p[t] * (hasWarning ? 0.15 : 0.5))) shown.push({ type: t, likelihood: 'low', text: falseAlarmText(t) });
  }
  if (cl.drought && cl.drought.monthsLeft > 1) shown.push({ type: 'drought', likelihood: 'high', text: '降雨持續偏少，水庫蓄水可能繼續下降' });
  cl.forecast = { y: c.year, m: c.month, events, shown, hasWarning, ai: ai >= 0.5 };
  // AI 氣象預警：再往後看一個月（兩個月前的預報比較不確定，只說「可能」）
  if (ai >= 0.5) {
    const y2 = c.month === 12 ? c.year + 1 : c.year, m2 = c.month === 12 ? 1 : c.month + 1;
    const ev2 = rollEvents(c.seed, cl.scenario, y2, m2, { droughtActive: !!cl.drought, disabled });
    cl.outlook = { y: y2, m: m2, shown: ev2.filter((e) => e.type !== 'drought').map((e) => ({ type: e.type, likelihood: 'mid', text: forecastText(e, false) })) };
  } else cl.outlook = null;
  return cl.forecast;
}

function forecastText(e, detail) {
  if (e.type === 'typhoon') return detail ? `${e.name}可能來襲，預估雨量 ${roundTo(e.rainMm, 50)} 毫米以上` : '颱風可能接近';
  if (e.type === 'heavyRain') return detail ? `鋒面帶來豪雨，預估雨量 ${roundTo(e.rainMm, 50)} 毫米` : '可能有豪雨';
  if (e.type === 'heatwave') return detail ? `高溫可能持續 ${e.days} 天，最高氣溫可達 ${35 + Math.round(e.dT / 2)} °C 以上` : '可能出現連續高溫';
  if (e.type === 'drought') return '降雨可能明顯偏少，請注意水庫蓄水';
  return '';
}
function falseAlarmText(t) {
  return { typhoon: '颱風有機會接近', heavyRain: '有機會出現豪雨', heatwave: '有機會出現高溫' }[t];
}
const roundTo = (v, s) => Math.floor(v / s) * s;

// 月初：把預報裡已擲好的事件變成「本月發生」，並調整本月天氣
export function startEvents(world) {
  const c = world.city;
  const cl = c.climate;
  const fc = cl.forecast;
  const events = fc && fc.y === c.year && fc.m === c.month ? fc.events.map((e) => ({ ...e })) : [];
  cl.activeEvents = events;
  const start = events.find((e) => e.type === 'drought');
  if (start) cl.drought = { monthsLeft: start.months, startY: c.year, startM: c.month, months: start.months };
  return events;
}

// 依本月事件修改天氣（updateWeather 之後呼叫）
export function applyEventsToWeather(world) {
  const cl = world.city.climate;
  let dryMult = 1;
  if (cl.drought) {
    dryMult = DROUGHT.rainMult;
    // 颱風或豪雨帶來的雨可以解除乾旱
    if (cl.activeEvents.some((e) => e.type === 'typhoon' || (e.type === 'heavyRain' && e.rainMm > 180))) cl.drought.endedByRain = true;
  }
  let eventRain = 0;
  for (const e of cl.activeEvents) if (e.rainMm) eventRain += e.rainMm;
  cl.rain = cl.rain * dryMult + eventRain;
  cl.eventRain = eventRain;
  const hw = cl.activeEvents.find((e) => e.type === 'heatwave');
  cl.heatwave = hw ? { dT: hw.dT, days: hw.days } : null;
  if (hw) {
    // 月平均氣溫被熱浪拉高一些；熱浪期間的最高溫另外記錄
    cl.temp += (hw.dT * hw.days) / 30;
    cl.heatwaveMax = cl.tempMax + hw.dT;
    cl.tempMax += (hw.dT * hw.days) / 30;
  } else cl.heatwaveMax = null;
  // 重新計算平滑的雨量指標（水力、水庫用）
  const prevIndex = cl.prevRainIndex ?? 1;
  cl.rainIndex = prevIndex * 0.5 + (cl.rain / Math.max(1, cl.rainNormal)) * 0.5;
  cl.prevRainIndex = cl.rainIndex;
  const ty = cl.activeEvents.find((e) => e.type === 'typhoon');
  cl.windMs = ty ? ty.windMs : 0;
}

// 月底：乾旱倒數
export function advanceDrought(world) {
  const cl = world.city.climate;
  if (!cl.drought) return;
  cl.drought.monthsLeft--;
  if (cl.drought.monthsLeft <= 0 || cl.drought.endedByRain) cl.drought = null;
}
