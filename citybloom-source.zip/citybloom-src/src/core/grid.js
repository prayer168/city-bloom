// 格子索引工具。第 i 格 = y * size + x。

export function idx(size, x, y) {
  return y * size + x;
}

export function inBounds(size, x, y) {
  return x >= 0 && y >= 0 && x < size && y < size;
}

export const DIR4 = Object.freeze([[1, 0], [-1, 0], [0, 1], [0, -1]]);
export const DIR8 = Object.freeze([
  [1, 0], [-1, 0], [0, 1], [0, -1],
  [1, 1], [1, -1], [-1, 1], [-1, -1],
]);

export function forEachNeighbor4(size, x, y, fn) {
  for (const [dx, dy] of DIR4) {
    const nx = x + dx, ny = y + dy;
    if (inBounds(size, nx, ny)) fn(nx, ny, ny * size + nx);
  }
}

// 以 (cx, cy) 為中心、半徑 r 的方形範圍（給筆刷與覆蓋半徑用）
export function forEachInSquare(size, cx, cy, r, fn) {
  const x0 = Math.max(0, cx - r), x1 = Math.min(size - 1, cx + r);
  const y0 = Math.max(0, cy - r), y1 = Math.min(size - 1, cy + r);
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) fn(x, y, y * size + x);
  }
}

// 以 (cx, cy) 為中心、半徑 r 的圓形範圍，附距離
export function forEachInRadius(size, cx, cy, r, fn) {
  const r2 = r * r;
  forEachInSquare(size, cx, cy, Math.ceil(r), (x, y, i) => {
    const dx = x - cx, dy = y - cy;
    const d2 = dx * dx + dy * dy;
    if (d2 <= r2) fn(x, y, i, Math.sqrt(d2));
  });
}
