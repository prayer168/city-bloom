// 可重現亂數：同樣的種子一定產生同樣的序列。
// 關卡分享與自動測試都依賴這個特性。

export function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class Rng {
  constructor(seed) {
    this.seed = seed >>> 0;
    this._next = mulberry32(this.seed);
  }
  next() { return this._next(); }
  range(min, max) { return min + (max - min) * this._next(); }
  int(min, maxInclusive) { return min + Math.floor(this._next() * (maxInclusive - min + 1)); }
  chance(p) { return this._next() < p; }
  pick(arr) { return arr[Math.floor(this._next() * arr.length)]; }
}

// 由整數座標得到穩定的 0–1 雜湊值（給繪圖細節用，不影響模擬）
export function hash2(x, y, salt = 0) {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(salt | 0, 2147483647)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

// 數值雜訊（value noise）+ 分形疊加，用於地形生成
export function makeValueNoise(seed) {
  const SIZE = 256;
  const rng = mulberry32(seed);
  const perm = new Uint8Array(SIZE * 2);
  const vals = new Float32Array(SIZE);
  const p = Array.from({ length: SIZE }, (_, i) => i);
  for (let i = SIZE - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [p[i], p[j]] = [p[j], p[i]];
  }
  for (let i = 0; i < SIZE * 2; i++) perm[i] = p[i & 255];
  for (let i = 0; i < SIZE; i++) vals[i] = rng();

  const lattice = (ix, iy) => vals[perm[(perm[ix & 255] + iy) & 511]];
  const smooth = (t) => t * t * (3 - 2 * t);

  function noise(x, y) {
    const ix = Math.floor(x), iy = Math.floor(y);
    const fx = x - ix, fy = y - iy;
    const sx = smooth(fx), sy = smooth(fy);
    const a = lattice(ix, iy), b = lattice(ix + 1, iy);
    const c = lattice(ix, iy + 1), d = lattice(ix + 1, iy + 1);
    const top = a + (b - a) * sx;
    const bot = c + (d - c) * sx;
    return top + (bot - top) * sy;
  }

  function fbm(x, y, octaves = 4, lacunarity = 2, gain = 0.5) {
    let sum = 0, amp = 1, freq = 1, norm = 0;
    for (let o = 0; o < octaves; o++) {
      sum += amp * noise(x * freq, y * freq);
      norm += amp;
      amp *= gain;
      freq *= lacunarity;
    }
    return sum / norm;
  }

  return { noise, fbm };
}
