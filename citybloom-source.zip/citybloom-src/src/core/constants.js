// 築城物語 全域常數
// 比例尺：1 格 ≈ 100 m × 100 m（1 公頃）

export const DEFAULT_MAP_SIZE = 128;
export const SMALL_MAP_SIZE = 96; // 給效能較弱的學校平板

// 海拔以公分儲存在 Uint16 中，海平面 = 10000 cm。
// 這樣才能表現每年幾公釐的海平面上升。
export const SEA_LEVEL_CM = 10000;
export const LEVEL_CM = 200; // 畫面上每一層 = 2 m
export const MAX_LEVEL = 15;
export const MAX_ELEV_CM = SEA_LEVEL_CM + MAX_LEVEL * LEVEL_CM - 1; // 約海拔 30 m

// 等角投影尺寸（未縮放像素）
export const TILE_W = 64;
export const TILE_H = 32;
export const LEVEL_PX = 8; // 每層高度在畫面上的像素
export const BASE_LEVELS = 3; // 地圖邊緣的「地基」厚度（模型感）

// 四段縮放：全景 / 城市 / 街區 / 近看（近看方便平板手指點選）
export const ZOOM_LEVELS = [0.25, 0.5, 1, 2];

// 地表類型（surface 圖層）
export const SURFACE = Object.freeze({
  GRASS: 0,
  FOREST: 1,
  WATER: 2,
  SAND: 3,
  MUDFLAT: 4,
});

export const SURFACE_NAME = Object.freeze({
  [SURFACE.GRASS]: '草地',
  [SURFACE.FOREST]: '樹林',
  [SURFACE.WATER]: '水域',
  [SURFACE.SAND]: '沙岸',
  [SURFACE.MUDFLAT]: '泥灘',
});

// 分區（zone 圖層，階段二開始使用）
export const ZONE = Object.freeze({
  NONE: 0,
  R1: 1, R2: 2,
  C1: 3, C2: 4,
  I1: 5, I2: 6,
});

// 網路位元旗標（net 圖層）
export const NET = Object.freeze({
  ROAD: 1,
  HIGHWAY: 2,
  RAIL: 4,
  POWERLINE: 8,
  PIPE: 16,
  SUBWAY: 32,
  STORM_DRAIN: 64,
  BIKE: 128,
});

// 地表覆蓋位元旗標（cover 圖層，階段六開始使用）
export const COVER = Object.freeze({
  PERMEABLE: 1,
  GREEN_ROOF: 2,
  COOL_ROOF: 4,
  STREET_TREES: 8,
  RAIN_GARDEN: 16,
  UNDERGROUND_GRID: 32,
});

// 公用事業旗標（util 圖層）
export const UTIL = Object.freeze({
  POWERED: 1,
  WATERED: 2,
  WATER_RESTRICTED: 4,
  BLACKOUT: 8,
});

// 狀態旗標（state 圖層）
export const STATE = Object.freeze({
  ON_FIRE: 1,
  FLOODED: 2,
  DAMAGED: 4,
  TIDAL: 8,
  SUBMERGED: 16,
});

export const START_YEAR = 2025;
export const START_FUNDS = 50000; // 千元

// 海平面變化預設加速倍數（教師可改為 1 = 真實速度）
export const DEFAULT_SEA_LEVEL_SPEED = 3;
