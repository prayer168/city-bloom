// 簡單事件匯流排：UI 與遊戲邏輯之間的鬆耦合溝通

export class Bus {
  constructor() { this._h = new Map(); }
  on(type, fn) {
    if (!this._h.has(type)) this._h.set(type, new Set());
    this._h.get(type).add(fn);
    return () => this._h.get(type)?.delete(fn);
  }
  emit(type, payload) {
    const set = this._h.get(type);
    if (!set) return;
    for (const fn of set) fn(payload);
  }
}
