// 建築成長與衰退
// 長出建築的條件：道路 3 格內、有電（沒有輪流停電）、該類需求為正

import { NET, UTIL } from '../../core/constants.js';
import { Rng } from '../../core/rng.js';
import { ZONE_INFO, GROWTH, LAND_VALUE_NEEDED, occupancy } from '../../data/buildings/zones.js';

// 到最近道路的距離（4 方向，超過 maxD 記為 255）
export function roadDistance(world, maxD = GROWTH.roadReach) {
  const { size } = world;
  const L = world.layers;
  const dist = new Uint8Array(size * size).fill(255);
  let frontier = [];
  for (let i = 0; i < size * size; i++) if (L.net[i] & NET.ROAD) { dist[i] = 0; frontier.push(i); }
  for (let d = 1; d <= maxD && frontier.length; d++) {
    const next = [];
    for (const i of frontier) {
      const x = i % size, y = (i / size) | 0;
      if (x > 0 && dist[i - 1] === 255) { dist[i - 1] = d; next.push(i - 1); }
      if (x < size - 1 && dist[i + 1] === 255) { dist[i + 1] = d; next.push(i + 1); }
      if (y > 0 && dist[i - size] === 255) { dist[i - size] = d; next.push(i - size); }
      if (y < size - 1 && dist[i + size] === 255) { dist[i + size] = d; next.push(i + size); }
    }
    frontier = next;
  }
  return dist;
}

export function updateGrowth(world) {
  const { size } = world;
  const L = world.layers;
  const city = world.city;
  const G = GROWTH;
  // 每個月用不同但可重現的亂數
  const rng = new Rng((city.seed * 31 + city.year * 12 + city.month) >>> 0);
  const roadDist = roadDistance(world);
  world.roadDist = roadDist;
  const changed = [];

  const hasJobs = city.jobs.c + city.jobs.i > 0;
  const hasPeople = city.population > 0;
  const jobAccess = world.jobAccess;
  const workerAccess = world.workerAccess;

  for (let i = 0; i < size * size; i++) {
    const z = L.zone[i];
    if (!z) continue;
    const info = ZONE_INFO[z];
    const kind = info.kind;
    const demand = city.demandRCI[kind];
    const powered = (L.util[i] & UTIL.POWERED) !== 0;
    const blackout = (L.util[i] & UTIL.BLACKOUT) !== 0;
    const road = roadDist[i] <= G.roadReach;
    const lv = L.devLevel[i];
    const landV = L.landValue[i];
    // 通勤可及性：住宅要到得了工作，工作地點要找得到住宅（城市裡還沒有對方時不要求）
    const access = kind === 'r' ? (!hasJobs || !jobAccess || jobAccess[i]) : (!hasPeople || !workerAccess || workerAccess[i]);
    // 住宅喜歡地價高的地方；工業喜歡便宜的地
    const lvFactor = kind === 'i' ? 1.3 - (landV / 255) * 0.6 : Math.max(0.5, Math.min(1.3, landV / 110));
    let next = lv;

    if (lv === 0) {
      if (road && powered && !blackout && access && demand > 0 && rng.chance((G.baseChance + G.demandChance * demand) * lvFactor)) next = 1;
    } else if (!powered || !road) {
      if (rng.chance(G.unpoweredDecline)) next = lv - 1;
    } else if (blackout) {
      if (rng.chance(G.blackoutDecline)) next = lv - 1;
    } else if (!access) {
      if (rng.chance(G.noAccessDecline)) next = lv - 1;
    } else if (kind === 'r' && L.pollution[i] > G.pollutionLimit && rng.chance(G.pollutionDecline)) {
      next = lv - 1;
    } else if (demand < -0.2) {
      if (rng.chance(G.negDemandDecline * -demand)) next = lv - 1;
    } else if (lv < info.maxLevel && demand > 0.15) {
      const need = LAND_VALUE_NEEDED[kind][info.dense ? 'dense' : 'light'][lv + 1] || 0;
      if (landV >= need && rng.chance(G.upgradeChance * demand * lvFactor)) next = lv + 1;
    }

    if (next !== lv) {
      L.devLevel[i] = next;
      const occ = occupancy(z, next);
      if (info.kind === 'r') { L.pop[i] = occ; L.jobs[i] = 0; }
      else { L.jobs[i] = occ; L.pop[i] = 0; }
      changed.push(i);
    }
  }
  return changed;
}

export function updatePopulation(world) {
  const { size } = world;
  const L = world.layers;
  let pop = 0, cj = 0, ij = 0;
  for (let i = 0; i < size * size; i++) {
    const z = L.zone[i];
    if (!z || !L.devLevel[i]) continue;
    const k = ZONE_INFO[z].kind;
    if (k === 'r') pop += L.pop[i];
    else if (k === 'c') cj += L.jobs[i];
    else ij += L.jobs[i];
  }
  world.city.population = pop;
  world.city.jobs = { c: cj, i: ij };
}
