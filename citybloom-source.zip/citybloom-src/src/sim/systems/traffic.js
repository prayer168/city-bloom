// 交通：通勤指派
//  1. 每個已開發的格子找 3 格內最近的道路當出入口
//  2. 從所有「有工作的出入口」做一次多起點 Dijkstra（成本含上個月的壅塞），得到每段道路往最近工作的方向
//  3. 每位開車通勤的居民從家門口的道路沿著方向走到工作地點，沿途每格道路的車流 +1
//  4. 同時算出「就業可及性」（住宅到得了工作嗎）與「勞動力可及性」（工作地點到得了住宅嗎）
// 公車站與自行車道會降低汽機車比例。

import { NET } from '../../core/constants.js';
import { ZONE_INFO } from '../../data/buildings/zones.js';
import { TRAFFIC, TRANSIT } from '../../data/transport.js';
import { SMART } from '../../data/ai.js';

const INF = 1e9;

// 道路之間是否相連（與畫面上的道路連接規則相同：高差不超過 1 層）
function roadLinked(world, a, b) {
  const L = world.layers;
  return (L.net[b] & NET.ROAD) && Math.abs(world.level(a) - world.level(b)) <= 1;
}

function roadNeighbors(world, i, out) {
  const { size } = world;
  const x = i % size, y = (i / size) | 0;
  out.length = 0;
  if (x > 0 && roadLinked(world, i, i - 1)) out.push(i - 1);
  if (x < size - 1 && roadLinked(world, i, i + 1)) out.push(i + 1);
  if (y > 0 && roadLinked(world, i, i - size)) out.push(i - size);
  if (y < size - 1 && roadLinked(world, i, i + size)) out.push(i + size);
  return out;
}

// 每格到最近道路（3 格內）的出入口；-1 = 沒有
export function roadAccess(world, reach = 3) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const acc = new Int32Array(n).fill(-1);
  const dist = new Uint8Array(n).fill(255);
  let frontier = [];
  for (let i = 0; i < n; i++) if (L.net[i] & NET.ROAD) { acc[i] = i; dist[i] = 0; frontier.push(i); }
  for (let d = 1; d <= reach && frontier.length; d++) {
    const next = [];
    for (const i of frontier) {
      const x = i % size, y = (i / size) | 0;
      const nb = [];
      if (x > 0) nb.push(i - 1);
      if (x < size - 1) nb.push(i + 1);
      if (y > 0) nb.push(i - size);
      if (y < size - 1) nb.push(i + size);
      for (const j of nb) if (dist[j] === 255) { dist[j] = d; acc[j] = acc[i]; next.push(j); }
    }
    frontier = next;
  }
  return { acc, dist };
}

// 二元堆積（Dijkstra 用）
class Heap {
  constructor() { this.k = []; this.v = []; }
  get size() { return this.k.length; }
  push(key, val) {
    const k = this.k, v = this.v;
    let i = k.length;
    k.push(key); v.push(val);
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (k[p] <= key) break;
      k[i] = k[p]; v[i] = v[p]; i = p;
    }
    k[i] = key; v[i] = val;
  }
  pop() {
    const k = this.k, v = this.v;
    const topV = v[0];
    const lastK = k.pop(), lastV = v.pop();
    if (k.length) {
      let i = 0;
      const n = k.length;
      for (;;) {
        let c = 2 * i + 1;
        if (c >= n) break;
        if (c + 1 < n && k[c + 1] < k[c]) c++;
        if (k[c] >= lastK) break;
        k[i] = k[c]; v[i] = v[c]; i = c;
      }
      k[i] = lastK; v[i] = lastV;
    }
    return topV;
  }
}

// 多起點 Dijkstra：回傳每格道路到最近起點的成本與「往起點的下一格」
function dijkstra(world, sources, edgeCost) {
  const n = world.size * world.size;
  const dist = new Float32Array(n).fill(INF);
  const next = new Int32Array(n).fill(-1);
  const h = new Heap();
  for (const s of sources) { dist[s] = 0; next[s] = s; h.push(0, s); }
  const nb = [];
  while (h.size) {
    const i = h.pop();
    const d = dist[i];
    for (const j of roadNeighbors(world, i, nb)) {
      const nd = d + edgeCost(j);
      if (nd < dist[j]) { dist[j] = nd; next[j] = i; h.push(nd, j); }
    }
  }
  return { dist, next };
}

export function updateTraffic(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const T = TRAFFIC;
  const { acc } = roadAccess(world);
  world.roadAccess = acc;

  // 出入口上的工作數與居民數
  const jobsAt = new Map();
  const homesAt = new Map();
  let totalJobs = 0, totalPop = 0;
  for (let i = 0; i < n; i++) {
    const z = L.zone[i];
    if (!z || !L.devLevel[i]) continue;
    const r = acc[i];
    if (r < 0) continue;
    if (ZONE_INFO[z].kind === 'r') { homesAt.set(r, (homesAt.get(r) || 0) + L.pop[i]); totalPop += L.pop[i]; }
    else { jobsAt.set(r, (jobsAt.get(r) || 0) + L.jobs[i]); totalJobs += L.jobs[i]; }
  }

  // 上個月的車流決定這個月的路線成本（壅塞的路會被避開）
  const prevLoad = world.trafficLoad || new Float32Array(n);
  // AI 智慧號誌：同一條路可以順暢通過更多車
  const sig = world.city.compute?.services?.aiSignals || 0;
  const capacity = T.roadCapacity * (1 + SMART.aiSignals.capacityBoost * sig);
  const cost = (j) => 1 + T.congestionCost * Math.pow(Math.min(3, prevLoad[j] / capacity), 2);
  const toJob = dijkstra(world, [...jobsAt.keys()], cost);
  const toHome = dijkstra(world, [...homesAt.keys()], () => 1);

  // 公車站覆蓋、自行車道覆蓋
  const busCov = coverage(world, (inst) => inst.def === 'busStop', TRANSIT.busStop.radius);
  const bikeCov = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    if (!(L.net[i] & NET.BIKE)) continue;
    const x = i % size, y = (i / size) | 0, r = TRANSIT.bikeLane.radius;
    for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      const nx = x + dx, ny = y + dy;
      if (nx >= 0 && ny >= 0 && nx < size && ny < size && Math.abs(dx) + Math.abs(dy) <= r) bikeCov[ny * size + nx] = 1;
    }
  }

  const load = new Float32Array(n);
  const stats = { workers: 0, car: 0, bus: 0, bike: 0, walk: 0, unreachable: 0, commuteTiles: 0, carKm: 0, busKm: 0, congested: 0, roads: 0 };
  for (let i = 0; i < n; i++) {
    const z = L.zone[i];
    if (!z || !L.devLevel[i] || ZONE_INFO[z].kind !== 'r') continue;
    const workers = L.pop[i] * T.workersPerResident;
    stats.workers += workers;
    const r = acc[i];
    const d = r >= 0 ? toJob.dist[r] : INF;
    if (d > T.maxCommute) { stats.unreachable += workers; continue; }
    const tiles = d + 2; // 成本近似距離（含壅塞），加上兩端從家門、公司走到路上的距離
    let carShare = T.baseCarShare;
    let bus = 0, bike = 0;
    if (busCov[i]) { bus = Math.min(carShare, TRANSIT.busStop.carShareCut); carShare -= bus; }
    if (bikeCov[i] && tiles <= TRANSIT.bikeLane.maxBikeTiles) { bike = Math.min(carShare, TRANSIT.bikeLane.carShareCut); carShare -= bike; }
    const cars = workers * carShare;
    stats.car += cars;
    stats.bus += workers * bus;
    stats.bike += workers * bike;
    stats.walk += workers * (1 - T.baseCarShare);
    stats.commuteTiles += workers * tiles;
    // 沿著方向走到工作地點
    let c = r, steps = 0;
    while (c >= 0 && steps < 400) {
      load[c] += cars;
      const nx = toJob.next[c];
      if (nx === c) break;
      c = nx;
      steps++;
    }
    stats.carKm += cars * (steps + 2) * T.kmPerTile * 2; // 來回
    stats.busKm += workers * bus * (steps + 2) * T.kmPerTile * 2;
  }

  // 寫入圖層：0–255，128 = 剛好滿載
  let loadSum = 0, jamLoad = 0;
  for (let i = 0; i < n; i++) {
    if (!(L.net[i] & NET.ROAD)) { L.traffic[i] = 0; continue; }
    stats.roads++;
    const ratio = load[i] / capacity;
    L.traffic[i] = Math.min(255, Math.round(ratio * 128));
    if (ratio > 1) stats.congested++;
    loadSum += load[i];
    jamLoad += load[i] * Math.min(1, Math.max(0, ratio - 0.7) / 0.8); // 接近滿載後開始走走停停
  }
  world.trafficLoad = load;

  // 可及性：給成長系統使用（住宅到得了工作嗎、工作地點找得到人嗎）
  const jobAccess = new Uint8Array(n);
  const workerAccess = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    const r = acc[i];
    if (r < 0) continue;
    if (toJob.dist[r] <= T.maxCommute) jobAccess[i] = 1;
    if (toHome.dist[r] <= T.maxCommute) workerAccess[i] = 1;
  }
  world.jobAccess = jobAccess;
  world.workerAccess = workerAccess;

  const w = stats.workers || 1;
  world.city.traffic = {
    workers: Math.round(stats.workers),
    carShare: stats.car / w, busShare: stats.bus / w, bikeShare: stats.bike / w, walkShare: stats.walk / w,
    unreachableShare: stats.unreachable / w,
    avgCommuteKm: ((stats.commuteTiles / Math.max(1, stats.workers - stats.unreachable)) * T.kmPerTile),
    carKmPerDay: Math.round(stats.carKm),
    busKmPerDay: Math.round(stats.busKm),
    congestedRoads: stats.congested,
    roads: stats.roads,
    stopGoShare: loadSum > 0 ? jamLoad / loadSum : 0, // 汽機車里程中「走走停停」的比例
    signals: sig,
    totalJobs, totalPop,
  };
  return world.city.traffic;
}

// 建築覆蓋範圍（曼哈頓距離）
export function coverage(world, pred, radius) {
  const { size } = world;
  const cov = new Uint8Array(size * size);
  for (const inst of world.instances.values()) {
    if (!pred(inst)) continue;
    const cx = inst.x + (inst.w - 1) / 2, cy = inst.y + (inst.h - 1) / 2;
    for (let y = Math.max(0, Math.floor(cy - radius)); y <= Math.min(size - 1, Math.ceil(cy + radius)); y++) {
      for (let x = Math.max(0, Math.floor(cx - radius)); x <= Math.min(size - 1, Math.ceil(cx + radius)); x++) {
        if (Math.abs(x - cx) + Math.abs(y - cy) <= radius) cov[y * size + x] = 1;
      }
    }
  }
  return cov;
}
