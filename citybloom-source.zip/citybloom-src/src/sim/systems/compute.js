// 算力分配（每月一開始、交通與供電之前執行）
//   資料中心提供算力；智慧城市設施消耗算力。算力不夠時，每個設施依比例降低效果。
//   資料中心要有電才能運作（用上個月的供電狀態）；嚴重限水時，蒸發式冷卻的資料中心要降載。
//   智慧設施本身也要有電。

import { UTIL } from '../../core/constants.js';
import { DATACENTER, SMART } from '../../data/ai.js';

const powered = (L, i) => (L.util[i] & UTIL.POWERED) && !(L.util[i] & (UTIL.BLACKOUT | UTIL.STORM_OUTAGE));

export function dataCenters(world) {
  return [...world.instances.values()].filter((x) => x.def === 'dataCenter');
}

export function updateCompute(world) {
  const { size } = world;
  const L = world.layers;
  const c = world.city;
  let supply = 0;
  let dcRunning = 0, dcTotal = 0;
  const waterLevel = c.water?.level ?? 0;
  for (const dc of dataCenters(world)) {
    dcTotal++;
    const i0 = dc.y * size + dc.x;
    // 剛蓋好的第一個月還沒有供電紀錄，先當作有電（之後依實際供電）
    const on = dc.firstMonth !== false || powered(L, i0);
    let level = on ? 1 : 0;
    if (on && waterLevel >= 2 && !dc.upgrades?.liquid) level *= 1 - DATACENTER.droughtThrottle;
    dc.operating = level;
    dc.firstMonth = false;
    if (level > 0) dcRunning++;
    supply += DATACENTER.compute * level;
  }
  const services = { aiSignals: 0, aiGrid: 0, aiWeather: 0, aiWater: 0 };
  const facilities = [...world.instances.values()].filter((x) => SMART[x.def]);
  let demand = 0;
  for (const f of facilities) {
    const on = f.firstMonth !== false || powered(L, f.y * size + f.x);
    f.firstMonth = false;
    f.on = on;
    if (on) demand += SMART[f.def].compute;
  }
  const ratio = demand > 0 ? Math.min(1, supply / demand) : 0;
  for (const f of facilities) if (f.on) services[f.def] = Math.max(services[f.def], ratio);
  c.compute = { supply, demand, ratio, services, dcRunning, dcTotal };
  return c.compute;
}
