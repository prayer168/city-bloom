// 碳排放統計：發電、交通、住商、工業四大來源，扣掉樹林吸收
// 同時把排放「放回地圖上」寫進 carbon 圖層（公噸／月），給碳排熱點圖層使用。

import { NET, SURFACE } from '../../core/constants.js';
import { ZONE_INFO } from '../../data/buildings/zones.js';
import { PLANTS } from '../../data/energy.js';
import { EMISSIONS as E, WORLD_PER_CAPITA_T } from '../../data/emissions.js';
import { DATACENTER } from '../../data/ai.js';

export function updateCarbon(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const c = world.city;
  const carbon = L.carbon;
  carbon.fill(0);

  // 發電：放在電廠占地上
  let power = 0;
  for (const inst of world.instances.values()) {
    if (inst.kind !== 'plant') continue;
    const t = inst.lastCO2t || 0;
    power += t;
    const per = t / (inst.w * inst.h);
    for (let y = inst.y; y < inst.y + inst.h; y++) for (let x = inst.x; x < inst.x + inst.w; x++) carbon[y * size + x] += per;
  }
  // 以電力系統的總數為準（含沒有被分配到個別電廠的小數誤差）
  if (c.power) power = c.power.co2t;

  // AI 資料中心：用電的碳排放已經算在「發電」裡，這裡另外標示它占多少
  const dcs = [...world.instances.values()].filter((x) => x.def === 'dataCenter');
  if (c.power && c.power.demandMWh > 0 && dcs.length) {
    const share = (c.power.dataCenterMWh || 0) / c.power.demandMWh;
    c.aiCarbon = { share, co2t: power * share };
    for (const dc of dcs) {
      const t = (power * share * (dc.lastMWh || 0)) / Math.max(1, c.power.dataCenterMWh) / 9;
      for (let y = dc.y; y < dc.y + dc.h; y++) for (let x = dc.x; x < dc.x + dc.w; x++) carbon[y * size + x] += t;
    }
  } else c.aiCarbon = null;
  // 廢熱回收：資料中心附近的住宅用回收的熱燒熱水，少用瓦斯
  const heatRec = dcs.filter((d) => d.upgrades?.heatRecovery && (d.operating ?? 1) > 0);
  const HR = DATACENTER.upgrades.heatRecovery;
  const nearRecovery = (i) => heatRec.some((d) => Math.max(Math.abs(i % size - (d.x + 1)), Math.abs(((i / size) | 0) - (d.y + 1))) <= HR.r);

  // 住商與工業：放在各自的格子上
  let buildings = 0, industry = 0;
  for (let i = 0; i < n; i++) {
    const z = L.zone[i];
    if (!z || !L.devLevel[i]) continue;
    const info = ZONE_INFO[z];
    let t = 0;
    if (info.kind === 'r') { t = L.pop[i] * E.residentPerMonth * (heatRec.length && nearRecovery(i) ? 1 - HR.gasCut : 1); buildings += t; }
    else if (info.kind === 'c') { t = L.jobs[i] * E.commercialJobPerMonth; buildings += t; }
    else { t = L.jobs[i] * E.industrialJobPerMonth[info.dense ? 'dense' : 'light']; industry += t; }
    carbon[i] += t;
  }

  // 交通：依每格道路的車流比例分配
  const tr = c.traffic;
  let transport = 0;
  if (tr) {
    // 塞車走走停停時，每公里多排約 30%；AI 智慧號誌讓這部分減少
    // 智慧號誌：走走停停多出的排放少六成，其他路段車流較順，再少約 5%
    const sig = tr.signals || 0;
    const stopGo = (tr.stopGoShare || 0) * E.stopGoExtra * (1 - 0.6 * sig);
    const signalCut = sig * 0.05;
    const carKg = E.carKgPerKm * (1 + stopGo) * (1 - signalCut);
    const carT = (tr.carKmPerDay * carKg * E.workDaysPerMonth) / 1000;
    const busT = ((tr.busKmPerDay || 0) * E.busKgPerPassengerKm * E.workDaysPerMonth) / 1000;
    // 通勤以外的日常移動（上學、購物、休閒）也依同樣的運具比例
    const otherKm = c.population * E.nonCommuteKmPerResidentDay * 30;
    const otherT = (otherKm * (tr.carShare * carKg + tr.busShare * E.busKgPerPassengerKm)) / 1000;
    const freightT = (c.jobs.c + c.jobs.i) * E.freightPerJobMonth;
    transport = carT + busT + otherT + freightT;
    c.transportDetail = { commute: carT + busT, daily: otherT, freight: freightT, stopGo, signalCut };
    const load = world.trafficLoad;
    if (load) {
      let sum = 0;
      for (let i = 0; i < n; i++) sum += load[i];
      if (sum > 0) for (let i = 0; i < n; i++) if (load[i] > 0 && L.net[i] & NET.ROAD) carbon[i] += (transport * load[i]) / sum;
    }
  }

  // 新種樹林吸收（原生成熟林不計，見 emissions.js 說明）
  let absorb = 0;
  for (let i = 0; i < n; i++) {
    if (L.surface[i] === SURFACE.FOREST && L.plantedYear[i]) {
      absorb += E.forestPerTileMonth;
      carbon[i] += E.forestPerTileMonth;
    }
  }
  // 砍伐樹林：這個月因建設或砍樹釋放的碳
  const landuse = c.pendingClearT || 0;
  c.pendingClearT = 0;

  const gross = power + transport + buildings + industry + landuse;
  const net = gross + absorb;

  // 近 12 個月（含本月）的年排放與人均
  const hist = c.history.monthly;
  let last11 = 0;
  for (let k = Math.max(0, hist.length - 11); k < hist.length; k++) last11 += hist[k].co2?.net ?? 0;
  const months = Math.min(12, hist.length + 1);
  const annual = ((last11 + net) / months) * 12;
  const perCapita = c.population > 0 ? annual / c.population : 0;

  c.carbon = {
    power, transport, buildings, industry, landuse, absorb, gross, net,
    annual, perCapita, worldPerCapita: WORLD_PER_CAPITA_T,
    shares: gross > 0 ? {
      power: power / gross, transport: transport / gross, buildings: buildings / gross, industry: industry / gross, landuse: landuse / gross,
    } : { power: 0, transport: 0, buildings: 0, industry: 0, landuse: 0 },
    forestTiles: Math.round(absorb / E.forestPerTileMonth),
  };
  // 起始值：第一次有人口的年排放，給「淨零挑戰」等關卡比較
  if (c.carbonBaseline == null && c.population > 0 && hist.length >= 11) c.carbonBaseline = annual;
  return c.carbon;
}

// 讓測試與介面共用：某一種電廠每月滿載的碳排
export function plantMonthlyCO2(type, cf) {
  const p = PLANTS[type];
  return (p.mw * 730 * cf * p.co2) / 1000;
}
