// RCI 需求（階段三：加入空氣、治安、交通、通勤可及性；稅率在階段八）
//   住宅：有工作機會就有人想搬來；城市剛起步時也有一些基本移入人口
//   商業：人越多，需要的商店與辦公室越多
//   工業：本地人口需要的產品，加上外地訂單
// 需求值介於 -1（太多、會衰退）到 +1（很缺、會快速成長）

export const DEMAND_MODEL = {
  residentsPerJob: 2.0,   // 每個工作約養活 2 位居民（含家人、學生、長輩）
  baseMigrants: 600,      // 城市剛起步時的基本移入人口
  commercialPerResident: 0.22,
  industrialPerResident: 0.26,
  exportIndustry: 400,    // 外地訂單
  // 成長迴圈增益 = 2.0 × (0.22 + 0.26) ≈ 0.96：城市可以成長到數萬人，但最後會受土地與基礎建設限制
};

const clamp = (v) => Math.max(-1, Math.min(1, v));

export function computeDemand(city) {
  const M = DEMAND_MODEL;
  const pop = city.population;
  const cj = city.jobs.c;
  const ij = city.jobs.i;
  // 生活品質：空氣、治安、塞車、找不到工作，都會讓人比較不想搬來
  const air = city.air?.avgExposure ?? 0;
  const crime = city.crimeAvg ?? 0;
  const t = city.traffic;
  const congested = t && t.roads ? t.congestedRoads / t.roads : 0;
  const unreachable = t ? t.unreachableShare : 0;
  const factors = {
    air: -Math.min(0.35, air / 300),
    crime: -Math.min(0.2, crime / 500),
    traffic: -Math.min(0.15, congested * 0.6),
    jobs: -Math.min(0.3, unreachable * 0.4),
    // 階段六：限水與災害讓人比較不想搬來
    water: -Math.min(0.2, (city.water?.resCutFrac ?? 0) * 1.5),
    disaster: -Math.min(0.25, city.disasterStress ?? 0),
  };
  city.demandFactors = factors;
  const quality = 1 + factors.air + factors.crime + factors.traffic + factors.jobs + factors.water + factors.disaster;
  const rTarget = ((cj + ij) * M.residentsPerJob + M.baseMigrants) * quality;
  const cTarget = pop * M.commercialPerResident;
  // 缺水時工廠減產，工業需求跟著下降
  const iTarget = (pop * M.industrialPerResident + M.exportIndustry) * (1 - (city.water?.indCutFrac ?? 0));
  city.demandRCI = {
    r: clamp((rTarget - pop) / Math.max(300, rTarget)),
    c: clamp((cTarget - cj) / Math.max(150, cTarget)),
    i: clamp((iTarget - ij) / Math.max(150, iTarget)),
  };
  return city.demandRCI;
}
