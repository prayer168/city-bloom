// 電力系統
//  1. 電網連通：電線、分區、建築都會導電（道路不會）。用洪水填充找出每一個獨立電網。
//  2. 用電需求：依人口、工作數與季節計算，再分配到一天四個時段（夜、晨、午、晚）。
//  3. 調度：每個電網各自計算一個「典型的一天」：
//       再生能源（不可調度）＋核能（固定出力）→ 不夠先放儲能 → 再開燃煤 → 再開燃氣
//       有剩先充儲能，再剩就是棄電
//     一天算兩遍，讓儲能電量穩定下來（第一遍的晚上會影響第二遍的夜裡）。
//  4. 缺電時輪流停電：離電廠最遠的用戶最先停電。

import { NET, UTIL, ZONE } from '../../core/constants.js';
import { ZONE_INFO } from '../../data/buildings/zones.js';
import {
  PLANTS, RENEWABLE, HOURS_PER_MONTH, DISPATCH_AVAILABILITY, STORAGE_EFFICIENCY,
  DEMAND_PER_RESIDENT, DEMAND_PER_COMMERCIAL_JOB, DEMAND_PER_INDUSTRIAL_JOB,
  SEASONAL_DEMAND, demandSlotShare,
} from '../../data/energy.js';
import { COOLING } from '../../data/climate.js';
import { COVER } from '../../core/constants.js';
import { ADAPT, TYPHOON, ROOF_SOLAR_MW } from '../../data/hazards.js';
import { DATACENTER, SMART } from '../../data/ai.js';

const DAYS = HOURS_PER_MONTH / 24; // 每月約 30.4 天
const SLOT_H = 6;

// parkIds：公園不導電（公園裡沒有電線）
export function isConductive(L, i, parkIds) {
  return (L.net[i] & NET.POWERLINE) !== 0 || L.zone[i] !== ZONE.NONE || (L.bld[i] !== 0 && !parkIds?.has(L.bld[i]));
}

// 天氣修正後的容量因數：水力看最近的雨量，很多雨的月份太陽能少一點
export function capacityFactor(def, month, climate) {
  const d = PLANTS[def];
  let cf = d.cfByMonth[month - 1];
  if (!climate || climate.rainIndex == null) return cf;
  if (def === 'hydro') cf *= Math.max(0.35, Math.min(1.4, Math.sqrt(climate.rainIndex)));
  if (def === 'solar' && climate.rainIndex > 1.5) cf *= 0.9;
  // 颱風：風速超過風機上限要停機保護
  if (def === 'wind' && climate.windMs >= TYPHOON.windCutoutMs) cf *= 1 - TYPHOON.daysAffected / 30;
  return cf;
}

// 找出所有電網：comp[i] = 電網編號（-1 = 不導電）
export function findGrids(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const comp = new Int32Array(n).fill(-1);
  const grids = [];
  const parkIds = new Set();
  for (const inst of world.instances.values()) if (inst.kind === 'park') parkIds.add(inst.id);
  const stack = new Int32Array(n);
  for (let s = 0; s < n; s++) {
    if (comp[s] !== -1 || !isConductive(L, s, parkIds)) continue;
    const id = grids.length;
    const tiles = [];
    let top = 0;
    stack[top++] = s;
    comp[s] = id;
    while (top) {
      const i = stack[--top];
      tiles.push(i);
      const x = i % size, y = (i / size) | 0;
      if (x > 0) push(i - 1);
      if (x < size - 1) push(i + 1);
      if (y > 0) push(i - size);
      if (y < size - 1) push(i + size);
    }
    grids.push({ id, tiles, plants: [] });
    function push(j) {
      if (comp[j] === -1 && isConductive(L, j, parkIds)) { comp[j] = id; stack[top++] = j; }
    }
  }
  for (const inst of world.instances.values()) {
    if (inst.kind !== 'plant') continue;
    const g = comp[inst.y * size + inst.x];
    if (g >= 0) grids[g].plants.push(inst);
  }
  return { comp, grids };
}

// 每格每月用電（MWh）
// localTemp：每格的當地氣溫（有熱島就比較熱）。沒有氣候資料時（單元測試）改用季節倍數
export function tileDemandMWh(L, i, month, localTemp) {
  const z = L.zone[i];
  if (!z || !L.devLevel[i]) return 0;
  const kind = ZONE_INFO[z].kind;
  const season = localTemp ? coolingFactor(localTemp[i]) : SEASONAL_DEMAND[month - 1];
  if (kind === 'r') return L.pop[i] * DEMAND_PER_RESIDENT * season;
  if (kind === 'c') return L.jobs[i] * DEMAND_PER_COMMERCIAL_JOB * season;
  return L.jobs[i] * DEMAND_PER_INDUSTRIAL_JOB;
}

// 住商用電的冷氣倍數：超過 24 °C 每度多 6%
export function coolingFactor(t) {
  return COOLING.base * (1 + COOLING.perDegree * Math.max(0, t - COOLING.threshold));
}

// 單一電網「典型一天」的調度（純函式，方便測試）
// plants: [{ def, mw, mwh, soc }]，demandDay: 一天四時段需求（MWh）
// flex：可以延後的用電比例（AI 智慧電網的需量反應），會從缺電的時段移到電多的時段
export function dispatchDay(plants, demandDayIn, month, climate = null, { flex = 0 } = {}) {
  const m = month - 1;
  let demandDay = demandDayIn;
  const varSlot = [0, 0, 0, 0];
  const genBySource = {};
  const varBySourceSlot = {};
  let baseloadMW = 0, coalMW = 0, gasMW = 0, storMW = 0, storMWh = 0;
  for (const p of plants) {
    const d = PLANTS[p.def];
    genBySource[p.def] = genBySource[p.def] || 0;
    if (d.kind === 'variable') {
      const day = (p.mw ?? d.mw) * capacityFactor(p.def, month, climate) * 24;
      const arr = (varBySourceSlot[p.def] = varBySourceSlot[p.def] || [0, 0, 0, 0]);
      for (let k = 0; k < 4; k++) { const e = day * d.slot[k]; varSlot[k] += e; arr[k] += e; }
    } else if (d.kind === 'baseload') baseloadMW += d.mw * d.cf;
    else if (d.kind === 'storage') { storMW += p.mw ?? d.mw; storMWh += p.mwh ?? d.mwh; }
    else if (p.def === 'coal') coalMW += d.mw * DISPATCH_AVAILABILITY;
    else if (p.def === 'gas') gasMW += d.mw * DISPATCH_AVAILABILITY;
  }
  let soc = plants.reduce((a, p) => a + (PLANTS[p.def].kind === 'storage' ? p.soc || 0 : 0), 0);
  soc = Math.min(soc, storMWh);
  // 需量反應：先把缺電時段的一部分用電，移到再生能源有剩的時段
  let shifted = 0;
  if (flex > 0) {
    const base0 = baseloadMW * SLOT_H;
    const net = demandDay.map((d, k) => varSlot[k] + base0 - d);
    const dd = demandDay.slice();
    for (let k = 0; k < 4; k++) {
      if (net[k] >= 0) continue;
      let need = Math.min(-net[k], dd[k] * flex);
      for (let j = 0; j < 4 && need > 0; j++) {
        if (j === k) continue;
        const room = varSlot[j] + base0 - dd[j];
        if (room <= 0) continue;
        const mv = Math.min(need, room);
        dd[k] -= mv; dd[j] += mv; need -= mv; shifted += mv;
      }
    }
    demandDay = dd;
  }

  let result;
  for (let pass = 0; pass < 2; pass++) {
    result = { slots: [], curtailed: 0, unserved: 0, charged: 0, discharged: 0, coal: 0, gas: 0, nuclear: 0, varUsed: 0, socEnd: 0 };
    for (let k = 0; k < 4; k++) {
      const demand = demandDay[k];
      const base = baseloadMW * SLOT_H;
      const vari = varSlot[k];
      let net = vari + base - demand;
      const slot = { demand, variable: vari, baseload: base, charge: 0, discharge: 0, coal: 0, gas: 0, curtailed: 0, unserved: 0 };
      if (net >= 0) {
        const room = (storMWh - soc) / STORAGE_EFFICIENCY;
        const c = Math.min(net, storMW * SLOT_H, Math.max(0, room));
        soc += c * STORAGE_EFFICIENCY;
        slot.charge = c;
        slot.curtailed = net - c;
      } else {
        let short = -net;
        const dis = Math.min(short, storMW * SLOT_H, soc);
        soc -= dis; short -= dis; slot.discharge = dis;
        const c = Math.min(short, coalMW * SLOT_H); short -= c; slot.coal = c;
        const g = Math.min(short, gasMW * SLOT_H); short -= g; slot.gas = g;
        slot.unserved = short;
      }
      // 棄電時，從再生能源與核能等比例扣掉
      const produced = vari + base;
      const used = produced - slot.curtailed;
      const usedFrac = produced > 0 ? used / produced : 0;
      slot.varUsed = vari * usedFrac;
      slot.baseUsed = base * usedFrac;
      result.slots.push(slot);
      result.curtailed += slot.curtailed;
      result.unserved += slot.unserved;
      result.charged += slot.charge;
      result.discharged += slot.discharge;
      result.coal += slot.coal;
      result.gas += slot.gas;
      result.nuclear += slot.baseUsed;
      result.varUsed += slot.varUsed;
      for (const [src, arr] of Object.entries(varBySourceSlot)) {
        genBySource[src] = (genBySource[src] || 0) + (pass === 1 && vari > 0 ? arr[k] * usedFrac : 0);
      }
    }
    result.socEnd = soc;
  }
  genBySource.coal = (genBySource.coal || 0) + result.coal;
  genBySource.gas = (genBySource.gas || 0) + result.gas;
  if (baseloadMW > 0) genBySource.nuclear = result.nuclear;
  genBySource.battery = result.discharged;
  result.genBySource = genBySource;
  result.shifted = shifted;
  result.storageMWh = storMWh;
  return result;
}

// 每月執行：更新 util 旗標、電廠統計，並把城市電力報告寫到 world.city.power
export function updatePower(world) {
  const { size } = world;
  const L = world.layers;
  const month = world.city.month;
  const n = size * size;
  const { comp, grids } = findGrids(world);
  const share = demandSlotShare(month);

  const totals = {
    demandMWh: 0, servedMWh: 0, unservedMWh: 0, curtailedMWh: 0,
    genBySource: {}, co2t: 0, fuelCost: 0, slots: [0, 1, 2, 3].map(() => ({ demand: 0, supply: {}, unserved: 0, curtailed: 0, charge: 0 })),
    storageMWh: 0, storageSoc: 0, grids: 0, gridsWithoutPlant: 0, unpoweredTiles: 0, blackoutTiles: 0, blackoutHours: 0,
    nuclearWasteT: 0,
  };

  for (let i = 0; i < n; i++) L.util[i] &= ~(UTIL.POWERED | UTIL.BLACKOUT | UTIL.BACKUP_POWER);
  const ym = world.city.year * 12 + month;
  // 調適設施的用電（抽水站、再生水廠、海水淡化廠、涼爽中心）
  const facilityDemand = new Map();
  const dcGreen = new Map(); // 資料中心所在格 → 遠端綠電契約
  totals.dataCenterMWh = 0;
  const hw = world.city.climate?.heatwave;
  for (const inst of world.instances.values()) {
    if (inst.def === 'dataCenter') {
      const D = DATACENTER;
      const pue = (inst.upgrades?.liquid ? D.pue.liquid : D.pue.air) + (hw ? (D.heatwavePueAdd * hw.days) / 30 : 0);
      const mwh = D.itMW * pue * HOURS_PER_MONTH * (inst.operating ?? 1);
      inst.lastPue = pue;
      inst.lastMWh = mwh;
      facilityDemand.set(inst.y * size + inst.x, mwh);
      totals.dataCenterMWh += mwh;
      if (inst.upgrades?.green) dcGreen.set(inst.y * size + inst.x, D.upgrades.green);
      continue;
    }
    const d = ADAPT[inst.def] || SMART[inst.def];
    if (!d || !d.powerMWh) continue;
    let mwh = d.powerMWh;
    if (inst.def === 'coolingCenter' && !world.heatwaveTemp) mwh *= 0.3;
    facilityDemand.set(inst.y * size + inst.x, mwh);
  }
  const flex = (world.city.compute?.services?.aiGrid || 0) * SMART.aiGrid.flexShare;
  totals.shiftedMWh = 0;
  totals.facilityMWh = 0;
  totals.heatwave = null;

  for (const g of grids) {
    // 用電需求
    let demandMonth = 0;
    const consumers = [];
    let roofTiles = 0;
    let peakMonth = 0;
    const greenContracts = [];
    for (const i of g.tiles) {
      const gc = dcGreen.get(i);
      if (gc) greenContracts.push(gc);
      let d = tileDemandMWh(L, i, month, world.localTemp);
      const fd = facilityDemand.get(i);
      if (fd) { d += fd; totals.facilityMWh += fd; }
      if (d > 0) { demandMonth += d; consumers.push([i, d]); }
      if (world.heatwaveMean) peakMonth += tileDemandMWh(L, i, month, world.heatwaveMean) + (fd || 0);
      if ((L.cover[i] & COVER.ROOF_SOLAR) && L.devLevel[i]) roofTiles++;
    }
    const hasConsumers = consumers.length > 0;
    if (!g.plants.length) {
      if (hasConsumers) totals.gridsWithoutPlant++;
      totals.unpoweredTiles += consumers.length;
      totals.demandMWh += demandMonth;
      totals.unservedMWh += demandMonth;
      continue;
    }
    totals.grids++;
    const demandDay = share.map((s) => (demandMonth * s) / DAYS);
    // 停機中的電廠（例如被強颱吹壞的風機）不發電；屋頂光電當成一座「虛擬太陽光電場」
    const active = g.plants.filter((p) => !(p.offlineUntil > ym));
    const fleet = roofTiles ? [...active, { def: 'solar', mw: roofTiles * ROOF_SOLAR_MW, rooftop: true }] : [...active];
    // 資料中心的遠端綠電契約：城外的風電與太陽能，透過電網送進來
    for (const gc of greenContracts) fleet.push({ def: 'wind', mw: gc.windMW, contract: true }, { def: 'solar', mw: gc.solarMW, contract: true });
    const r = dispatchDay(fleet, demandDay, month, world.city.climate, { flex });
    totals.shiftedMWh += (r.shifted || 0) * DAYS;
    // 熱浪尖峰日：冷氣全開，看電夠不夠
    let peakWorst = 0;
    if (world.heatwaveMean && peakMonth > 0) {
      const peakDay = share.map((s) => (peakMonth * s) / DAYS);
      const rp = dispatchDay(fleet, peakDay, month, world.city.climate, { flex });
      rp.slots.forEach((s) => { if (s.demand > 0) peakWorst = Math.max(peakWorst, s.unserved / s.demand); });
      const hwTot = totals.heatwave || (totals.heatwave = { normalDayMWh: 0, peakDayMWh: 0, peakUnservedMWh: 0, blackoutTiles: 0 });
      hwTot.normalDayMWh += demandMonth / DAYS;
      hwTot.peakDayMWh += peakMonth / DAYS;
      hwTot.peakUnservedMWh += rp.unserved;
    }

    // 有接上電廠的格子都標為有電
    for (const i of g.tiles) L.util[i] |= UTIL.POWERED;

    // 輪流停電：缺口最大的時段，依比例讓最遠的用戶停電
    let worst = 0, shortSlots = 0;
    r.slots.forEach((s) => {
      if (s.demand > 0) worst = Math.max(worst, s.unserved / s.demand);
      if (s.unserved > 1e-6) shortSlots++;
    });
    const fromHeat = peakWorst > worst;
    worst = Math.max(worst, peakWorst);
    if (worst > 1e-6 && hasConsumers) {
      const dist = distanceFromPlants(world, comp, g);
      consumers.sort((a, b) => dist[b[0]] - dist[a[0]]);
      let cut = 0;
      const target = worst * demandMonth;
      for (const [i, d] of consumers) {
        if (cut >= target - 1e-9) break;
        // 有屋頂光電＋儲電的建築自己撐得住
        if (L.cover[i] & COVER.ROOF_SOLAR) { L.util[i] |= UTIL.BACKUP_POWER; cut += d * 0.5; continue; }
        L.util[i] |= UTIL.BLACKOUT;
        cut += d;
        totals.blackoutTiles++;
        if (fromHeat && totals.heatwave) totals.heatwave.blackoutTiles++;
      }
      totals.blackoutHours = Math.max(totals.blackoutHours, shortSlots * SLOT_H);
    }

    // 儲能電量存回電池
    const storages = g.plants.filter((p) => PLANTS[p.def].kind === 'storage');
    const totalMWh = storages.reduce((a, p) => a + PLANTS[p.def].mwh, 0);
    for (const p of storages) p.soc = totalMWh ? (r.socEnd * PLANTS[p.def].mwh) / totalMWh : 0;

    // 每座電廠的本月發電量（同類電廠依容量分配）
    const capByType = {};
    for (const p of fleet) capByType[p.def] = (capByType[p.def] || 0) + (p.mw ?? PLANTS[p.def].mw);
    if (roofTiles) totals.rooftopMW = (totals.rooftopMW || 0) + roofTiles * ROOF_SOLAR_MW;
    for (const p of g.plants) {
      if (p.offlineUntil > ym) { p.lastGenMWh = 0; p.lastCO2t = 0; p.lastCF = 0; continue; }
      const genDay = r.genBySource[p.def] || 0;
      const mwh = (genDay * DAYS * PLANTS[p.def].mw) / capByType[p.def];
      p.lastGenMWh = mwh;
      p.lastCO2t = (mwh * PLANTS[p.def].co2) / 1000;
      p.lastCF = mwh / (PLANTS[p.def].mw * HOURS_PER_MONTH);
    }

    // 加總
    totals.demandMWh += demandMonth;
    totals.unservedMWh += r.unserved * DAYS;
    totals.curtailedMWh += r.curtailed * DAYS;
    totals.storageMWh += r.storageMWh;
    totals.storageSoc += r.socEnd;
    for (const [src, day] of Object.entries(r.genBySource)) {
      const mwh = day * DAYS;
      totals.genBySource[src] = (totals.genBySource[src] || 0) + mwh;
      if (src !== 'battery') {
        totals.co2t += (mwh * PLANTS[src].co2) / 1000;
        totals.fuelCost += mwh * PLANTS[src].fuel;
        if (src === 'nuclear') totals.nuclearWasteT += mwh * PLANTS.nuclear.wastePerMWh;
      }
    }
    r.slots.forEach((s, k) => {
      const t = totals.slots[k];
      t.demand += s.demand * DAYS;
      t.unserved += s.unserved * DAYS;
      t.curtailed += s.curtailed * DAYS;
      t.charge += s.charge * DAYS;
      const add = (key, v) => { t.supply[key] = (t.supply[key] || 0) + v * DAYS; };
      add('coal', s.coal); add('gas', s.gas); add('battery', s.discharge);
      if (s.baseUsed) add('nuclear', s.baseUsed);
      const frac = s.variable > 0 ? s.varUsed / s.variable : 0;
      for (const p of fleet) {
        const d = PLANTS[p.def];
        if (d.kind !== 'variable') continue;
        add(p.def, (p.mw ?? d.mw) * capacityFactor(p.def, month, world.city.climate) * 24 * d.slot[k] * frac);
      }
    });
  }
  // 沒接到任何電網的已開發格子
  for (let i = 0; i < n; i++) {
    if (comp[i] === -1 && L.devLevel[i]) totals.unpoweredTiles++;
  }

  let gen = 0, renew = 0;
  for (const [src, v] of Object.entries(totals.genBySource)) {
    if (src === 'battery') continue;
    gen += v;
    if (RENEWABLE.has(src)) renew += v;
  }
  totals.generationMWh = gen;
  totals.servedMWh = totals.demandMWh - totals.unservedMWh;
  totals.renewableShare = gen > 0 ? renew / gen : 0;
  // 每格冷氣用電（下個月的冷氣廢熱用）
  const lt = world.localTemp;
  if (lt) {
    const cool = world.coolingLoad && world.coolingLoad.length === n ? world.coolingLoad : (world.coolingLoad = new Float32Array(n));
    let coolSum = 0;
    for (let i = 0; i < n; i++) {
      cool[i] = 0;
      const z = L.zone[i];
      if (!z || !L.devLevel[i] || ZONE_INFO[z].kind === 'i') continue;
      const extra = COOLING.base * COOLING.perDegree * Math.max(0, lt[i] - COOLING.threshold);
      const per = ZONE_INFO[z].kind === 'r' ? L.pop[i] * DEMAND_PER_RESIDENT : L.jobs[i] * DEMAND_PER_COMMERCIAL_JOB;
      cool[i] = per * extra;
      coolSum += cool[i];
    }
    totals.coolingMWh = coolSum;
  }
  world.city.power = totals;
  world.city.nuclearWasteT += totals.nuclearWasteT;
  return totals;
}

// 電網內每格到最近電廠的距離（沿導電格）
function distanceFromPlants(world, comp, grid) {
  const { size } = world;
  const dist = new Int32Array(size * size).fill(1 << 29);
  const q = [];
  for (const p of grid.plants) {
    for (let y = p.y; y < p.y + p.h; y++) for (let x = p.x; x < p.x + p.w; x++) {
      const i = y * size + x;
      dist[i] = 0;
      q.push(i);
    }
  }
  for (let h = 0; h < q.length; h++) {
    const i = q[h];
    const x = i % size, y = (i / size) | 0;
    const nb = [];
    if (x > 0) nb.push(i - 1);
    if (x < size - 1) nb.push(i + 1);
    if (y > 0) nb.push(i - size);
    if (y < size - 1) nb.push(i + size);
    for (const j of nb) {
      if (comp[j] === grid.id && dist[j] > dist[i] + 1) { dist[j] = dist[i] + 1; q.push(j); }
    }
  }
  return dist;
}
