// 淹水模型（純計算，不修改世界）
//
// 1. 內水（下大雨，排水來不及）：
//    每格逕流 = 雨量 × 逕流係數 − 可以留住的雨（雨水花園、雨水回收）− 下水道排得掉的量
//    滯洪池先收集附近的逕流；剩下的水依地形往低處流，在窪地積起來（細胞自動機，水面高的往水面低的流）；
//    最後抽水站把積水抽走（要有電）。
// 2. 外水（河川氾濫）：雨量大時河水位上升，河岸比水位低、又沒有堤防擋住的地方會被淹。
// 3. 海水（暴潮、海平面上升）：海水位 + 漲潮 + 颱風暴潮，比它低、又沒有海堤擋住的海岸低地會被淹。
// 最後的淹水深度取三者最大值。
//
// adapt = false 時忽略所有調適設施，用來回答「如果沒有這些設施，會淹多少？」（災情報告用）。

import { NET, SURFACE, COVER, DEFENSE, ZONE, SEA_LEVEL_CM, UTIL, STATE } from '../../core/constants.js';
import { WATER_BODY } from '../world.js';
import { ZONE_INFO } from '../../data/buildings/zones.js';
import { RUNOFF, DRAIN, FLOOD, ADAPT, INITIAL_LOSS, PONDED_INFIL_M } from '../../data/hazards.js';

const TILE_M2 = 10000;

export function riverStageM(rainMm) {
  return Math.max(0, Math.min(FLOOD.riverStageMaxM, ((rainMm - FLOOD.riverStageStartMm) / 100) * FLOOD.riverStagePer100Mm));
}

// 每格的逕流係數、可留住的雨量（mm）
export function runoffOf(world, i, adapt = true) {
  const L = world.layers;
  const s = L.surface[i];
  if (s === SURFACE.WATER) return null;
  const cv = adapt ? L.cover[i] : 0;
  let C;
  let store = 0;
  let loss = INITIAL_LOSS.natural;
  let infil = PONDED_INFIL_M.natural;
  const bid = L.bld[i];
  const inst = bid ? world.instances.get(bid) : null;
  if (inst) {
    if (inst.kind === 'park') { C = RUNOFF.park; loss = INITIAL_LOSS.park; infil = PONDED_INFIL_M.park; }
    else if (inst.def === 'detentionPond') { C = adapt ? 0 : RUNOFF.park; loss = INITIAL_LOSS.park; infil = PONDED_INFIL_M.park; }
    else if (inst.def === 'solar' || inst.def === 'wind') C = RUNOFF.grass;
    else { C = RUNOFF.plant; loss = INITIAL_LOSS.paved; infil = PONDED_INFIL_M.paved; }
  } else if (L.net[i] & NET.ROAD) {
    C = RUNOFF.road;
    loss = INITIAL_LOSS.paved;
    infil = PONDED_INFIL_M.paved;
    if (cv & COVER.PERMEABLE) { C *= RUNOFF.permeableMult; infil = PONDED_INFIL_M.permeable; }
  } else if (L.zone[i] !== ZONE.NONE) {
    const info = ZONE_INFO[L.zone[i]];
    C = L.devLevel[i] ? (info.dense ? RUNOFF.lotDense : RUNOFF.lotLight) : RUNOFF.lotEmpty;
    loss = L.devLevel[i] ? INITIAL_LOSS.lot : INITIAL_LOSS.natural;
    infil = L.devLevel[i] ? PONDED_INFIL_M.lot : PONDED_INFIL_M.natural;
    if (cv & COVER.PERMEABLE) { C *= RUNOFF.permeableMult; infil = Math.max(infil, PONDED_INFIL_M.permeable); }
    if (cv & COVER.GREEN_ROOF) C *= RUNOFF.greenRoofMult;
    if (cv & COVER.RAIN_HARVEST) store += RUNOFF.rainHarvestStoreMm;
  } else {
    C = s === SURFACE.FOREST ? RUNOFF.forest : s === SURFACE.SAND ? RUNOFF.sand : s === SURFACE.MUDFLAT ? RUNOFF.mudflat : RUNOFF.grass;
    loss = s === SURFACE.FOREST ? INITIAL_LOSS.forest : s === SURFACE.SAND ? INITIAL_LOSS.sand : s === SURFACE.MUDFLAT ? INITIAL_LOSS.mudflat : INITIAL_LOSS.natural;
    infil = s === SURFACE.FOREST ? PONDED_INFIL_M.forest : s === SURFACE.SAND ? PONDED_INFIL_M.sand : s === SURFACE.MUDFLAT ? PONDED_INFIL_M.mudflat : PONDED_INFIL_M.natural;
  }
  store += loss;
  if (cv & COVER.RAIN_GARDEN) { C *= RUNOFF.rainGardenMult; store += RUNOFF.rainGardenStoreMm; infil = Math.max(infil, PONDED_INFIL_M.rainGarden); }
  return { C, store, infil };
}

// 下水道排水能力（mm）：道路 2 格內有基本排水；擴建過的下水道附近加倍
export function drainCapacity(world, adapt = true) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const cap = new Float32Array(n);
  const R = DRAIN.reach;
  for (let i = 0; i < n; i++) {
    if (!(L.net[i] & NET.ROAD)) continue;
    const up = adapt && (L.net[i] & NET.STORM_DRAIN);
    const v = up ? DRAIN.upgradedMm : DRAIN.baseMm;
    const x = i % size, y = (i / size) | 0;
    for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= size || ny >= size) continue;
      const j = ny * size + nx;
      if (cap[j] < v) cap[j] = v;
    }
  }
  return cap;
}

function isPowered(L, i) {
  const u = L.util[i];
  return (u & UTIL.POWERED) && !(u & (UTIL.BLACKOUT | UTIL.STORM_OUTAGE));
}

// 主函式
// opts: { rainMm, adapt, surgeM, seaRiseM, tideM, riverStage }
export function computeFlood(world, opts) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const adapt = opts.adapt !== false;
  const rain = opts.rainMm || 0;
  const elevM = new Float32Array(n);
  const sink = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    elevM[i] = L.elev[i] / 100;
    if (L.surface[i] === SURFACE.WATER || (L.state[i] & STATE.SUBMERGED)) sink[i] = 1;
  }
  const stats = { pondStoredM3: 0, pumpedM3: 0, pumpsOffline: 0, pumpsOnline: 0, leveeBlocked: 0, seawallBlocked: 0, runoffM3: 0, drainedM3: 0 };

  // ---- 1. 內水 ----
  const water = new Float32Array(n);
  const infil = new Float32Array(n);
  const spare = new Float32Array(n); // 本格下水道沒用完的排水能力（公尺）
  const local = new Float32Array(n); // 本格自己排不掉的雨（公尺）
  if (rain > 0) {
    const drain = drainCapacity(world, adapt);
    for (let i = 0; i < n; i++) {
      if (sink[i]) continue;
      const r = runoffOf(world, i, adapt);
      if (!r) continue;
      infil[i] = r.infil;
      const run = Math.max(0, (rain - r.store) * r.C);
      const excess = Math.max(0, run - drain[i]);
      stats.runoffM3 += (run / 1000) * TILE_M2;
      stats.drainedM3 += ((run - excess) / 1000) * TILE_M2;
      water[i] = excess / 1000;
      local[i] = water[i];
      spare[i] = Math.max(0, drain[i] - run) / 1000;
    }
    // 滯洪池：收集附近格子的逕流，近的先收
    if (adapt) {
      for (const inst of world.instances.values()) {
        if (inst.def !== 'detentionPond') continue;
        const d = ADAPT.detentionPond;
        let room = d.capacityM3;
        const cx = inst.x + inst.w / 2 - 0.5, cy = inst.y + inst.h / 2 - 0.5;
        const cells = [];
        const R = d.catchR;
        for (let y = Math.floor(cy - R); y <= Math.ceil(cy + R); y++) for (let x = Math.floor(cx - R); x <= Math.ceil(cx + R); x++) {
          if (x < 0 || y < 0 || x >= size || y >= size) continue;
          const dist = Math.max(Math.abs(x - cx), Math.abs(y - cy));
          if (dist > R + 0.5) continue;
          cells.push([dist, y * size + x]);
        }
        cells.sort((a, b) => a[0] - b[0]);
        for (const [, j] of cells) {
          if (room <= 0) break;
          const v = water[j] * TILE_M2;
          if (v <= 0) continue;
          const take = Math.min(v, room);
          water[j] -= take / TILE_M2;
          room -= take;
          stats.pondStoredM3 += take;
        }
      }
    }
    // 依地形流動：水面高的往水面低的地方流，流進河、海、湖就排掉
    const iters = opts.iterations ?? FLOOD.iterations;
    for (let it = 0; it < iters; it++) {
      let moved = 0;
      for (let i = 0; i < n; i++) {
        const w = water[i];
        if (w < 1e-4 || sink[i]) continue;
        const h = elevM[i] + w;
        const x = i % size, y = (i / size) | 0;
        let best = -1, bh = h;
        let edge = false;
        if (x > 0) { const j = i - 1; const hj = elevM[j] + water[j]; if (hj < bh) { bh = hj; best = j; } } else edge = true;
        if (x < size - 1) { const j = i + 1; const hj = elevM[j] + water[j]; if (hj < bh) { bh = hj; best = j; } } else edge = true;
        if (y > 0) { const j = i - size; const hj = elevM[j] + water[j]; if (hj < bh) { bh = hj; best = j; } } else edge = true;
        if (y < size - 1) { const j = i + size; const hj = elevM[j] + water[j]; if (hj < bh) { bh = hj; best = j; } } else edge = true;
        if (edge) { // 流出地圖外
          const f = w * 0.5;
          water[i] -= f; moved += f;
          continue;
        }
        if (best < 0) continue;
        if (sink[best]) {
          const f = Math.min(w, h - elevM[best]);
          water[i] -= f; moved += f;
        } else {
          const f = Math.min(w, (h - bh) / 2);
          water[i] -= f; water[best] += f; moved += f;
        }
      }
      if (moved < 1e-3) break;
    }
    // 最後的積水不會超過「窪地的深度 + 本格自己排不掉的雨」：
    // 平地與斜坡上流過的水最後都會流走，只有窪地會積起來（窪地深度用 Priority-Flood 填窪算出）
    const fill = filledElevation(world, elevM, sink);
    for (let i = 0; i < n; i++) {
      if (water[i] <= 0) continue;
      const cap = Math.max(0, fill[i] - elevM[i]) + local[i];
      if (water[i] > cap) water[i] = cap;
    }
    // 流過來的積水：下水道還有餘力的地方可以排掉；之後一兩天會繼續滲進地下（泥土地多、水泥地幾乎沒有）
    for (let i = 0; i < n; i++) {
      if (water[i] <= 0) continue;
      const d = Math.min(water[i], spare[i]);
      water[i] -= d;
      stats.drainedM3 += d * TILE_M2;
      water[i] = Math.max(0, water[i] - infil[i]);
    }
    // 抽水站：要有電才能抽
    if (adapt) {
      for (const inst of world.instances.values()) {
        if (inst.def !== 'pumpStation') continue;
        const d = ADAPT.pumpStation;
        const i0 = inst.y * size + inst.x;
        if (!isPowered(L, i0)) { stats.pumpsOffline++; continue; }
        stats.pumpsOnline++;
        let cap = d.pumpM3;
        const cells = [];
        for (let y = inst.y - d.r; y <= inst.y + d.r; y++) for (let x = inst.x - d.r; x <= inst.x + d.r; x++) {
          if (x < 0 || y < 0 || x >= size || y >= size) continue;
          const j = y * size + x;
          if (water[j] > 0.01) cells.push(j);
        }
        cells.sort((a, b) => water[b] - water[a]);
        // 一層一層抽：每次把最深的那幾格抽低 5 公分
        while (cap > 0 && cells.length) {
          let any = false;
          for (const j of cells) {
            if (cap <= 0) break;
            const take = Math.min(water[j], 0.05) * TILE_M2;
            if (take <= 0) continue;
            const t = Math.min(take, cap);
            water[j] -= t / TILE_M2; cap -= t; stats.pumpedM3 += t; any = true;
          }
          if (!any) break;
        }
      }
    }
  }

  const depth = water;

  // ---- 2. 河川氾濫 ----
  const stage = opts.riverStage ?? riverStageM(rain);
  if (stage > 0) {
    const sources = [];
    for (let i = 0; i < n; i++) if (L.surface[i] === SURFACE.WATER && L.waterBody[i] === WATER_BODY.RIVER) sources.push([i, elevM[i] + stage]);
    spreadWater(world, elevM, depth, sources, FLOOD.riverSlopeCmPerTile / 100, adapt ? DEFENSE.LEVEE : 0, stats, 'leveeBlocked');
  }

  // ---- 3. 海水 ----
  const seaLevel = SEA_LEVEL_CM / 100 + (opts.seaRiseM || 0) + (opts.tideM || 0) + (opts.surgeM || 0);
  if ((opts.surgeM || 0) > 0) {
    const sources = [];
    for (let i = 0; i < n; i++) if (L.surface[i] === SURFACE.WATER && L.waterBody[i] === WATER_BODY.SEA) sources.push([i, seaLevel]);
    spreadWater(world, elevM, depth, sources, 0.02, adapt ? DEFENSE.SEAWALL : 0, stats, 'seawallBlocked');
  }
  for (let i = 0; i < n; i++) if (sink[i]) depth[i] = 0;
  return { depth, stats, riverStage: stage };
}

// Priority-Flood 填窪：從地圖邊緣與水體往內，算出每格「水最多能積到多高」（窪地的溢出高度）
export function filledElevation(world, elevM, sink) {
  const { size } = world;
  const n = size * size;
  const F = new Float32Array(n);
  const done = new Uint8Array(n);
  // 二元最小堆
  const heapI = new Int32Array(n * 2);
  const heapV = new Float32Array(n * 2);
  let len = 0;
  const push = (i, v) => {
    let k = len++;
    heapI[k] = i; heapV[k] = v;
    while (k > 0) {
      const p = (k - 1) >> 1;
      if (heapV[p] <= heapV[k]) break;
      [heapI[p], heapI[k]] = [heapI[k], heapI[p]];
      [heapV[p], heapV[k]] = [heapV[k], heapV[p]];
      k = p;
    }
  };
  const pop = () => {
    const i = heapI[0], v = heapV[0];
    len--;
    if (len > 0) {
      heapI[0] = heapI[len]; heapV[0] = heapV[len];
      let k = 0;
      for (;;) {
        const l = 2 * k + 1, r = l + 1;
        let m = k;
        if (l < len && heapV[l] < heapV[m]) m = l;
        if (r < len && heapV[r] < heapV[m]) m = r;
        if (m === k) break;
        [heapI[m], heapI[k]] = [heapI[k], heapI[m]];
        [heapV[m], heapV[k]] = [heapV[k], heapV[m]];
        k = m;
      }
    }
    return [i, v];
  };
  for (let i = 0; i < n; i++) {
    const x = i % size, y = (i / size) | 0;
    if (sink[i] || x === 0 || y === 0 || x === size - 1 || y === size - 1) { F[i] = elevM[i]; done[i] = 1; push(i, elevM[i]); }
  }
  while (len) {
    const [i, v] = pop();
    const x = i % size, y = (i / size) | 0;
    const nb = [];
    if (x > 0) nb.push(i - 1);
    if (x < size - 1) nb.push(i + 1);
    if (y > 0) nb.push(i - size);
    if (y < size - 1) nb.push(i + size);
    for (const j of nb) {
      if (done[j]) continue;
      done[j] = 1;
      F[j] = Math.max(elevM[j], v);
      push(j, F[j]);
    }
  }
  return F;
}

// 從水源往外漫：水面每走一格降低 slope 公尺，比水面低的陸地被淹；遇到 blockBit 的格子擋住
export function spreadWater(world, elevM, depth, sources, slope, blockBit, stats, statKey) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const surf = new Float32Array(n).fill(-1e9);
  const q = [];
  for (const [i, s] of sources) { surf[i] = s; q.push(i); }
  const blocked = new Uint8Array(n);
  for (let h = 0; h < q.length; h++) {
    const i = q[h];
    const s = surf[i] - slope;
    const x = i % size, y = (i / size) | 0;
    const nb = [];
    if (x > 0) nb.push(i - 1);
    if (x < size - 1) nb.push(i + 1);
    if (y > 0) nb.push(i - size);
    if (y < size - 1) nb.push(i + size);
    for (const j of nb) {
      if (L.surface[j] === SURFACE.WATER) continue;
      if (s <= elevM[j] || s <= surf[j]) continue;
      if (blockBit && (L.defense[j] & blockBit)) {
        if (!blocked[j]) { blocked[j] = 1; if (stats) stats[statKey]++; }
        continue;
      }
      surf[j] = s;
      const d = s - elevM[j];
      if (d > depth[j]) depth[j] = d;
      q.push(j);
    }
  }
  return surf;
}

// 淹水統計：哪些格子淹水、影響多少人
export function floodSummary(world, depth) {
  const L = world.layers;
  const n = world.size * world.size;
  let tiles = 0, devTiles = 0, people = 0, evacuees = 0, roads = 0, urban = 0;
  const minD = FLOOD.floodedCm / 100;
  for (let i = 0; i < n; i++) {
    const d = depth[i];
    if (d < minD) continue;
    tiles++;
    if (L.zone[i] || L.net[i] || L.bld[i]) urban++;
    if (L.net[i] & NET.ROAD) roads++;
    if (L.zone[i] && L.devLevel[i]) {
      devTiles++;
      people += L.pop[i];
      if (d >= FLOOD.evacuateCm / 100) evacuees += L.pop[i];
    }
  }
  return { tiles, urban, devTiles, people, evacuees, roads };
}
