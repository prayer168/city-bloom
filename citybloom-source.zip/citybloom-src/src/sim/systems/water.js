// 供水：城市層級的水量收支（設計決策：不做水管網路）
//   區域水庫：蓄水率隨雨量變化，乾旱時下降；低於門檻就依燈號限水。
//   本地水源：再生水廠、海水淡化廠（都要有電）、雨水回收。本地水源不受乾旱影響。
//   限水只影響「由水庫供應」的那一部分，所以本地水源越多，乾旱時越不怕。

import { ZONE, COVER, UTIL } from '../../core/constants.js';
import { ZONE_INFO } from '../../data/buildings/zones.js';
import { WATER, ADAPT } from '../../data/hazards.js';
import { DATACENTER, SMART } from '../../data/ai.js';

const DAYS = 30.4;

export function waterLevelOf(storage) {
  let lv = WATER.levels[0];
  for (const l of WATER.levels) if (storage < l.below) lv = l;
  return lv;
}

export function updateWater(world) {
  const { size } = world;
  const L = world.layers;
  const c = world.city;
  const cl = c.climate;
  const m = c.month - 1;
  const n = size * size;

  // ---- 區域水庫 ----
  const prev = c.water?.storage ?? WATER.startStorage;
  const rainRatio = cl.rainNormal ? cl.rain / cl.rainNormal : 1;
  const inflow = WATER.inflow[m] * Math.min(3, rainRatio);
  const storage = Math.max(0.03, Math.min(1, prev + inflow - WATER.outflow));

  // ---- 用水需求 ----
  const hot = Math.max(0, (cl.temp ?? 25) - 25) * 0.015; // 天氣熱，用水多一點
  let demandRes = 0, demandCom = 0, demandInd = 0;
  let harvest = 0;
  const rainM = (cl.rain ?? 0) / 1000;
  for (let i = 0; i < n; i++) {
    const z = L.zone[i];
    if (z === ZONE.NONE || !L.devLevel[i]) continue;
    const kind = ZONE_INFO[z].kind;
    let d;
    if (kind === 'r') { d = L.pop[i] * WATER.perResidentM3Day * DAYS * (1 + hot); demandRes += d; }
    else if (kind === 'c') { d = L.jobs[i] * WATER.perCommercialJobM3Day * DAYS * (1 + hot); demandCom += d; }
    else { d = L.jobs[i] * WATER.perIndustrialJobM3Day * DAYS; demandInd += d; }
    if (L.cover[i] & COVER.RAIN_HARVEST) harvest += Math.min(d * WATER.rainHarvestMaxShare, rainM * WATER.roofCatchM2 * 0.8);
  }
  // AI 資料中心的冷卻用水（算在工業用水裡，限水時一樣會被減量）
  let demandDC = 0;
  for (const inst of world.instances.values()) {
    if (inst.def !== 'dataCenter') continue;
    const wue = inst.upgrades?.liquid ? DATACENTER.waterM3PerMWh.liquid : DATACENTER.waterM3PerMWh.air;
    const it = DATACENTER.itMW * 730 * (inst.operating ?? 1);
    inst.lastWaterM3 = it * wue;
    demandDC += inst.lastWaterM3;
  }
  demandInd += demandDC;
  // AI 水資源管理：偵測漏水，全市用水量減少
  const aiW = (c.compute?.services?.aiWater || 0) * SMART.aiWater.demandCut;
  const saved = (demandRes + demandCom + demandInd) * aiW;
  if (aiW) { demandRes *= 1 - aiW; demandCom *= 1 - aiW; demandInd *= 1 - aiW; }
  const demand = demandRes + demandCom + demandInd;

  // ---- 本地水源 ----
  let recycled = 0, desal = 0;
  const offline = [];
  for (const inst of world.instances.values()) {
    const d = ADAPT[inst.def];
    if (!d || !d.supplyM3Day) continue;
    const i0 = inst.y * size + inst.x;
    const u = L.util[i0];
    const ok = (u & UTIL.POWERED) && !(u & UTIL.BLACKOUT);
    if (!ok) { offline.push(inst.def); continue; }
    if (inst.def === 'recycledWater') recycled += d.supplyM3Day * DAYS;
    else desal += d.supplyM3Day * DAYS;
  }
  const local = Math.min(demand, recycled + desal + harvest);
  const fromReservoir = Math.max(0, demand - local);

  // ---- 限水 ----
  const level = waterLevelOf(storage);
  // 本地水源先給工業（再生水最適合工業用），剩下的再給住商
  const localForInd = Math.min(demandInd, local);
  const indFromRes = demandInd - localForInd;
  const resComFromRes = Math.max(0, demandRes + demandCom - (local - localForInd));
  const shortInd = indFromRes * level.indCut;
  const shortRes = resComFromRes * level.resCut;
  const shortage = shortInd + shortRes;
  // 給模擬其他部分用的影響：工業產出下降、居民不滿
  const indCutFrac = demandInd > 0 ? shortInd / demandInd : 0;
  const resCutFrac = demandRes + demandCom > 0 ? shortRes / (demandRes + demandCom) : 0;

  c.water = {
    storage, level: level.id, levelName: level.name, levelColor: level.color, dataCenterM3: demandDC * (1 - aiW), aiSavedM3: saved,
    demandM3: demand, demandRes, demandCom, demandInd,
    recycledM3: recycled, desalM3: desal, harvestM3: harvest, localM3: local, localShare: demand > 0 ? local / demand : 0,
    fromReservoirM3: fromReservoir, shortageM3: shortage, indCutFrac, resCutFrac, offline,
  };
  // 限水旗標（格子資訊與圖層用）
  for (let i = 0; i < n; i++) {
    if (L.zone[i] && L.devLevel[i] && level.id >= 2) L.util[i] |= UTIL.WATER_RESTRICTED;
    else L.util[i] &= ~UTIL.WATER_RESTRICTED;
  }
  return c.water;
}
