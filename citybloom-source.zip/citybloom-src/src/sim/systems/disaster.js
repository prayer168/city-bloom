// 極端天氣結算（月中）：算出災情、扣掉損失，並寫一份「災情報告」
// 每份報告都會比較「有調適設施」與「沒有調適設施」的差別，讓學生看到自己的準備發揮了多少作用。

import { NET, UTIL, STATE, COVER } from '../../core/constants.js';
import { Rng } from '../../core/rng.js';
import { ZONE_INFO, occupancy } from '../../data/buildings/zones.js';
import { HEAT } from '../../data/climate.js';
import {
  TYPHOON, HEATWAVE, FLOOD, ADAPT, BUILDING_VALUE, PUBLIC_SHARE_OF_LOSS, REPAIR, WARNING_DAMAGE_CUT, depthDamage, WATER,
} from '../../data/hazards.js';
import { computeFlood, floodSummary } from './flood.js';
import { findGrids } from './power.js';
import { tideHighM } from '../../climate/sealevel.js';

const MAX_REPORTS = 30;

export function buildingValue(L, i) {
  const z = L.zone[i];
  if (!z || !L.devLevel[i]) return 0;
  const info = ZONE_INFO[z];
  return BUILDING_VALUE[info.kind][info.dense ? 'dense' : 'light'] * L.devLevel[i];
}

function setLevel(L, i, lv) {
  const z = L.zone[i];
  L.devLevel[i] = lv;
  const occ = occupancy(z, lv);
  if (ZONE_INFO[z].kind === 'r') { L.pop[i] = occ; L.jobs[i] = 0; } else { L.jobs[i] = occ; L.pop[i] = 0; }
}

const hasWarning = (world) => [...world.instances.values()].some((x) => x.def === 'warningCenter');
const wanStr = (k) => `${Math.round(k / 10).toLocaleString('zh-TW')} 萬`;

// 避難中心：把需要撤離的居民分配到附近的避難中心
function shelterEvacuees(world, evacTiles) {
  const { size } = world;
  const L = world.layers;
  const shelters = [...world.instances.values()].filter((x) => x.def === 'shelter').map((x) => ({ x: x.x, y: x.y, room: ADAPT.shelter.capacity }));
  let need = 0, sheltered = 0;
  for (const i of evacTiles) {
    let p = L.pop[i];
    need += p;
    const x = i % size, y = (i / size) | 0;
    for (const s of shelters) {
      if (p <= 0) break;
      if (Math.max(Math.abs(s.x - x), Math.abs(s.y - y)) > ADAPT.shelter.r || s.room <= 0) continue;
      const t = Math.min(p, s.room);
      s.room -= t; p -= t; sheltered += t;
    }
  }
  return { need, sheltered, shelters: shelters.length };
}

// 結算本月的極端天氣
export function settleDisasters(world, { seaResult } = {}) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const c = world.city;
  const cl = c.climate;
  const changed = [];
  const reports = [];
  const rng = new Rng((c.seed * 6271 + c.year * 53 + c.month * 19 + 101) >>> 0);
  const warn = hasWarning(world);
  const aiW = (c.compute?.services?.aiWeather || 0) * 0.1; // AI 氣象預警：損失再少 10%
  const ym = c.year * 12 + c.month;
  c.broadcasts = c.broadcasts || [];

  // 上個月的淹水退了；損壞的建築有一半會修好
  for (let i = 0; i < n; i++) {
    if (L.floodDepth[i]) { L.floodDepth[i] = 0; changed.push(i); }
    if (L.state[i] & STATE.FLOODED) { L.state[i] &= ~STATE.FLOODED; changed.push(i); }
    if ((L.state[i] & STATE.DAMAGED) && rng.chance(0.5)) { L.state[i] &= ~STATE.DAMAGED; changed.push(i); }
    L.util[i] &= ~UTIL.STORM_OUTAGE;
  }

  let lossK = 0, paidK = 0;
  const events = cl.activeEvents || [];
  const ty = events.find((e) => e.type === 'typhoon');
  const rainEv = events.find((e) => e.type === 'heavyRain');

  // ---------------- 颱風與豪雨 ----------------
  if (ty || rainEv) {
    const ev = ty || rainEv;
    const rep = { type: ev.type, title: ty ? ty.name : '豪雨', y: c.year, m: c.month, rows: [], helped: [], warnings: [] };
    if (ty) rep.rows.push(['近中心最大風速', `每秒 ${ty.windMs} 公尺`]);
    const rainMm = (ty?.rainMm || 0) + (rainEv?.rainMm || 0);
    rep.rows.push(['雨量', `${rainMm} 毫米`]);
    let wind = { brokenLines: 0, savedLines: 0, outageTiles: 0, outagePeople: 0, backupTiles: 0, bldDamaged: 0, turbines: 0, turbinesDamaged: 0 };

    if (ty) {
      const def = TYPHOON.cats[ty.cat];
      // 1. 電線被吹斷（地下化的不會）
      const broken = [];
      for (let i = 0; i < n; i++) {
        if (!(L.net[i] & NET.POWERLINE)) continue;
        const hit = rng.chance(def.lineP);
        if (!hit) continue;
        if (L.cover[i] & COVER.UNDERGROUND_GRID) wind.savedLines++;
        else broken.push(i);
      }
      wind.brokenLines = broken.length;
      // 2. 停電範圍：拿掉斷掉的電線，重新找電網
      if (broken.length) {
        for (const i of broken) L.net[i] &= ~NET.POWERLINE;
        const { comp, grids } = findGrids(world);
        for (const i of broken) L.net[i] |= NET.POWERLINE;
        for (let i = 0; i < n; i++) {
          if (!(L.util[i] & UTIL.POWERED)) continue;
          const g = comp[i];
          const isConsumer = (L.zone[i] && L.devLevel[i]) || L.bld[i];
          if (!isConsumer) continue;
          if (g >= 0 && grids[g].plants.length) continue;
          if (L.cover[i] & COVER.ROOF_SOLAR) { L.util[i] |= UTIL.BACKUP_POWER; wind.backupTiles++; continue; }
          L.util[i] |= UTIL.STORM_OUTAGE;
          wind.outageTiles++;
          wind.outagePeople += L.pop[i];
          changed.push(i);
        }
        const repair = broken.length * REPAIR.powerlinePerTile;
        paidK += repair;
        rep.rows.push(['吹斷的電線', `${broken.length} 格（搶修費 ${wanStr(repair)}）`]);
      }
      // 3. 風機：超過上限要停機；強颱可能吹壞
      for (const inst of world.instances.values()) {
        if (inst.def !== 'wind') continue;
        wind.turbines++;
        if (rng.chance(def.turbineDamageP)) { inst.offlineUntil = ym + 3; wind.turbinesDamaged++; world.instancesVersion = (world.instancesVersion || 0) + 1; }
      }
      // 4. 建築被強風吹壞（透天厝、鐵皮屋比較容易）
      for (let i = 0; i < n; i++) {
        if (!L.zone[i] || !L.devLevel[i]) continue;
        const info = ZONE_INFO[L.zone[i]];
        if (!rng.chance(def.bldP * (info.dense ? 0.5 : 1.3))) continue;
        wind.bldDamaged++;
        lossK += buildingValue(L, i) * 0.15 * (warn ? 1 - WARNING_DAMAGE_CUT : 1);
        L.state[i] |= STATE.DAMAGED;
        changed.push(i);
      }
      if (wind.bldDamaged) rep.rows.push(['被強風吹壞的建築', `${wind.bldDamaged} 棟`]);
      if (wind.turbines) rep.rows.push(['風力發電場', wind.turbinesDamaged ? `${wind.turbinesDamaged} 座受損，停機修理 3 個月` : `風速超過每秒 ${TYPHOON.windCutoutMs} 公尺，停機保護 ${TYPHOON.daysAffected} 天`]);
    }

    // 5. 淹水（先算颱風停電，因為抽水站沒電就不能抽）
    const fopt = { rainMm, surgeM: ty ? ty.surgeM : 0, seaRiseM: cl.seaRiseM || 0, tideM: tideHighM(c.month) * 0.6 };
    const withA = computeFlood(world, { ...fopt, adapt: true });
    const noA = computeFlood(world, { ...fopt, adapt: false });
    const s1 = floodSummary(world, withA.depth);
    const s0 = floodSummary(world, noA.depth);
    let floodLoss = 0, floodLoss0 = 0;
    const evacTiles = [];
    const flooded = [];
    for (let i = 0; i < n; i++) {
      const d = withA.depth[i];
      const d0 = noA.depth[i];
      const v = buildingValue(L, i);
      if (v) floodLoss0 += v * depthDamage(d0);
      if (d < FLOOD.floodedCm / 100) continue;
      flooded.push(i);
      L.floodDepth[i] = Math.min(65535, Math.round(d * 100));
      L.state[i] |= STATE.FLOODED;
      changed.push(i);
      if (v) {
        const frac = depthDamage(d);
        floodLoss += v * frac;
        if (d >= FLOOD.evacuateCm / 100) evacTiles.push(i);
        if (d >= 1) { L.state[i] |= STATE.DAMAGED; if (L.devLevel[i] > 1) setLevel(L, i, L.devLevel[i] - 1); }
      }
    }
    const cut = (warn ? 1 - WARNING_DAMAGE_CUT : 1) * (1 - aiW);
    lossK += floodLoss * cut;
    paidK += s1.roads * REPAIR.roadPerTile;
    const ev2 = shelterEvacuees(world, evacTiles);

    rep.rows.push(['市區淹水', s1.urban ? `${s1.urban} 公頃（其中有建築 ${s1.devTiles} 格）` : '沒有淹水']);
    if (s1.tiles > s1.urban) rep.rows.push(['郊外積水', `${s1.tiles - s1.urban} 公頃（農地、草地、河邊低地）`]);
    rep.rows.push(['受影響居民', `${s1.people.toLocaleString('zh-TW')} 人`]);
    if (withA.riverStage > 0) rep.rows.push(['河川水位', `上漲 ${withA.riverStage.toFixed(1)} 公尺`]);
    if (ty && ty.surgeM) rep.rows.push(['暴潮', `海水面上升 ${ty.surgeM.toFixed(1)} 公尺`]);
    if (ev2.need) rep.rows.push(['需要撤離', `${ev2.need.toLocaleString('zh-TW')} 人${ev2.shelters ? `，避難中心收容 ${ev2.sheltered.toLocaleString('zh-TW')} 人` : '（沒有避難中心）'}`]);
    if (wind.outageTiles) rep.rows.push(['停電', `${wind.outageTiles} 格、約 ${wind.outagePeople.toLocaleString('zh-TW')} 人（電線修好前）`]);

    // ---- 調適設施發揮的作用 ----
    const st = withA.stats;
    if (st.pondStoredM3 > 0) rep.helped.push(['detentionPond', `滯洪池存了 ${Math.round(st.pondStoredM3 / 1000).toLocaleString('zh-TW')} 千立方公尺的雨水`]);
    if (st.pumpedM3 > 0) rep.helped.push(['pumpStation', `抽水站抽走 ${Math.round(st.pumpedM3 / 1000).toLocaleString('zh-TW')} 千立方公尺的積水`]);
    if (st.pumpsOffline > 0) rep.warnings.push(`${st.pumpsOffline} 座抽水站因為停電沒辦法運作`);
    if (st.leveeBlocked > 0) rep.helped.push(['levee', `堤防在 ${st.leveeBlocked} 個地方擋住暴漲的河水`]);
    if (st.seawallBlocked > 0) rep.helped.push(['seawall', `海堤在 ${st.seawallBlocked} 個地方擋住暴潮`]);
    if (wind.savedLines > 0) rep.helped.push(['undergroundGrid', `地下化的電線有 ${wind.savedLines} 格沒被吹斷`]);
    if (wind.backupTiles > 0) rep.helped.push(['roofSolar', `${wind.backupTiles} 棟有屋頂光電＋儲電的建築沒有停電`]);
    if (ev2.sheltered > 0) rep.helped.push(['shelter', `避難中心照顧了 ${ev2.sheltered.toLocaleString('zh-TW')} 位撤離的居民`]);
    if (warn) rep.helped.push(['warningCenter', '預警中心提早通知，居民先做準備，損失少了 15%']);
    if (aiW > 0) rep.helped.push(['aiWeather', `AI 氣象預警提早兩個月看到這次天氣，損失再少 ${Math.round(aiW * 100)}%`]);
    const sponge = countSponge(world);
    if (sponge.total && s0.urban > s1.urban) rep.helped.push(['sponge', `海綿城市設施（${sponge.text}）讓雨水少流到地面`]);
    const savedTiles = s0.urban - s1.urban;
    const savedLoss = Math.max(0, floodLoss0 * cut - floodLoss * cut);
    rep.compare = { withTiles: s1.urban, withoutTiles: s0.urban, totalTiles: s1.tiles, savedTiles, savedLossK: savedLoss, withPeople: s1.people, withoutPeople: s0.people };
    if (!rep.helped.length && s1.urban > 0) rep.warnings.push('城市還沒有防洪設施。試試滯洪池、透水鋪面、雨水花園或抽水站。');
    if (ev2.need > ev2.sheltered) rep.warnings.push(`還有 ${(ev2.need - ev2.sheltered).toLocaleString('zh-TW')} 位居民沒有地方避難`);
    c.disasterStress = (c.disasterStress || 0) + (ev2.need - ev2.sheltered) / Math.max(500, c.population) + wind.outagePeople / Math.max(2000, c.population) * 0.3;
    rep.floodTiles = flooded.slice(0, 1500);
    rep.severity = s1.devTiles > 30 || wind.outageTiles > 40 ? 3 : s1.devTiles > 5 || wind.outageTiles > 5 ? 2 : 1;
    rep.wind = wind;
    reports.push(rep);
  }

  // ---------------- 熱浪 ----------------
  const hw = events.find((e) => e.type === 'heatwave');
  if (hw && world.heatwaveTemp) {
    const peak = world.heatwaveTemp;
    const ac = world.adaptCool;
    let affected = 0, affectedNoAdapt = 0, residents = 0, hottest = 0, coolAvg = 0;
    const hotTiles = [];
    for (let i = 0; i < n; i++) {
      if (!L.zone[i] || !L.devLevel[i] || ZONE_INFO[L.zone[i]].kind !== 'r') continue;
      const p = L.pop[i];
      residents += p;
      const t = peak[i];
      hottest = Math.max(hottest, t);
      const tNo = t - (ac ? ac[i] : 0) * HEAT.airCoupling; // 沒有降溫設施時會更熱
      coolAvg += (ac ? -ac[i] : 0) * p;
      if (t >= HEATWAVE.thresholdC) { affected += p; hotTiles.push(i); }
      if (tNo >= HEATWAVE.thresholdC) affectedNoAdapt += p;
    }
    coolAvg = residents ? (coolAvg / residents) * HEAT.airCoupling : 0;
    // 涼爽中心照顧附近需要的人
    const vulnerable = Math.round(affected * HEATWAVE.vulnerableShare);
    let cared = 0;
    const centers = [...world.instances.values()].filter((x) => x.def === 'coolingCenter').map((x) => ({ x: x.x, y: x.y, room: ADAPT.coolingCenter.capacity }));
    for (const i of hotTiles) {
      let v = Math.round(L.pop[i] * HEATWAVE.vulnerableShare);
      const x = i % size, y = (i / size) | 0;
      for (const s of centers) {
        if (v <= 0) break;
        if (Math.max(Math.abs(s.x - x), Math.abs(s.y - y)) > ADAPT.coolingCenter.r || s.room <= 0) continue;
        const t = Math.min(v, s.room);
        s.room -= t; v -= t; cared += t;
      }
    }
    const pw = c.power?.heatwave;
    const rep = { type: 'heatwave', title: '熱浪', y: c.year, m: c.month, rows: [], helped: [], warnings: [] };
    rep.rows.push(['持續天數', `${hw.days} 天`]);
    rep.rows.push(['最熱的住宅區', `午後約 ${hottest.toFixed(1)} °C`]);
    rep.rows.push(['郊區', `午後約 ${(cl.heatwaveMax ?? cl.tempMax).toFixed(1)} °C`]);
    rep.rows.push(['35 °C 以上的住宅區居民', `${affected.toLocaleString('zh-TW')} 人`]);
    if (pw && pw.normalDayMWh > 0) rep.rows.push(['尖峰日用電', `比平常多 ${Math.round((pw.peakDayMWh / pw.normalDayMWh - 1) * 100)}%`]);
    if (pw && pw.blackoutTiles > 0) rep.rows.push(['電不夠，輪流停電', `${pw.blackoutTiles} 格`]);
    if (vulnerable) rep.rows.push(['需要特別照顧的人', `約 ${vulnerable.toLocaleString('zh-TW')} 人（長者、幼兒、戶外工作者）`]);
    if (coolAvg > 0.05) rep.helped.push(['heatIsland', `公園、行道樹、綠屋頂、冷屋頂讓住宅區平均涼了 ${coolAvg.toFixed(1)} °C`]);
    if (affectedNoAdapt > affected) rep.helped.push(['heatIsland', `如果沒有這些降溫設施，會有 ${affectedNoAdapt.toLocaleString('zh-TW')} 人在 35 °C 以上（多 ${(affectedNoAdapt - affected).toLocaleString('zh-TW')} 人）`]);
    if (cared) rep.helped.push(['coolingCenter', `涼爽中心照顧了 ${cared.toLocaleString('zh-TW')} 人`]);
    if (vulnerable > cared) rep.warnings.push(`還有約 ${(vulnerable - cared).toLocaleString('zh-TW')} 位需要照顧的人沒有涼爽中心可去`);
    if (pw && pw.blackoutTiles > 0) rep.warnings.push('冷氣用電太多，電廠供應不上。可以增加電廠、儲能，或用降溫設施減少冷氣用電。');
    rep.compare = { withPeople: affected, withoutPeople: affectedNoAdapt };
    rep.heatTiles = hotTiles.slice(0, 1500);
    rep.severity = affected > 3000 || (pw && pw.blackoutTiles > 10) ? 3 : affected > 500 ? 2 : 1;
    c.disasterStress = (c.disasterStress || 0) + (vulnerable - cared) / Math.max(1000, c.population);
    reports.push(rep);
  }

  // ---------------- 乾旱與限水 ----------------
  const w = c.water;
  if (w) {
    const prevLevel = c.prevWaterLevel ?? 0;
    if (w.level >= 2 && w.level > prevLevel) {
      const lv = WATER.levels[w.level];
      const rep = { type: 'drought', title: '乾旱缺水', y: c.year, m: c.month, rows: [], helped: [], warnings: [] };
      rep.rows.push(['水庫蓄水率', `${Math.round(w.storage * 100)}%`]);
      rep.rows.push(['限水燈號', lv.name]);
      rep.rows.push(['城市每月用水', `${Math.round(w.demandM3 / 1000).toLocaleString('zh-TW')} 千立方公尺`]);
      rep.rows.push(['本月缺水', `${Math.round(w.shortageM3 / 1000).toLocaleString('zh-TW')} 千立方公尺`]);
      if (w.indCutFrac > 0) rep.rows.push(['工廠減產', `約 ${Math.round(w.indCutFrac * 100)}%`]);
      if (w.recycledM3 > 0) rep.helped.push(['recycledWater', `再生水廠每月供應 ${Math.round(w.recycledM3 / 1000)} 千立方公尺`]);
      if (w.desalM3 > 0) rep.helped.push(['desalination', `海水淡化廠每月供應 ${Math.round(w.desalM3 / 1000)} 千立方公尺`]);
      if (w.harvestM3 > 0) rep.helped.push(['rainHarvest', `雨水回收每月供應 ${Math.round(w.harvestM3 / 1000)} 千立方公尺`]);
      if (w.localM3 > 0) rep.helped.push(['water', `本地水源占城市用水 ${Math.round(w.localShare * 100)}%，這部分不受限水影響`]);
      else rep.warnings.push('城市的水全部來自水庫。再生水廠、雨水回收、海水淡化可以增加備援。');
      if (w.offline.length) rep.warnings.push('有水廠因為沒電停止運作');
      rep.severity = w.level;
      reports.push(rep);
    }
    c.prevWaterLevel = w.level;
    if (w.indCutFrac > 0) lossK += c.jobs.i * w.indCutFrac * 0.4; // 工廠減產的損失
  }

  // ---------------- 海平面上升 ----------------
  if (seaResult) {
    let lost = 0, lostPeople = 0, lostTiles = 0;
    for (const i of seaResult.newSubmerged) {
      lostTiles++;
      if (L.zone[i] && L.devLevel[i]) { lost += buildingValue(L, i); lostPeople += L.pop[i]; setLevel(L, i, 0); changed.push(i); }
    }
    // 漲潮淹水：每個月有機會讓建築損壞、衰退
    let tidalHit = 0;
    for (let i = 0; i < n; i++) {
      if (!(L.state[i] & STATE.TIDAL) || !L.zone[i] || !L.devLevel[i]) continue;
      if (rng.chance(0.06)) { setLevel(L, i, L.devLevel[i] - 1); L.state[i] |= STATE.DAMAGED; changed.push(i); tidalHit++; lossK += buildingValue(L, i) * 0.1; }
    }
    lossK += lost;
    const coastal = cl.coastal || {};
    const yearKey = c.year;
    if (lostTiles >= 3 || (lostTiles > 0 && lostPeople > 0) || (coastal.tidalDev > 0 && c.month === 9 && c.lastSeaReportYear !== yearKey)) {
      // 一年最多一份；有居民被迫搬家時另外再報
      if (c.lastSeaReportYear !== yearKey || lostPeople > 0) {
        const rep = { type: 'sea', title: '海平面上升', y: c.year, m: c.month, rows: [], helped: [], warnings: [] };
        rep.rows.push(['海平面（相對 2025 年）', `上升 ${Math.round((cl.seaRiseM || 0) * 100)} 公分${(cl.seaLevelSpeed ?? 1) !== 1 ? `（已加速 ${cl.seaLevelSpeed} 倍）` : ''}`]);
        rep.rows.push(['被海水淹沒的土地', `${coastal.submerged || 0} 公頃${lostTiles ? `（本月新增 ${lostTiles} 公頃）` : ''}`]);
        rep.rows.push(['漲潮會淹的土地', `${coastal.tidal || 0} 公頃，其中有建築 ${coastal.tidalDev || 0} 格`]);
        if (lostPeople) rep.rows.push(['需要搬家的居民', `${lostPeople.toLocaleString('zh-TW')} 人`]);
        const walls = countDefense(world);
        if (walls.seawall) rep.helped.push(['seawall', `海堤 ${walls.seawall} 格正在保護海岸`]);
        else rep.warnings.push('海岸還沒有海堤。也可以考慮讓低地保留為濕地、把重要建設蓋在高一點的地方。');
        rep.severity = lostPeople > 0 ? 3 : 2;
        rep.seaTiles = [];
        for (let i = 0; i < n && rep.seaTiles.length < 1500; i++) if (L.state[i] & (STATE.SUBMERGED | STATE.TIDAL)) rep.seaTiles.push(i);
        c.lastSeaReportYear = yearKey;
        reports.push(rep);
      }
    }
    void tidalHit;
  }

  // ---------------- 損失入帳 ----------------
  const cityShare = lossK * PUBLIC_SHARE_OF_LOSS + paidK;
  c.funds -= cityShare;
  c.disasterLossYear = (c.month === 1 ? 0 : c.disasterLossYear || 0) + lossK;
  c.disasterStress = Math.max(0, (c.disasterStress || 0) * 0.6);

  for (const rep of reports) {
    c.reportSeq = (c.reportSeq || 0) + 1;
    rep.id = c.reportSeq;
    // 本月的總損失記在第一份報告
    rep.lossK = rep === reports[0] ? lossK : 0;
    rep.cityPaidK = rep === reports[0] ? cityShare : 0;
    c.reports.push(rep);
    c.broadcasts.push({ kind: 'report', type: rep.type, reportId: rep.id, text: broadcastFor(rep) });
  }
  while (c.reports.length > MAX_REPORTS) c.reports.shift();
  for (const rep of reports) c.journal.push({ y: c.year, m: c.month, kind: 'disaster', text: `${rep.title}${rep.compare?.withTiles ? `：淹水 ${rep.compare.withTiles} 公頃` : ''}` });
  return { changed, lossK, cityPaidK: cityShare, reports };
}

function broadcastFor(rep) {
  if (rep.type === 'typhoon') return `${rep.title}過境，災情報告出爐。請到報告查看淹水與停電情形。`;
  if (rep.type === 'heavyRain') return '豪雨過後，災情報告出爐。低窪地區請注意積水。';
  if (rep.type === 'heatwave') return '熱浪來襲，請多喝水、避免中午外出，並關心家中長輩。';
  if (rep.type === 'drought') return '水庫蓄水偏低，啟動限水措施，請大家一起節約用水。';
  if (rep.type === 'sea') return '海平面上升，海岸低地受到海水影響，災情報告出爐。';
  return '災情報告出爐。';
}

function countSponge(world) {
  const L = world.layers;
  const n = world.size * world.size;
  let perm = 0, garden = 0, green = 0, harvest = 0, drains = 0;
  for (let i = 0; i < n; i++) {
    const cv = L.cover[i];
    if (cv & COVER.PERMEABLE) perm++;
    if (cv & COVER.RAIN_GARDEN) garden++;
    if (cv & COVER.GREEN_ROOF) green++;
    if (cv & COVER.RAIN_HARVEST) harvest++;
    if (L.net[i] & NET.STORM_DRAIN) drains++;
  }
  const parts = [];
  if (perm) parts.push(`透水鋪面 ${perm} 格`);
  if (garden) parts.push(`雨水花園 ${garden} 格`);
  if (green) parts.push(`綠屋頂 ${green} 棟`);
  if (harvest) parts.push(`雨水回收 ${harvest} 棟`);
  if (drains) parts.push(`擴建下水道 ${drains} 格`);
  return { total: perm + garden + green + harvest + drains, text: parts.join('、') };
}

export function countDefense(world) {
  const L = world.layers;
  const n = world.size * world.size;
  let levee = 0, seawall = 0;
  for (let i = 0; i < n; i++) { if (L.defense[i] & 1) levee++; if (L.defense[i] & 2) seawall++; }
  return { levee, seawall };
}

// ---------------- 氣候韌性指數（0–100） ----------------
// 淹水防護、供水備援、供電備援、避難、降溫照顧、預警，六項平均
export function computeResilience(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const c = world.city;
  let dev = 0, devSafe = 0, residents = 0, nearShelter = 0, nearCooling = 0, consumers = 0, backup = 0;
  const shelters = [...world.instances.values()].filter((x) => x.def === 'shelter');
  const centers = [...world.instances.values()].filter((x) => x.def === 'coolingCenter');
  const near = (arr, x, y, r) => arr.some((s) => Math.max(Math.abs(s.x - x), Math.abs(s.y - y)) <= r);
  for (let i = 0; i < n; i++) {
    if (!L.zone[i] || !L.devLevel[i]) continue;
    dev++;
    if (L.floodRisk[i] < 30) devSafe++;
    consumers++;
    if (L.cover[i] & COVER.ROOF_SOLAR) backup++;
    if (ZONE_INFO[L.zone[i]].kind === 'r') {
      const x = i % size, y = (i / size) | 0;
      residents += L.pop[i];
      if (near(shelters, x, y, ADAPT.shelter.r)) nearShelter += L.pop[i];
      if (near(centers, x, y, ADAPT.coolingCenter.r)) nearCooling += L.pop[i];
    }
  }
  const p = c.power;
  const storage = p && p.demandMWh > 0 ? Math.min(1, (p.storageMWh || 0) / ((p.demandMWh / 30.4) * 0.15)) : 0;
  const parts = {
    flood: dev ? devSafe / dev : 1,
    water: c.water && c.water.demandM3 > 0 ? Math.min(1, c.water.localShare / 0.3) : 0,
    power: consumers ? Math.min(1, 0.5 * storage + 0.5 * Math.min(1, (backup / consumers) / 0.3) + undergroundShare(world) * 0.3) : 0,
    shelter: residents ? nearShelter / residents : 0,
    cooling: residents ? nearCooling / residents : 0,
    warning: hasWarning(world) ? 1 : 0,
  };
  for (const k of Object.keys(parts)) parts[k] = Math.max(0, Math.min(1, parts[k]));
  const score = Math.round((Object.values(parts).reduce((a, b) => a + b, 0) / 6) * 100);
  c.resilience = { score, parts };
  return c.resilience;
}

function undergroundShare(world) {
  const L = world.layers;
  const n = world.size * world.size;
  let lines = 0, ug = 0;
  for (let i = 0; i < n; i++) if (L.net[i] & NET.POWERLINE) { lines++; if (L.cover[i] & COVER.UNDERGROUND_GRID) ug++; }
  return lines ? ug / lines : 0;
}

// 淹水潛勢：用「設計暴雨」算一次，寫進 floodRisk 圖層（公分，0–255）
export function updateFloodRisk(world) {
  const L = world.layers;
  const n = world.size * world.size;
  const r = computeFlood(world, { rainMm: FLOOD.designStormMm, adapt: true, seaRiseM: world.city.climate.seaRiseM || 0, tideM: 0, iterations: 100 });
  for (let i = 0; i < n; i++) L.floodRisk[i] = Math.min(255, Math.round(r.depth[i] * 100));
  world.floodRiskDirty = false;
  return r;
}

