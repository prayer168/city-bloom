// 空氣污染擴散、地價、犯罪

import { NET, SURFACE } from '../../core/constants.js';
import { ZONE_INFO } from '../../data/buildings/zones.js';
import { PLANTS } from '../../data/energy.js';
import { POLLUTION, LAND_VALUE, CRIME, windOf, aqiLevel } from '../../data/environment.js';

// ---------------- 空氣污染 ----------------
// 來源：工業、電廠、道路車流。每個月擴散幾次並自然消散；樹林會吸收；往下風處飄得比較多。
export function updatePollution(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const P = POLLUTION;
  let field = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const z = L.zone[i];
    if (z && L.devLevel[i] && ZONE_INFO[z].kind === 'i') field[i] += L.jobs[i] * P.perIndustrialJob;
  }
  for (const inst of world.instances.values()) {
    if (inst.kind !== 'plant') continue;
    const lvl = PLANTS[inst.def].pollution;
    if (!lvl) continue;
    // 排放與發電量成正比：城市用電越多，電廠燒得越多
    const running = inst.lastCF === undefined ? 0.5 : Math.min(1.3, inst.lastCF / P.plantFullCF);
    for (let y = inst.y; y < inst.y + inst.h; y++) for (let x = inst.x; x < inst.x + inst.w; x++) field[y * size + x] += lvl * P.perPlantLevel * running;
  }
  const load = world.trafficLoad;
  if (load) for (let i = 0; i < n; i++) if (load[i] > 0) field[i] += load[i] * P.perCar;

  const wind = windOf(world.city.month);
  const park = parkTiles(world);
  const next = new Float32Array(n);
  for (let pass = 0; pass < P.diffusionPasses; pass++) {
    next.fill(0);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const i = y * size + x;
        const v = field[i];
        if (v <= 0.01) continue;
        const spread = (1 - P.keep - P.windShare) / 4;
        next[i] += v * P.keep;
        if (x > 0) next[i - 1] += v * spread;
        if (x < size - 1) next[i + 1] += v * spread;
        if (y > 0) next[i - size] += v * spread;
        if (y < size - 1) next[i + size] += v * spread;
        // 往下風處
        const wx = x + wind.dx, wy = y + wind.dy;
        if (wx >= 0 && wy >= 0 && wx < size && wy < size) next[wy * size + wx] += v * P.windShare;
      }
    }
    for (let i = 0; i < n; i++) {
      let v = next[i] * P.decay;
      if (L.surface[i] === SURFACE.FOREST || park[i]) v *= P.forestAbsorb;
      else if (L.surface[i] === SURFACE.WATER) v *= P.waterAbsorb;
      field[i] = v;
    }
  }

  // 寫入圖層並統計居民實際吸到的空氣
  let exposure = 0, pop = 0;
  const levelCounts = [0, 0, 0, 0];
  for (let i = 0; i < n; i++) {
    const v = Math.min(255, Math.round(field[i]));
    L.pollution[i] = v;
    if (L.pop[i] > 0) {
      exposure += v * L.pop[i];
      pop += L.pop[i];
      levelCounts[aqiLevel(v)] += L.pop[i];
    }
  }
  const avg = pop ? exposure / pop : 0;
  world.city.air = { avgExposure: avg, level: aqiLevel(avg), popByLevel: levelCounts, wind: wind.name };
  return world.city.air;
}

// ---------------- 地價 ----------------
export function updateLandValue(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const V = LAND_VALUE;

  // 市中心 = 人口與工作的加權中心
  let sx = 0, sy = 0, sw = 0;
  for (let i = 0; i < n; i++) {
    const w = L.pop[i] + L.jobs[i];
    if (!w) continue;
    sx += (i % size) * w; sy += ((i / size) | 0) * w; sw += w;
  }
  const cx = sw ? sx / sw : size / 2, cy = sw ? sy / sw : size / 2;
  world.city.center = { x: cx, y: cy };

  const waterD = distanceTo(world, (i) => L.surface[i] === SURFACE.WATER, V.waterReach);
  const park = parkTiles(world);
  const forestD = distanceTo(world, (i) => L.surface[i] === SURFACE.FOREST || park[i] === 1, 3);
  const acc = world.roadAccess;
  const lv = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    if (L.surface[i] === SURFACE.WATER) { lv[i] = 0; continue; }
    const x = i % size, y = (i / size) | 0;
    let v = V.base;
    if (waterD[i] <= V.waterReach) v += V.water * (1 - (waterD[i] - 1) / V.waterReach);
    if (forestD[i] <= 3 && L.surface[i] !== SURFACE.FOREST) v += V.forest * (1 - (forestD[i] - 1) / 3);
    if (sw) {
      const d = Math.hypot(x - cx, y - cy);
      v += V.center * Math.max(0, 1 - d / V.centerReach);
    }
    if (acc && acc[i] >= 0) {
      v += V.road;
      if (L.traffic[acc[i]] > 128) v -= V.congestion * Math.min(1, (L.traffic[acc[i]] - 128) / 128);
    }
    v -= L.pollution[i] * V.pollution;
    v -= L.crime[i] * V.crime;
    lv[i] = v;
  }
  // 平滑一次，讓地價連續
  for (let i = 0; i < n; i++) {
    if (L.surface[i] === SURFACE.WATER) { L.landValue[i] = 0; continue; }
    const x = i % size, y = (i / size) | 0;
    let s = lv[i] * 2, c = 2;
    if (x > 0) { s += lv[i - 1]; c++; }
    if (x < size - 1) { s += lv[i + 1]; c++; }
    if (y > 0) { s += lv[i - size]; c++; }
    if (y < size - 1) { s += lv[i + size]; c++; }
    L.landValue[i] = Math.max(0, Math.min(255, Math.round(s / c)));
  }
}

// ---------------- 犯罪 ----------------
// 人口越密集、地價越低（經濟弱勢）的地方，治安越需要關注。警察局在階段八加入。
export function updateCrime(world) {
  const { size } = world;
  const L = world.layers;
  const n = size * size;
  const C = CRIME;
  const raw = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    if (!L.zone[i] || !L.devLevel[i]) continue;
    const people = L.pop[i] + L.jobs[i];
    raw[i] = C.base + people * C.density + Math.max(0, 120 - L.landValue[i]) * C.poverty;
    if (L.covPolice) raw[i] *= 1 - (L.covPolice[i] / 255) * 0.7;
  }
  let sum = 0, cnt = 0;
  for (let i = 0; i < n; i++) {
    const x = i % size, y = (i / size) | 0;
    let s = raw[i] * 2, c = 2;
    if (x > 0) { s += raw[i - 1]; c++; }
    if (x < size - 1) { s += raw[i + 1]; c++; }
    if (y > 0) { s += raw[i - size]; c++; }
    if (y < size - 1) { s += raw[i + size]; c++; }
    const v = Math.min(255, Math.round(s / c));
    L.crime[i] = v;
    if (L.pop[i]) { sum += v * L.pop[i]; cnt += L.pop[i]; }
  }
  world.city.crimeAvg = cnt ? sum / cnt : 0;
}

// 公園占用的格子
export function parkTiles(world) {
  const { size } = world;
  const out = new Uint8Array(size * size);
  for (const inst of world.instances.values()) {
    if (inst.kind !== 'park') continue;
    for (let y = inst.y; y < inst.y + inst.h; y++) for (let x = inst.x; x < inst.x + inst.w; x++) out[y * size + x] = 1;
  }
  return out;
}

// 到最近符合條件格子的距離（8 方向，maxD 以上記為 maxD+1）
function distanceTo(world, pred, maxD) {
  const { size } = world;
  const n = size * size;
  const d = new Uint8Array(n).fill(maxD + 1);
  let frontier = [];
  for (let i = 0; i < n; i++) if (pred(i)) { d[i] = 0; frontier.push(i); }
  for (let k = 1; k <= maxD && frontier.length; k++) {
    const next = [];
    for (const i of frontier) {
      const x = i % size, y = (i / size) | 0;
      for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
        const nx = x + ox, ny = y + oy;
        if (nx < 0 || ny < 0 || nx >= size || ny >= size) continue;
        const j = ny * size + nx;
        if (d[j] > k) { d[j] = k; next.push(j); }
      }
    }
    frontier = next;
  }
  return d;
}

export { NET };
