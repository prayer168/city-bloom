// 簡易財政（階段八會換成完整的年度預算、撥款比例與債券）
// 收入：住宅與工作的稅收；支出：電廠維護、燃料、道路與電線維護

import { NET } from '../../core/constants.js';
import { PLANTS } from '../../data/energy.js';
import { TAX, UPKEEP } from '../../data/buildings/infra.js';
import { TRANSIT } from '../../data/transport.js';
import { GREEN } from '../../data/climate.js';
import { ADAPT, ADAPT_LINE } from '../../data/hazards.js';
import { COVER, DEFENSE } from '../../core/constants.js';

export function updateFinance(world) {
  const { size } = world;
  const L = world.layers;
  const c = world.city;
  const income = {
    residential: c.population * TAX.perResident * (c.taxes.r / TAX.baseRate),
    commercial: c.jobs.c * TAX.perJob * (c.taxes.c / TAX.baseRate),
    industrial: c.jobs.i * TAX.perJob * (c.taxes.i / TAX.baseRate) * (1 - (c.water?.indCutFrac ?? 0)),
  };
  let roads = 0, lines = 0, adaptLines = 0;
  for (let i = 0; i < size * size; i++) {
    if (L.net[i] & NET.ROAD) roads++;
    if (L.net[i] & NET.POWERLINE) lines++;
    if (L.defense[i] & DEFENSE.LEVEE) adaptLines += ADAPT_LINE.levee.upkeep;
    if (L.defense[i] & DEFENSE.SEAWALL) adaptLines += ADAPT_LINE.seawall.upkeep;
    if (L.net[i] & NET.STORM_DRAIN) adaptLines += ADAPT_LINE.drain.upkeep;
    if (L.cover[i] & COVER.UNDERGROUND_GRID) adaptLines += ADAPT_LINE.undergroundGrid.upkeep;
  }
  let adapt = adaptLines;
  let plantUpkeep = 0;
  let transit = 0;
  for (const inst of world.instances.values()) {
    if (inst.kind === 'plant') plantUpkeep += PLANTS[inst.def].upkeep;
    else if (TRANSIT[inst.def]) transit += TRANSIT[inst.def].upkeep;
    else if (GREEN[inst.def]?.upkeep) transit += GREEN[inst.def].upkeep;
    else if (ADAPT[inst.def]) adapt += ADAPT[inst.def].upkeep;
  }
  const expense = {
    plants: plantUpkeep,
    fuel: c.power ? c.power.fuelCost : 0,
    roads: roads * UPKEEP.roadPerTile + lines * UPKEEP.powerlinePerTile,
    transit, // 公車站與公園的維護
    adapt,   // 氣候調適設施的維護
  };
  const inSum = Object.values(income).reduce((a, b) => a + b, 0);
  const outSum = Object.values(expense).reduce((a, b) => a + b, 0);
  c.funds += inSum - outSum;
  c.lastMonth = { income, expense, net: inSum - outSum };
  return c.lastMonth;
}
