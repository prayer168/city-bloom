// Web Worker：模擬在背景執行緒跑，畫面不會因為計算而卡住。
import { SimCore } from './core.js';

const core = new SimCore((msg, transfer) => self.postMessage(msg, transfer));
self.onmessage = (e) => {
  try {
    core.handle(e.data);
  } catch (err) {
    self.postMessage({ type: 'error', message: String(err && err.stack || err) });
  }
};
