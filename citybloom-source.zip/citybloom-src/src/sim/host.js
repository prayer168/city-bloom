// 主執行緒這一端：啟動模擬（優先用 Web Worker，失敗就在主執行緒跑），
// 並維護一份「鏡像」世界給畫面與介面讀取。鏡像只讀，所有修改都透過指令送去模擬端。

import SimWorker from './worker.js?worker&inline';
import { SimCore } from './core.js';
import { World } from './world.js';

export class SimHost {
  constructor({ onState, onUpdate, onError } = {}) {
    this.onState = onState;
    this.onUpdate = onUpdate;
    this.onError = onError;
    this.world = null;
    this.pending = new Map();
    this.nextId = 1;
    this.mode = 'worker';
    try {
      this.worker = new SimWorker();
      this.worker.onmessage = (e) => this.receive(e.data);
      this.worker.onerror = (e) => this.fallback(e);
      this.send = (msg) => this.worker.postMessage(msg);
    } catch (err) {
      this.fallback(err);
    }
  }

  // Worker 無法使用時（極少數瀏覽器或嵌入環境），改在主執行緒執行
  fallback(err) {
    if (this.mode === 'local') return;
    console.warn('[築城物語] Web Worker 無法使用，改在主執行緒模擬：', err?.message || err);
    this.mode = 'local';
    this.worker?.terminate?.();
    const core = new SimCore((msg) => queueMicrotask(() => this.receive(msg)));
    this.send = (msg) => queueMicrotask(() => core.handle(msg));
    if (this.lastInit) this.send(this.lastInit);
  }

  init(map) {
    this.lastInit = { type: 'init', map };
    this.send(this.lastInit);
  }

  setSpeed(value) { this.send({ type: 'speed', value }); }
  step(months = 1) { this.send({ type: 'step', months }); }

  command(cmd) {
    const id = this.nextId++;
    return new Promise((resolve) => {
      this.pending.set(id, resolve);
      this.send({ type: 'command', id, cmd });
    });
  }

  receive(msg) {
    if (msg.type === 'error') { console.error('[模擬錯誤]', msg.message); this.onError?.(msg.message); return; }
    if (msg.type === 'state') {
      const w = new World(msg.size);
      this.world = w;
      w.history = [];
    }
    const w = this.world;
    if (!w) return;
    for (const [name, arr] of Object.entries(msg.layers)) w.layers[name] = arr;
    w.city = { ...msg.city, history: w.city.history };
    if (msg.instances) {
      w.instances = new Map(msg.instances.map((x) => [x.id, x]));
      w.instancesVersion = (w.instancesVersion || 0) + 1;
    }
    if (msg.history) w.city.history.monthly.push(...msg.history);
    w.version++;
    if (msg.type === 'state') this.onState?.(w, msg);
    else {
      this.onUpdate?.(w, msg);
      if (msg.id && this.pending.has(msg.id)) {
        this.pending.get(msg.id)(msg.result);
        this.pending.delete(msg.id);
      }
    }
  }
}
