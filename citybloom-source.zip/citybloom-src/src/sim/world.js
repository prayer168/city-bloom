// WorldState：整張地圖的資料。
// 採「陣列結構」（Structure of Arrays）：每種屬性一條 TypedArray，
// 第 i 格的資料在每條陣列的第 i 個位置（i = y * size + x）。
// 好處：可零複製傳給 Web Worker、擴散計算快、存檔容易。
// 本檔不碰 DOM，可在 Worker 與 Node（測試）中執行。

import {
  DEFAULT_MAP_SIZE, SEA_LEVEL_CM, LEVEL_CM, MAX_LEVEL, SURFACE,
  START_YEAR, START_FUNDS, DEFAULT_SEA_LEVEL_SPEED,
} from '../core/constants.js';

// 每條圖層的型別。新增圖層只要加在這裡。
export const LAYER_SPEC = Object.freeze({
  elev: Uint16Array,       // 海拔（公分），海平面 = 10000
  surface: Uint8Array,     // 地表類型
  zone: Uint8Array,        // 分區
  bld: Uint16Array,        // 建築實例 ID（0 = 無），電廠等放置型建築
  devLevel: Uint8Array,    // 分區上自動長出的建築等級（0 = 空地）
  waterBody: Uint8Array,   // 水體種類：0 陸地、1 海、2 河、3 湖或池塘
  plantedYear: Uint16Array, // 玩家種樹的年份（0 = 原本就有的樹林）
  net: Uint8Array,         // 網路位元旗標
  cover: Uint8Array,       // 地表覆蓋位元旗標
  defense: Uint8Array,     // 堤防、海堤
  util: Uint8Array,        // 公用事業旗標
  state: Uint8Array,       // 狀態旗標
  pop: Uint16Array,        // 人口
  jobs: Uint16Array,       // 工作數
  landValue: Uint8Array,
  pollution: Uint8Array,
  crime: Uint8Array,
  fireRisk: Uint8Array,
  covPolice: Uint8Array,
  covFire: Uint8Array,
  covHealth: Uint8Array,
  covEdu: Uint8Array,
  covPark: Uint8Array,
  covShelter: Uint8Array,
  traffic: Uint8Array,
  surfTemp: Float32Array,  // °C
  floodDepth: Uint16Array, // 公分
  floodRisk: Uint8Array,
  carbon: Float32Array,    // 公噸 CO₂ / 月
});

// 存檔時需要保存的圖層（其餘可由模擬重算）
export const PERSISTENT_LAYERS = Object.freeze(['elev', 'surface', 'zone', 'bld', 'devLevel', 'waterBody', 'plantedYear', 'net', 'cover', 'defense', 'state']);

// 主執行緒畫圖與介面需要的圖層（Worker 每次更新都會送過來）
export const SYNC_LAYERS = Object.freeze(['elev', 'surface', 'zone', 'bld', 'devLevel', 'waterBody', 'net', 'util', 'state', 'pop', 'jobs', 'landValue', 'pollution', 'crime', 'traffic', 'carbon', 'surfTemp', 'cover', 'defense', 'floodDepth', 'floodRisk']);

export const WATER_BODY = Object.freeze({ NONE: 0, SEA: 1, RIVER: 2, LAKE: 3 });

export function createCityState({ seed = 1, year = START_YEAR, funds = START_FUNDS, scenario = 'mid', seaLevelSpeed = DEFAULT_SEA_LEVEL_SPEED } = {}) {
  return {
    seed,
    year,
    month: 1,
    funds,
    bonds: [],
    adaptationFund: 0,
    taxes: { r: 7, c: 7, i: 7 },
    budget: { police: 1, fire: 1, health: 1, edu: 1, transit: 1, roads: 1 },
    policies: { carbonFee: false, carbonFeeUse: 'renewables', adaptationShare: 0.05 },
    climate: {
      scenario,
      seaLevelSpeed,
      globalDT: 1.3,
      seaLevelCm: 0,
      forecast: [],      // 下個月的預報（已經擲好骰子的事件 + 給玩家看的文字）
      activeEvents: [],  // 本月發生的極端天氣
      drought: null,     // 進行中的乾旱 { monthsLeft, startY, startM }
    },
    water: null,         // 本月供水統計（water.js 寫入）
    reports: [],         // 災情報告
    resilience: null,
    disasterLossYear: 0,
    compute: { supply: 0, demand: 0 },
    demandRCI: { r: 0, c: 0, i: 0 },
    population: 0,
    jobs: { c: 0, i: 0 },
    nuclearWasteT: 0,
    pendingClearT: 0,  // 本月砍伐樹林釋放的碳（carbon.js 結算）
    power: null,       // 本月電力統計（power.js 寫入）
    lastMonth: null,   // 本月收支（finance.js 寫入）
    history: { monthly: [] },
    journal: [],
  };
}

export class World {
  constructor(size = DEFAULT_MAP_SIZE, cityOptions = {}) {
    this.size = size;
    this.count = size * size;
    this.layers = {};
    for (const [name, Type] of Object.entries(LAYER_SPEC)) {
      this.layers[name] = new Type(this.count);
    }
    this.layers.elev.fill(SEA_LEVEL_CM + LEVEL_CM / 2);
    this.instances = new Map();
    this.nextInstanceId = 1;
    this.city = createCityState(cityOptions);
    this.version = 0; // 每次修改 +1，渲染端用來判斷是否需要重畫
  }

  get elev() { return this.layers.elev; }
  get surface() { return this.layers.surface; }

  index(x, y) { return y * this.size + x; }
  inBounds(x, y) { return x >= 0 && y >= 0 && x < this.size && y < this.size; }

  isWater(i) { return this.layers.surface[i] === SURFACE.WATER; }

  // 畫面層數：水面 0；陸地 1–15（每 2 m 一層）
  level(i) { return elevToLevel(this.layers.elev[i], this.layers.surface[i]); }

  // 相對海平面的海拔（公尺）
  altitudeM(i) { return (this.layers.elev[i] - SEA_LEVEL_CM) / 100; }
}

export function elevToLevel(elevCm, surface) {
  if (elevCm < SEA_LEVEL_CM) return 0;
  const lv = 1 + Math.floor((elevCm - SEA_LEVEL_CM) / LEVEL_CM);
  if (surface === SURFACE.WATER) return Math.max(0, Math.min(MAX_LEVEL, lv - 1));
  return Math.min(MAX_LEVEL, lv);
}

// 把層數換回該層中間的海拔（公分），給地形工具用
export function levelToElev(level) {
  if (level <= 0) return SEA_LEVEL_CM - 50;
  return SEA_LEVEL_CM + (level - 1) * LEVEL_CM + LEVEL_CM / 2;
}
