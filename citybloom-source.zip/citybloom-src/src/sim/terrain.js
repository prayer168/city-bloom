// 地形工具：升高、降低、整平、種樹、移除樹木、挖水
// 每個函式回傳有改變的格子索引，渲染端據此重畫。

import { SEA_LEVEL_CM, LEVEL_CM, SURFACE } from '../core/constants.js';
import { elevToLevel, levelToElev, WATER_BODY } from './world.js';

const MIN_ELEV = SEA_LEVEL_CM - 1500; // 最深 15 m
const MAX_LAND_ELEV = levelToElev(15);

export const TERRAIN_TOOLS = Object.freeze({
  RAISE: 'raise',
  LOWER: 'lower',
  LEVEL: 'level',
  TREES: 'trees',
  CLEAR_TREES: 'clearTrees',
  WATER: 'water',
});

// 把一格「對齊」到某一層的中間，避免高度在層與層的邊界抖動
function snapLand(elev) {
  const lv = elevToLevel(elev, SURFACE.GRASS);
  return levelToElev(lv);
}

export function raiseTile(world, i) {
  const { elev, surface } = world.layers;
  if (surface[i] === SURFACE.WATER) {
    // 填水成陸：至少升到第 1 層
    surface[i] = SURFACE.GRASS;
    world.layers.waterBody[i] = WATER_BODY.NONE;
    elev[i] = Math.max(snapLand(Math.max(elev[i], SEA_LEVEL_CM)), levelToElev(1));
    return true;
  }
  const next = Math.min(MAX_LAND_ELEV, snapLand(elev[i]) + LEVEL_CM);
  if (next === elev[i]) return false;
  elev[i] = next;
  if (surface[i] === SURFACE.MUDFLAT && elevToLevel(next, SURFACE.GRASS) > 1) surface[i] = SURFACE.GRASS;
  return true;
}

export function lowerTile(world, i) {
  const { elev, surface } = world.layers;
  if (surface[i] === SURFACE.WATER) {
    const next = Math.max(MIN_ELEV, elev[i] - LEVEL_CM);
    if (next === elev[i]) return false;
    elev[i] = next;
    return true;
  }
  const next = snapLand(elev[i]) - LEVEL_CM;
  if (next < SEA_LEVEL_CM) {
    // 低於海平面：變成水
    elev[i] = SEA_LEVEL_CM - 50;
    surface[i] = SURFACE.WATER;
    world.layers.waterBody[i] = neighborWaterBody(world, i);
  } else {
    elev[i] = next;
  }
  return true;
}

// 新出現的水格屬於哪種水體：旁邊有海就是海，有河就是河，否則算池塘
function neighborWaterBody(world, i) {
  const { size } = world;
  const wb = world.layers.waterBody;
  const x = i % size, y = (i / size) | 0;
  let best = WATER_BODY.LAKE;
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const nx = x + dx, ny = y + dy;
    if (nx < 0 || ny < 0 || nx >= size || ny >= size) continue;
    const v = wb[ny * size + nx];
    if (v === WATER_BODY.SEA) return WATER_BODY.SEA;
    if (v === WATER_BODY.RIVER) best = WATER_BODY.RIVER;
  }
  return best;
}

export function levelTile(world, i, targetLevel) {
  const { elev, surface } = world.layers;
  if (targetLevel <= 0) {
    if (surface[i] === SURFACE.WATER && elev[i] < SEA_LEVEL_CM) return false;
    elev[i] = SEA_LEVEL_CM - 50;
    surface[i] = SURFACE.WATER;
    world.layers.waterBody[i] = neighborWaterBody(world, i);
    return true;
  }
  const target = levelToElev(targetLevel);
  if (surface[i] !== SURFACE.WATER && elev[i] === target) return false;
  if (surface[i] === SURFACE.WATER) { surface[i] = SURFACE.GRASS; world.layers.waterBody[i] = WATER_BODY.NONE; }
  elev[i] = target;
  return true;
}

export function plantTrees(world, i) {
  const { surface } = world.layers;
  if (surface[i] !== SURFACE.GRASS) return false;
  surface[i] = SURFACE.FOREST;
  return true;
}

export function clearTrees(world, i) {
  const { surface } = world.layers;
  if (surface[i] !== SURFACE.FOREST) return false;
  surface[i] = SURFACE.GRASS;
  return true;
}

export function digWater(world, i) {
  const { surface } = world.layers;
  if (surface[i] === SURFACE.WATER) return false;
  // 保留原海拔：水面在畫面上會比原陸地低一層，看起來像挖出來的池塘
  surface[i] = SURFACE.WATER;
  world.layers.waterBody[i] = neighborWaterBody(world, i);
  return true;
}
