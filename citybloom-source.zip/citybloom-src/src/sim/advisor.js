// AI 市政顧問（規則式程式，不是真正的 AI）
// 每位顧問只在乎一個目標，依城市數據挑出三個建議，並誠實列出「這個建議沒有考慮到的事」。
// 教學目的：讓學生發現「AI 的建議取決於它被設定的目標」，需要人類綜合判斷。

import { ZONE_INFO } from '../data/buildings/zones.js';
import { DATACENTER } from '../data/ai.js';
import { NET, COVER } from '../core/constants.js';

export const ADVISORS = {
  economy: { name: '經濟成長顧問', goal: '讓城市賺最多錢、人口成長最快', ignores: '碳排放、空氣品質、熱島、災害風險' },
  carbon: { name: '減碳顧問', goal: '讓城市的碳排放最少', ignores: '建設費用、電夠不夠用、工作機會' },
  safety: { name: '防災顧問', goal: '讓城市最能承受颱風、淹水、熱浪和乾旱', ignores: '預算和經濟成長' },
  livable: { name: '宜居顧問', goal: '讓居民住得舒服：空氣好、不太熱、不塞車', ignores: '財政收入和產業發展' },
};

const wan = (k) => `${Math.round(k / 10).toLocaleString('zh-TW')} 萬`;
const fmt = (v) => Math.round(v).toLocaleString('zh-TW');

export function advise(world, who) {
  const c = world.city;
  const L = world.layers;
  const n = world.size * world.size;
  const inst = [...world.instances.values()];
  const has = (def) => inst.some((x) => x.def === def);
  const dcs = inst.filter((x) => x.def === 'dataCenter');
  const p = c.power;
  const co2 = c.carbon;
  const recs = [];
  const add = (r) => recs.push(r);

  // 常用的數據
  let indTiles = 0, resTiles = 0, overhead = 0;
  const floodRes = [], hotRes = [];
  for (let i = 0; i < n; i++) {
    const z = L.zone[i];
    if (z && ZONE_INFO[z].kind === 'i') indTiles++;
    if (L.net[i] & NET.POWERLINE && !(L.cover[i] & COVER.UNDERGROUND_GRID)) overhead++;
    if (z && L.devLevel[i] && ZONE_INFO[z].kind === 'r') {
      resTiles++;
      if (L.floodRisk[i] >= 30) floodRes.push(i);
      hotRes.push(i);
    }
  }
  hotRes.sort((a, b) => L.surfTemp[b] - L.surfTemp[a]);
  const hottest = hotRes.slice(0, Math.max(1, Math.round(hotRes.length * 0.15)));
  const coalT = inst.filter((x) => x.def === 'coal').reduce((a, x) => a + (x.lastCO2t || 0), 0);
  const short = p && p.demandMWh > 0 ? p.unservedMWh / p.demandMWh : 0;
  const dcMWh = DATACENTER.itMW * DATACENTER.pue.air * 730;

  if (who === 'economy') {
    if (!dcs.length && indTiles >= 9) add({ score: 90, tool: 'dataCenter', title: '引進 AI 資料中心',
      why: `城市有 ${indTiles} 格工業區可以用。資料中心每月可繳稅約 ${wan(DATACENTER.taxPerMonth)}，帶來 ${DATACENTER.jobs} 個高薪工作，商業也會跟著成長。`,
      blind: `每月要多用約 ${fmt(dcMWh / 10)} 萬度電、大量冷卻用水，還會排出廢熱讓周圍變熱。` });
    if (short > 0.01) add({ score: 85, tool: 'plant_coal', title: '蓋一座燃煤電廠補足電力',
      why: `本月缺電 ${Math.round(short * 100)}%。燃煤每度電的燃料費最便宜，而且可以日夜穩定供電，工廠不會停工。`,
      blind: '燃煤的碳排放和空氣污染最嚴重；長期看燃料費也會累積。' });
    if ((c.demandRCI?.c ?? 0) > 0.3) add({ score: 70, tool: 'zoneC2', title: '多劃一些高密度商業區', why: `商業需求很高（${Math.round(c.demandRCI.c * 100)}），蓋了很快就會有店家進駐，增加稅收。`, blind: '商業區多了交通會變擠，地面也比較熱。' });
    if ((c.demandRCI?.i ?? 0) > 0.3) add({ score: 65, tool: 'zoneI2', title: '多劃一些高密度工業區', why: `工業需求很高（${Math.round(c.demandRCI.i * 100)}），工廠帶來工作和稅收。`, blind: '工業區會產生空氣污染和碳排放，也最耗水，乾旱時最先受影響。' });
    const adapt = c.lastMonth?.expense?.adapt || 0;
    if (adapt > 20) add({ score: 55, title: '暫停興建新的調適設施', why: `調適設施每月維護費約 ${wan(adapt)}，先把錢留給能賺錢的建設。`, blind: '極端天氣來的時候，城市會比較脆弱，災損可能更高。' });
    if ((c.demandRCI?.r ?? 0) > 0.3) add({ score: 60, tool: 'zoneR2', title: '多劃一些高密度住宅', why: '想搬進城市的人很多，住宅越多，稅收越多。', blind: '人多了需要更多電、水和交通建設。' });
    if (dcs.length && indTiles >= 18) add({ score: 58, tool: 'dataCenter', title: '再引進一座 AI 資料中心', why: `第一座資料中心每月繳稅約 ${wan(DATACENTER.taxPerMonth)}，是城市最大的收入來源之一。再一座，稅收再加一倍。`, blind: `用電、用水和廢熱也會再加一倍；城市的電廠可能不夠，碳排放會大增。` });
    const notUpgraded = dcs.filter((d) => !d.upgrades?.green || !d.upgrades?.liquid);
    if (notUpgraded.length) add({ score: 45, title: '先不要花錢升級資料中心', why: '綠電契約、液冷、廢熱回收要花 80–150 萬，不會增加稅收。', blind: '不升級，資料中心的碳排放、用水和廢熱都維持很高。', inspect: notUpgraded[0] });
    if ((c.demandRCI?.r ?? 0) > 0) add({ score: 35, tool: 'zoneR1', title: '繼續擴大住宅區', why: '住宅需求還是正的，人口越多，稅收越多。', blind: '城市越大，需要的電、水、交通也越多。' });
  }

  if (who === 'carbon') {
    if (coalT > 0) add({ score: 95, tool: 'plant_solar', title: '用太陽能＋儲能取代燃煤電廠',
      why: `燃煤電廠本月排放約 ${fmt(coalT)} 公噸二氧化碳，是城市最大的排放來源之一。太陽能每度電的碳排放只有燃煤的約 6%。`,
      blind: '太陽能晚上不發電，要搭配儲能；建造費和土地需求都很大，換的過程可能缺電。' });
    if (dcs.length && !dcs.some((d) => d.upgrades?.green)) add({ score: 88, title: '要求資料中心購買綠電', why: `AI 資料中心用了城市 ${Math.round((p?.dataCenterMWh || 0) / Math.max(1, p?.demandMWh || 1) * 100)}% 的電。簽遠端綠電契約後，大約六成的用電改由風電和太陽能供應。`, blind: '要花一筆補助費用；綠電不夠時仍要靠其他電廠。', inspect: dcs[0] });
    if (!dcs.length) add({ score: 70, title: '先不要引進 AI 資料中心', why: `一座資料中心每月要用約 ${fmt(dcMWh / 10)} 萬度電，如果用的是火力發電，碳排放會大幅增加。`, blind: '城市會少一筆可觀的稅收和高薪工作，也沒有算力可以用智慧城市設施。' });
    if (co2 && co2.share?.transport > 0.15) add({ score: 72, tool: 'busStop', title: '增加公車站和自行車道', why: `交通占全市排放 ${Math.round(co2.share.transport * 100)}%。公車站附近的居民會有三成改搭公車。`, blind: '公車站與自行車道要維護費，效果要等居民改變習慣。' });
    if (dcs.length && !has('aiSignals')) add({ score: 60, tool: 'aiSignals', title: '設置 AI 智慧號誌', why: '城市已經有資料中心的算力。智慧號誌讓車子少走走停停，交通排放可以再少一些。', blind: '號誌本身要用電和算力；車子變順，也可能讓更多人選擇開車。' });
    add({ score: 30, tool: 'trees', title: '在空地種樹', why: '新種的樹林每公頃每年約吸收 8 公噸二氧化碳。', blind: '一片樹林只抵得過幾十位開車通勤的人，種樹不能取代減少排放。' });
  }

  if (who === 'safety') {
    if (floodRes.length) add({ score: 90, tool: 'detentionPond', tiles: floodRes, title: '在淹水潛勢高的住宅區附近蓋滯洪池、鋪透水鋪面',
      why: `有 ${floodRes.length} 格住宅在大雨時可能淹水 30 公分以上（地圖上標示的地方）。`, blind: '滯洪池要占土地，也要花錢；只靠設施不能擋住所有的雨。' });
    if (!has('shelter') && resTiles) add({ score: 75, tool: 'shelter', title: '蓋避難中心', why: '城市還沒有避難中心，淹水或颱風時居民沒有地方可以去。', blind: '避難中心平常用不到，維護費也要付。' });
    if (!has('warningCenter') && !has('aiWeather')) add({ score: 70, tool: 'warningCenter', title: '蓋災害預警中心', why: '沒有預警中心時，大約一成的極端天氣不會被預報到。有預警中心，災害損失少 15%。', blind: '預報再準，也不能取代實際的防洪設施。' });
    if ((c.water?.localShare ?? 0) < 0.1 && resTiles) add({ score: 65, tool: 'recycledWater', title: '蓋再生水廠，準備備用水源', why: `城市的水 ${Math.round((1 - (c.water?.localShare ?? 0)) * 100)}% 都靠水庫，乾旱時會直接限水。`, blind: '再生水廠要用電、要花錢；平常水庫有水時好像沒什麼用。' });
    if (overhead > 20) add({ score: 55, tool: 'undergroundGrid', title: '把重要的電線地下化', why: `城市有 ${overhead} 格架空電線，強烈颱風時每格約有一成機率被吹斷。`, blind: '地下化很貴，施工期間也會影響交通。' });
    if (!has('coolingCenter') && (c.climate?.hotDaysYear || 0) > 10) add({ score: 60, tool: 'coolingCenter', title: '蓋涼爽中心', why: `今年市中心已經有約 ${Math.round(c.climate.hotDaysYear)} 天超過 35 °C，熱浪時長者需要照顧。`, blind: '涼爽中心熱浪時要開冷氣，用電會增加。' });
  }

  if (who === 'livable') {
    if (hottest.length && (c.climate?.heatIsland || 0) > 1) add({ score: 85, tool: 'bigPark', tiles: hottest, title: '在最熱的住宅區種行道樹、蓋公園',
      why: `市中心比郊區熱約 ${(c.climate.heatIsland).toFixed(1)} °C。地圖上標示的是最熱的住宅區。`, blind: '公園要占土地，可能少蓋幾棟房子，稅收也會少一些。' });
    const air = c.air?.avgExposure ?? 0;
    if (air > 40) add({ score: 80, title: '讓工廠和燃煤電廠遠離住宅區', why: `居民平均吸到的空氣污染指數是 ${Math.round(air)}。污染主要來自工業區和燃煤電廠，會往下風處飄。`, blind: '搬遷要花大錢，工廠搬走也會少一些工作。' });
    const t = c.traffic;
    if (t && t.roads && t.congestedRoads / t.roads > 0.05) add({ score: 75, tool: 'busStop', title: '解決塞車：公車、自行車道或智慧號誌', why: `有 ${t.congestedRoads} 格道路塞車。`, blind: '要花建設與維護費；智慧號誌還需要資料中心的算力。' });
    if (dcs.length) add({ score: 50, title: '注意資料中心的廢熱', why: '資料中心周圍 400 公尺的地面明顯變熱。可以升級「廢熱回收」，把熱拿去加熱住宅的熱水。', blind: '升級要補助費用。', inspect: dcs[0] });
    add({ score: 35, tool: 'park', title: '每個住宅區都有小公園', why: '公園讓周圍變涼、地價上升，也能吸附一些空氣污染。', blind: '要維護費，也會占用土地。' });
  }

  recs.sort((a, b) => b.score - a.score);
  return { advisor: ADVISORS[who], recs: recs.slice(0, 3) };
}

// AI 的好處與代價（給顧問面板的「AI 帳本」）
export function aiLedger(world) {
  const c = world.city;
  const dcs = [...world.instances.values()].filter((x) => x.def === 'dataCenter');
  if (!dcs.length) return null;
  const p = c.power;
  const w = c.water;
  const income = dcs.reduce((a, d) => a + DATACENTER.taxPerMonth * (d.operating ?? 1), 0);
  return {
    count: dcs.length,
    income,
    jobs: DATACENTER.jobs * dcs.length,
    mwh: p?.dataCenterMWh || 0,
    mwhShare: p && p.demandMWh ? (p.dataCenterMWh || 0) / p.demandMWh : 0,
    co2: c.aiCarbon?.co2t || 0,
    co2Share: c.carbon && c.carbon.gross ? (c.aiCarbon?.co2t || 0) / c.carbon.gross : 0,
    water: w?.dataCenterM3 || 0,
    waterShare: w && w.demandM3 ? (w.dataCenterM3 || 0) / w.demandM3 : 0,
    pue: dcs[0].lastPue || DATACENTER.pue.air,
    compute: c.compute,
    upgrades: dcs[0].upgrades || {},
  };
}

