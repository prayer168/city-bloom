// SimCore：擁有「正本」世界，處理指令與時間推進，產生要送給畫面的更新。
// Web Worker 版（worker.js）與主執行緒備援版（host.js 的 LocalHost）都用這個類別，行為完全一致。
//
// 收到的訊息：
//   { type: 'init', map: { seed, preset, size } }
//   { type: 'command', id, cmd }
//   { type: 'speed', value: 0..3 }
//   { type: 'step', months }             // 測試用：立刻推進幾個月
// 送出的訊息：
//   { type: 'state', ... }                // 整份狀態（初始化時）
//   { type: 'update', reason, changed, layers, city, instances?, result?, id?, report? }

import { generateMap } from './mapgen.js';
import { applyCommand } from './commands.js';
import { tick } from './tick.js';
import { SYNC_LAYERS } from './world.js';
import { prepareForecast } from '../climate/events.js';
import { updateFloodRisk } from './systems/disaster.js';

export const SPEED_MS = [0, 3000, 1500, 600]; // 暫停、慢、中、快：每個遊戲月幾毫秒

export class SimCore {
  constructor(post) {
    this.post = post; // (msg, transferList) => void
    this.world = null;
    this.speed = 0;
    this.timer = null;
    this.sentInstancesVersion = -1;
  }

  handle(msg) {
    switch (msg.type) {
      case 'init': return this.init(msg.map);
      case 'command': return this.command(msg.id, msg.cmd);
      case 'speed': return this.setSpeed(msg.value);
      case 'step': return this.step(msg.months || 1);
      case 'debug': // 開發與測試用：直接設定資金
        if (this.world && Number.isFinite(msg.funds)) { this.world.city.funds = msg.funds; this.send('update', { reason: 'debug', changed: [] }); }
        return undefined;
      default: return undefined;
    }
  }

  init(map) {
    this.world = generateMap(map);
    if (map.cityOptions?.disabledHazards) this.world.city.disabledHazards = map.cityOptions.disabledHazards;
    this.world.instancesVersion = 0;
    prepareForecast(this.world);  // 第一個月的預報
    updateFloodRisk(this.world);  // 淹水潛勢圖層
    this.sentInstancesVersion = -1;
    // 先算一次，讓畫面一開始就有正確的電力狀態
    this.send('state', { size: this.world.size, map, changed: null });
  }

  command(id, cmd) {
    if (!this.world) return;
    const result = applyCommand(this.world, cmd);
    const changed = result.ok ? result.changed : [];
    this.send('update', { reason: 'command', id, result: { ok: result.ok, reason: result.reason, cost: result.cost || 0 }, changed });
    // 蓋了會影響淹水的東西：停手 0.4 秒後重算淹水潛勢（拖曳時不會每格都重算）
    if (this.world.floodRiskDirty) {
      clearTimeout(this.floodTimer);
      this.floodTimer = setTimeout(() => {
        if (!this.world?.floodRiskDirty) return;
        updateFloodRisk(this.world);
        this.send('update', { reason: 'floodRisk', changed: [] });
      }, 400);
    }
  }

  setSpeed(v) {
    this.speed = v;
    clearTimeout(this.timer);
    this.timer = null;
    if (v > 0) this.schedule();
  }

  schedule() {
    this.timer = setTimeout(() => {
      this.timer = null;
      if (!this.speed) return;
      this.step(1);
      this.schedule();
    }, SPEED_MS[this.speed]);
  }

  step(months) {
    if (!this.world) return;
    const L = this.world.layers;
    const prevUtil = L.util.slice();
    const changedSet = new Set();
    let report = null;
    const broadcasts = [];
    for (let k = 0; k < months; k++) {
      const r = tick(this.world);
      for (const i of r.changed) changedSet.add(i);
      report = { ms: r.ms, net: r.money.net };
      broadcasts.push(...(this.world.city.broadcasts || []));
    }
    // 供電狀態改變的格子也要重畫（停電標誌、電力圖層）
    for (let i = 0; i < prevUtil.length; i++) if (prevUtil[i] !== L.util[i]) changedSet.add(i);
    const hist = this.world.city.history.monthly;
    this.send('update', { reason: 'tick', changed: [...changedSet], report, history: hist.slice(-months), broadcasts: broadcasts.slice(-6) });
  }

  send(type, extra) {
    const w = this.world;
    const layers = {};
    const transfer = [];
    for (const name of SYNC_LAYERS) {
      const copy = w.layers[name].slice();
      layers[name] = copy;
      transfer.push(copy.buffer);
    }
    const msg = { type, layers, city: publicCity(w.city), ...extra };
    if (w.instancesVersion !== this.sentInstancesVersion || type === 'state' || extra.reason === 'tick') {
      // 電廠每月的發電量會變，所以每次 tick 也送
      msg.instances = [...w.instances.values()].map((x) => ({ ...x }));
      this.sentInstancesVersion = w.instancesVersion;
    }
    this.post(msg, transfer);
  }
}

// 送給畫面的城市資料：歷史紀錄另外送，避免每次都複製一大串
function publicCity(c) {
  const { history, journal, broadcasts, ...rest } = c;
  return { ...rest, journalCount: journal.length, lastJournal: journal.slice(-5) };
}
