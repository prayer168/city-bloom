// 地圖生成：同一個種子 + 同一個預設，一定產生同一張地圖。
// 三種預設：
//   river-plain 河川平原：大片低平地、一條河流、河岸是低窪氾濫平原（之後淹水單元會用到）
//   coast       海岸城市：一側臨海，有沙岸與泥灘（海平面上升單元會用到）
//   hills       丘陵山城：起伏大、有湖泊，平地較少

import { World, WATER_BODY } from './world.js';
import { Rng, makeValueNoise } from '../core/rng.js';
import { SEA_LEVEL_CM, MAX_ELEV_CM, SURFACE } from '../core/constants.js';

export const MAP_PRESETS = Object.freeze([
  { id: 'river-plain', name: '河川平原', desc: '大片平地與一條河流，河岸低窪處容易淹水。' },
  { id: 'coast', name: '海岸城市', desc: '一側臨海，有沙灘和泥灘，適合觀察海平面上升。' },
  { id: 'hills', name: '丘陵山城', desc: '地勢起伏大，有湖泊，可蓋的平地比較少。' },
]);

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smoothstep = (a, b, v) => {
  const t = clamp((v - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export function generateMap({ size = 128, seed = 1, preset = 'river-plain', cityOptions = {} } = {}) {
  const world = new World(size, { seed, ...cityOptions });
  const rng = new Rng(seed ^ 0x9e3779b9);
  const n1 = makeValueNoise(seed);
  const n2 = makeValueNoise(seed + 101);
  const n3 = makeValueNoise(seed + 202);

  // 高度先以「公尺（相對海平面）」計算，最後再轉公分
  const hM = new Float32Array(size * size);
  const s = size / 128; // 讓不同尺寸地圖的地形比例一致

  if (preset === 'coast') {
    const side = rng.int(0, 3); // 0 左、1 上、2 右、3 下 臨海
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const along = side === 0 || side === 2 ? y : x;
        let d = side === 0 ? x : side === 1 ? y : side === 2 ? size - 1 - x : size - 1 - y;
        // 海岸線用雜訊推進退縮，形成海灣與岬角
        const wiggle = (n1.fbm(along / (34 * s), 3.7, 3) - 0.5) * 38 * s;
        const dc = d - (24 * s + wiggle);
        let h;
        if (dc < 0) h = dc * 0.35 - 0.6; // 海床
        // 靠海處是低平的海岸平原（海平面上升時最先受影響），往內陸漸高
        else h = 0.3 + dc * 0.09 / s + n2.fbm(x / (26 * s), y / (26 * s), 4) * 7 * smoothstep(0, 22 * s, dc);
        // 內陸一角的丘陵
        const far = d / size;
        h += smoothstep(0.62, 0.95, far) * n3.fbm(x / (20 * s), y / (20 * s), 4) * 16;
        hM[y * size + x] = h;
      }
    }
  } else if (preset === 'hills') {
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const f = n1.fbm(x / (30 * s), y / (30 * s), 5);
        const ridge = 1 - Math.abs(n2.fbm(x / (44 * s), y / (44 * s), 3) * 2 - 1);
        const h = 1.5 + Math.pow(f, 1.25) * 24 + ridge * 6;
        hM[y * size + x] = h;
      }
    }
  } else {
    // river-plain（預設）
    const cx = rng.pick([0.15, 0.85]) * size;
    const cy = rng.pick([0.15, 0.85]) * size;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const base = n1.fbm(x / (40 * s), y / (40 * s), 4);
        let h = 1.2 + base * 7;
        const dist = Math.hypot(x - cx, y - cy) / size;
        const hill = 1 - smoothstep(0.08, 0.45, dist);
        h += hill * n2.fbm(x / (18 * s), y / (18 * s), 4) * 20;
        hM[y * size + x] = h;
      }
    }
  }

  // 河流（三種預設都有，海岸版本流入海）
  const riverMask = carveRiver(hM, size, rng, n3, preset, s);

  // 湖泊（丘陵限定）
  if (preset === 'hills') {
    for (let y = 1; y < size - 1; y++) {
      for (let x = 1; x < size - 1; x++) {
        const v = n3.fbm(x / (16 * s) + 40, y / (16 * s) + 40, 3);
        if (v < 0.2) hM[y * size + x] = -1000; // 標記為湖，稍後處理
      }
    }
  }

  // 轉成公分並決定地表
  const { elev, surface } = world.layers;
  for (let i = 0; i < size * size; i++) {
    let h = hM[i];
    if (h <= -999) {
      // 湖：先標 0，fillLakes 再依周圍陸地決定水面高度
      surface[i] = SURFACE.WATER;
      elev[i] = 0;
      continue;
    }
    elev[i] = clamp(Math.round(SEA_LEVEL_CM + h * 100), 0, MAX_ELEV_CM);
    surface[i] = elev[i] < SEA_LEVEL_CM ? SURFACE.WATER : SURFACE.GRASS;
  }
  // 湖面高度 = 周圍陸地的最低高度（讓湖看起來凹下去）
  const { waterBody } = world.layers;
  for (let i = 0; i < size * size; i++) {
    if (riverMask[i] !== Infinity) { surface[i] = SURFACE.WATER; waterBody[i] = WATER_BODY.RIVER; }
    else if (surface[i] === SURFACE.WATER) waterBody[i] = elev[i] === 0 ? WATER_BODY.LAKE : WATER_BODY.SEA;
  }
  fillLakes(world);

  // 沙岸、泥灘
  const nearSea = distanceToSea(world, 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      if (surface[i] === SURFACE.WATER) continue;
      const d = nearSea[i];
      const alt = (elev[i] - SEA_LEVEL_CM) / 100;
      if (preset === 'coast' && d <= 3 && alt < 1.2 && n2.noise(x / (9 * s), y / (9 * s)) > 0.62) {
        surface[i] = SURFACE.MUDFLAT;
      } else if (d <= 2 && alt < 2.2) {
        surface[i] = SURFACE.SAND;
      }
    }
  }

  // 樹林：用分位數決定門檻，讓每種地形的樹林比例穩定
  const forestShare = preset === 'hills' ? 0.42 : preset === 'coast' ? 0.2 : 0.24;
  const fv = new Float32Array(size * size).fill(-1);
  const grassVals = [];
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      if (surface[i] !== SURFACE.GRASS) continue;
      const alt = (elev[i] - SEA_LEVEL_CM) / 100;
      const v = n2.fbm(x / (17 * s) + 77, y / (17 * s) - 31, 4) + Math.min(0.08, alt / 250);
      fv[i] = v;
      grassVals.push(v);
    }
  }
  if (grassVals.length) {
    grassVals.sort((a, b) => a - b);
    const cut = grassVals[Math.floor(grassVals.length * (1 - forestShare))];
    for (let i = 0; i < size * size; i++) if (fv[i] >= cut) surface[i] = SURFACE.FOREST;
  }

  world.version++;
  return world;
}

function carveRiver(hM, size, rng, noise, preset, s) {
  // 從地圖一邊流到另一邊；海岸版從內陸流向海（由最低的邊進入海）
  const horizontal = rng.chance(0.5);
  let start, end;
  if (preset === 'coast') {
    // 找出海在哪一邊：比較四邊平均高度
    const edgeAvg = [0, 0, 0, 0];
    for (let k = 0; k < size; k++) {
      edgeAvg[0] += hM[k * size];
      edgeAvg[1] += hM[k];
      edgeAvg[2] += hM[k * size + size - 1];
      edgeAvg[3] += hM[(size - 1) * size + k];
    }
    const seaSide = edgeAvg.indexOf(Math.min(...edgeAvg));
    const opp = (seaSide + 2) % 4;
    start = edgePoint(opp, size, rng);
    end = edgePoint(seaSide, size, rng);
  } else if (horizontal) {
    start = [0, rng.range(0.25, 0.75) * size];
    end = [size - 1, rng.range(0.25, 0.75) * size];
  } else {
    start = [rng.range(0.25, 0.75) * size, 0];
    end = [rng.range(0.25, 0.75) * size, size - 1];
  }

  // 讓河流從高的那端流向低的那端
  const hAt = (p) => hM[Math.round(clamp(p[1], 0, size - 1)) * size + Math.round(clamp(p[0], 0, size - 1))];
  if (preset !== 'coast' && hAt(start) < hAt(end)) [start, end] = [end, start];

  const width = preset === 'hills' ? 0.9 : 1.3;
  const bank = preset === 'hills' ? 2.5 : 4.5;
  const pts = [];
  let [x, y] = start;
  const total = Math.hypot(end[0] - start[0], end[1] - start[1]);
  for (let step = 0; step < size * 6; step++) {
    const dx = end[0] - x, dy = end[1] - y;
    const dist = Math.hypot(dx, dy);
    if (dist < 1) break;
    let ang = Math.atan2(dy, dx);
    ang += (noise.fbm(x / (22 * s), y / (22 * s), 3) - 0.5) * 2.4; // 蜿蜒
    x += Math.cos(ang) * 0.5;
    y += Math.sin(ang) * 0.5;
    x = clamp(x, 0, size - 1);
    y = clamp(y, 0, size - 1);
    pts.push([x, y, 1 - dist / total]);
  }
  pts.push([end[0], end[1], 1]);

  // 河道高度沿流向單調下降；兩岸壓低成河谷 / 氾濫平原
  const startH = Math.max(0.6, Math.min(hAt(start) - 2, preset === 'hills' ? 14 : 3));
  const riverH = new Float32Array(size * size).fill(Infinity);
  const bankH = new Float32Array(size * size).fill(Infinity);
  for (const [px, py, t] of pts) {
    const surfaceH = startH * (1 - t) - 0.5 * t; // 終點低於海平面
    const r = Math.ceil(bank);
    for (let oy = -r; oy <= r; oy++) {
      for (let ox = -r; ox <= r; ox++) {
        const tx = Math.round(px + ox), ty = Math.round(py + oy);
        if (tx < 0 || ty < 0 || tx >= size || ty >= size) continue;
        const d = Math.hypot(tx - px, ty - py);
        const i = ty * size + tx;
        if (d <= width) riverH[i] = Math.min(riverH[i], surfaceH);
        else if (d <= bank) {
          // 越靠近河越低，最低比河面高 1 m 左右
          const b = surfaceH + 1.0 + (d - width) * (preset === 'hills' ? 1.6 : 0.35);
          bankH[i] = Math.min(bankH[i], b);
        }
      }
    }
  }
  for (let i = 0; i < size * size; i++) {
    // 河道高度存的是「河床」，水格畫面會再低一層，所以略減
    if (riverH[i] !== Infinity) hM[i] = riverH[i] - 0.6;
    else if (bankH[i] !== Infinity) hM[i] = Math.min(hM[i], bankH[i]);
  }
  return riverH; // 河道遮罩：非 Infinity 的格子是河
}

function edgePoint(side, size, rng) {
  const t = rng.range(0.3, 0.7) * size;
  if (side === 0) return [0, t];
  if (side === 1) return [t, 0];
  if (side === 2) return [size - 1, t];
  return [t, size - 1];
}

function fillLakes(world) {
  const { size } = world;
  const { elev, surface } = world.layers;
  // 湖：elev 仍是 0（未設定）的水格，取周圍陸地最低高度
  for (let pass = 0; pass < 3; pass++) {
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const i = y * size + x;
        if (surface[i] !== SURFACE.WATER || elev[i] !== 0) continue;
        let minLand = Infinity;
        for (let oy = -1; oy <= 1; oy++) {
          for (let ox = -1; ox <= 1; ox++) {
            const nx = x + ox, ny = y + oy;
            if (nx < 0 || ny < 0 || nx >= size || ny >= size) continue;
            const j = ny * size + nx;
            if (elev[j] !== 0) minLand = Math.min(minLand, elev[j]);
          }
        }
        if (minLand !== Infinity) elev[i] = minLand;
      }
    }
  }
  for (let i = 0; i < size * size; i++) {
    if (surface[i] === SURFACE.WATER && elev[i] === 0) elev[i] = SEA_LEVEL_CM - 50;
  }
}

// 每格到最近海水（海拔低於海平面的水域）的距離（格），超過 maxD 記為 255
export function distanceToSea(world, maxD) {
  const { size } = world;
  const { elev, surface } = world.layers;
  const dist = new Uint8Array(size * size).fill(255);
  let frontier = [];
  for (let i = 0; i < size * size; i++) {
    if (surface[i] === SURFACE.WATER && elev[i] < SEA_LEVEL_CM) {
      dist[i] = 0;
      frontier.push(i);
    }
  }
  for (let d = 1; d <= maxD && frontier.length; d++) {
    const next = [];
    for (const i of frontier) {
      const x = i % size, y = (i / size) | 0;
      for (let oy = -1; oy <= 1; oy++) {
        for (let ox = -1; ox <= 1; ox++) {
          const nx = x + ox, ny = y + oy;
          if (nx < 0 || ny < 0 || nx >= size || ny >= size) continue;
          const j = ny * size + nx;
          if (dist[j] === 255) { dist[j] = d; next.push(j); }
        }
      }
    }
    frontier = next;
  }
  return dist;
}
