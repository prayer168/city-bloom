// 每月模擬管線。每一步只讀取前面已算好的結果。
// 極端天氣月初發生 → 天氣 → 海平面 → 地表溫度（熱島）→ 用電與供電 → 供水 → 交通 → 污染 → 碳排放
// → 極端天氣月中結算（災情報告）→ 地價 → 犯罪 → RCI 需求 → 建築成長 → 人口 → 財政 → 記錄 → 下個月的預報

import { updatePower } from './systems/power.js';
import { computeDemand } from './systems/demand.js';
import { updateGrowth, updatePopulation } from './systems/growth.js';
import { updateFinance } from './systems/finance.js';
import { updateTraffic } from './systems/traffic.js';
import { updatePollution, updateLandValue, updateCrime } from './systems/environment.js';
import { updateCarbon } from './systems/carbon.js';
import { updateWater } from './systems/water.js';
import { settleDisasters, computeResilience, updateFloodRisk } from './systems/disaster.js';
import { updateWeather } from '../climate/weather.js';
import { updateHeatIsland } from '../climate/heatisland.js';
import { updateSeaLevel } from '../climate/sealevel.js';
import { startEvents, applyEventsToWeather, advanceDrought, prepareForecast, EVENT_NAME } from '../climate/events.js';

const r1 = (v) => Math.round(v * 10) / 10;

export function tick(world) {
  const c = world.city;
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  c.broadcasts = [];

  const events = startEvents(world);
  const weather = updateWeather(world);
  applyEventsToWeather(world);
  const sea = updateSeaLevel(world);
  if (events.length) c.broadcasts.push({ kind: 'event', text: eventStartText(events) });
  const heat = updateHeatIsland(world);
  const power = updatePower(world);
  const water = updateWater(world);
  const traffic = updateTraffic(world);
  const air = updatePollution(world);
  const co2 = updateCarbon(world);
  const dis = settleDisasters(world, { seaResult: sea });
  if (world.floodRiskDirty || c.month % 3 === 1 || sea.changed.length) updateFloodRisk(world);
  updateLandValue(world);
  updateCrime(world);
  computeDemand(c);
  const changed = updateGrowth(world);
  updatePopulation(world);
  const money = updateFinance(world);
  computeResilience(world);

  c.history.monthly.push({
    y: c.year, m: c.month,
    pop: c.population, jobsC: c.jobs.c, jobsI: c.jobs.i,
    funds: Math.round(c.funds),
    demandMWh: Math.round(power.demandMWh), genMWh: Math.round(power.generationMWh),
    unservedMWh: Math.round(power.unservedMWh), co2t: Math.round(power.co2t),
    renewableShare: +power.renewableShare.toFixed(3),
    carShare: +traffic.carShare.toFixed(3), carKm: traffic.carKmPerDay, congested: traffic.congestedRoads,
    air: +air.avgExposure.toFixed(1), crime: +(c.crimeAvg || 0).toFixed(1),
    co2: { power: r1(co2.power), transport: r1(co2.transport), buildings: r1(co2.buildings), industry: r1(co2.industry), landuse: r1(co2.landuse), absorb: r1(co2.absorb), net: r1(co2.net) },
    aqiPop: air.popByLevel.slice(),
    temp: r1(weather.temp), rain: Math.round(weather.rain), globalDT: +weather.globalDT.toFixed(2),
    heatIsland: r1(heat.heatIsland), hotDays: r1(heat.hotDaysCore), coolingMWh: Math.round(power.coolingMWh || 0),
    gen: Object.fromEntries(Object.entries(power.genBySource).map(([k, v]) => [k, Math.round(v)])),
    water: +water.storage.toFixed(3), waterLevel: water.level,
    events: events.map((e) => e.type), lossK: Math.round(dis.lossK), resilience: c.resilience?.score ?? 0,
    seaCm: Math.round((c.climate.seaRiseM || 0) * 100),
  });
  if (c.history.monthly.length > 1200) c.history.monthly.shift(); // 最多 100 年

  // 下個月
  advanceDrought(world);
  c.month++;
  if (c.month > 12) { c.month = 1; c.year++; }
  const fc = prepareForecast(world);
  if (fc.shown.length) c.broadcasts.push({ kind: 'forecast', text: forecastBroadcast(fc) });
  world.version++;

  const allChanged = new Set(changed);
  for (const i of sea.changed) allChanged.add(i);
  for (const i of dis.changed) allChanged.add(i);
  const ms = (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0;
  return { changed: [...allChanged], power, money, ms, reports: dis.reports };
}

function eventStartText(events) {
  const names = events.filter((e) => e.type !== 'drought').map((e) => e.name || EVENT_NAME[e.type]);
  const dry = events.some((e) => e.type === 'drought');
  if (!names.length && dry) return '氣象單位提醒：降雨明顯偏少，水庫進帳變少，請節約用水。';
  return `${names.join('、')}來了！市民請注意安全${dry ? '，同時降雨偏少，請節約用水' : ''}。`;
}

function forecastBroadcast(fc) {
  const items = fc.shown.map((s) => s.text);
  return `天氣預報：下個月${items.join('；')}。${fc.shown.some((s) => s.likelihood !== 'low') ? '請先檢查防災準備。' : ''}`;
}
