// 每月模擬管線。每一步只讀取前面已算好的結果。
// 氣候與天氣 → 地表溫度（熱島）→ 用電需求與供電 → 交通 → 污染擴散 → 碳排放統計 → 地價 → 犯罪 → RCI 需求 → 建築成長 → 人口 → 財政 → 記錄
// 之後的階段會在對應位置插入：氣候、熱島、算力、交通、污染、碳排、極端天氣、地價…

import { updatePower } from './systems/power.js';
import { computeDemand } from './systems/demand.js';
import { updateGrowth, updatePopulation } from './systems/growth.js';
import { updateFinance } from './systems/finance.js';
import { updateTraffic } from './systems/traffic.js';
import { updatePollution, updateLandValue, updateCrime } from './systems/environment.js';
import { updateCarbon } from './systems/carbon.js';
import { updateWeather } from '../climate/weather.js';
import { updateHeatIsland } from '../climate/heatisland.js';

const r1 = (v) => Math.round(v * 10) / 10;

export function tick(world) {
  const c = world.city;
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();

  const weather = updateWeather(world);
  const heat = updateHeatIsland(world);
  const power = updatePower(world);
  const traffic = updateTraffic(world);
  const air = updatePollution(world);
  const co2 = updateCarbon(world);
  updateLandValue(world);
  updateCrime(world);
  computeDemand(c);
  const changed = updateGrowth(world);
  updatePopulation(world);
  const money = updateFinance(world);

  c.history.monthly.push({
    y: c.year, m: c.month,
    pop: c.population, jobsC: c.jobs.c, jobsI: c.jobs.i,
    funds: Math.round(c.funds),
    demandMWh: Math.round(power.demandMWh), genMWh: Math.round(power.generationMWh),
    unservedMWh: Math.round(power.unservedMWh), co2t: Math.round(power.co2t),
    renewableShare: +power.renewableShare.toFixed(3),
    carShare: +traffic.carShare.toFixed(3), carKm: traffic.carKmPerDay, congested: traffic.congestedRoads,
    air: +air.avgExposure.toFixed(1), crime: +(c.crimeAvg || 0).toFixed(1),
    co2: { power: r1(co2.power), transport: r1(co2.transport), buildings: r1(co2.buildings), industry: r1(co2.industry), landuse: r1(co2.landuse), absorb: r1(co2.absorb), net: r1(co2.net) },
    aqiPop: air.popByLevel.slice(),
    temp: r1(weather.temp), rain: Math.round(weather.rain), globalDT: +weather.globalDT.toFixed(2),
    heatIsland: r1(heat.heatIsland), hotDays: r1(heat.hotDaysCore), coolingMWh: Math.round(power.coolingMWh || 0),
    gen: Object.fromEntries(Object.entries(power.genBySource).map(([k, v]) => [k, Math.round(v)])),
  });
  if (c.history.monthly.length > 1200) c.history.monthly.shift(); // 最多 100 年

  // 下個月
  c.month++;
  if (c.month > 12) { c.month = 1; c.year++; }
  world.version++;

  const ms = (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0;
  return { changed, power, money, ms };
}
