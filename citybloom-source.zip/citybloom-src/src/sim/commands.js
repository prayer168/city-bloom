// 玩家指令：驗證後套用到世界，並記入決策時間軸。
// 每種指令都有「只檢查不執行」的 validate 版本，主執行緒用它來預覽（綠框 / 紅框與價格）。
// 指令是純資料物件，可以原封不動地傳給 Web Worker 執行。
//
//   { op: 'terrain', tool, x, y, radius, targetLevel }
//   { op: 'road' | 'powerline' | 'bulldoze', tiles: [世界索引...] }
//   { op: 'zone', zone, tiles: [...] }
//   { op: 'plant', type, x, y }          // (x, y) = 占地左上角
//   { op: 'bikelane', tiles: [...] }      // 在既有道路上畫自行車道
//   { op: 'busStop', x, y }
//   { op: 'park', type: 'park' | 'bigPark', x, y }
//   { op: 'cover', flag: 'streetTrees' | 'greenRoof' | 'coolRoof' | 'permeable' | 'rainGarden'
//                      | 'rainHarvest' | 'roofSolar' | 'undergroundGrid', tiles: [...] }
//   { op: 'adapt', type: 'detentionPond' | 'pumpStation' | ..., x, y }   // 調適設施（占地左上角）
//   { op: 'defense', flag: 'levee' | 'seawall', tiles: [...] }
//   { op: 'drain', tiles: [...] }         // 擴建道路下的雨水下水道

import { forEachInSquare } from '../core/grid.js';
import { NET, SURFACE, ZONE, STATE, DEFENSE } from '../core/constants.js';
import {
  TERRAIN_TOOLS, raiseTile, lowerTile, levelTile, plantTrees, clearTrees, digWater,
} from './terrain.js';
import { WATER_BODY } from './world.js';
import { PLANTS, plantCost } from '../data/energy.js';
import { COSTS } from '../data/buildings/infra.js';
import { TRANSIT } from '../data/transport.js';
import { EMISSIONS } from '../data/emissions.js';
import { GREEN } from '../data/climate.js';
import { COVER } from '../core/constants.js';
import { ZONE_INFO } from '../data/buildings/zones.js';
import { ADAPT, ADAPT_LINE } from '../data/hazards.js';

const FLOOD_OPS = new Set(['adapt', 'defense', 'drain', 'cover', 'terrain', 'zone', 'road', 'bulldoze', 'park', 'plant']);
export const COVER_BITS = {
  streetTrees: COVER.STREET_TREES, greenRoof: COVER.GREEN_ROOF, coolRoof: COVER.COOL_ROOF,
  permeable: COVER.PERMEABLE, rainGarden: COVER.RAIN_GARDEN, rainHarvest: COVER.RAIN_HARVEST,
  roofSolar: COVER.ROOF_SOLAR, undergroundGrid: COVER.UNDERGROUND_GRID,
};
const coverCost = (flag) => GREEN[flag]?.cost ?? ADAPT_LINE[flag]?.cost ?? 0;
const coverName = (flag) => GREEN[flag]?.name ?? ADAPT_LINE[flag]?.name ?? flag;

export function applyCommand(world, cmd) {
  const v = validateCommand(world, cmd);
  if (!v.ok) return { ok: false, reason: v.reason, changed: [] };
  // 記下哪些格子原本是樹林：之後被砍掉要計算釋放的碳，新種的要記年份
  const S = world.layers.surface;
  const wasForest = new Set(v.tiles.filter((i) => S[i] === SURFACE.FOREST));
  const res = EXEC[cmd.op](world, cmd, v);
  trackForest(world, v.tiles, wasForest);
  if (res.changed.length || res.instance) {
    world.city.funds -= v.cost;
    world.version++;
    logDecision(world, cmd, v);
    if (FLOOD_OPS.has(cmd.op)) world.floodRiskDirty = true;
  }
  return { ok: true, cost: v.cost, ...res };
}

export function validateCommand(world, cmd) {
  const fn = VALIDATE[cmd.op];
  if (!fn) return fail('不認得的指令');
  const v = fn(world, cmd);
  if (v.ok && v.cost > world.city.funds) return fail(`資金不足（需要 ${formatWan(v.cost)}）`, v.cost);
  return v;
}

const fail = (reason, cost = 0) => ({ ok: false, reason, cost, tiles: [] });
export const formatWan = (k) => `${Math.round(k / 10).toLocaleString('zh-TW')} 萬`;

function logDecision(world, cmd, v) {
  // 只記錄有教學意義的決策（地形與道路太多，不記）
  const c = world.city;
  if (cmd.op === 'plant') c.journal.push({ y: c.year, m: c.month, kind: 'plant', type: cmd.type, text: `興建${PLANTS[cmd.type].name}` });
  else if (cmd.op === 'zone' && v.tiles.length >= 4) c.journal.push({ y: c.year, m: c.month, kind: 'zone', zone: cmd.zone, n: v.tiles.length, text: `劃設${ZONE_INFO[cmd.zone].name} ${v.tiles.length} 格` });
  else if (cmd.op === 'adapt') c.journal.push({ y: c.year, m: c.month, kind: 'adapt', type: cmd.type, text: `興建${ADAPT[cmd.type].name}` });
  else if (cmd.op === 'defense' || cmd.op === 'drain' || (cmd.op === 'cover' && ADAPT_LINE[cmd.flag])) {
    const key = cmd.op === 'cover' ? cmd.flag : cmd.op === 'drain' ? 'drain' : cmd.flag;
    const last = c.journal[c.journal.length - 1];
    // 同一個月連續拖曳的同種設施合併成一筆
    if (last && last.kind === 'adaptLine' && last.key === key && last.y === c.year && last.m === c.month) { last.n += v.tiles.length; last.text = `${ADAPT_LINE[key].name} ${last.n} 格`; }
    else c.journal.push({ y: c.year, m: c.month, kind: 'adaptLine', key, n: v.tiles.length, text: `${ADAPT_LINE[key].name} ${v.tiles.length} 格` });
  }
  if (c.journal.length > 500) c.journal.shift();
}

// ---------------- 驗證 ----------------
const VALIDATE = {
  terrain(world, { tool, x, y, radius = 0, targetLevel }) {
    if (!world.inBounds(x, y)) return fail('超出地圖範圍');
    if (!Object.values(TERRAIN_TOOLS).includes(tool)) return fail('不認得的地形工具');
    if (tool === TERRAIN_TOOLS.LEVEL && !Number.isInteger(targetLevel)) return fail('整平需要目標高度');
    const tiles = [];
    let blocked = false;
    forEachInSquare(world.size, x, y, radius, (_x, _y, i) => {
      if (isDeveloped(world, i)) blocked = true;
      else tiles.push(i);
    });
    if (!tiles.length && blocked) return fail('這裡有建設，請先拆除');
    return { ok: true, cost: tiles.length * COSTS.terrain, tiles };
  },

  road(world, { tiles }) {
    const L = world.layers;
    const ok = [];
    let cost = 0, reason = '';
    for (const i of uniq(tiles)) {
      if (L.net[i] & NET.ROAD) continue;
      if (L.surface[i] === SURFACE.WATER) { reason = '道路不能蓋在水上（橋梁之後開放）'; continue; }
      if (L.state[i] & STATE.SUBMERGED) { reason = '這裡已經被海水淹沒'; continue; }
      if (L.bld[i]) { reason = '這裡有建築'; continue; }
      if (L.devLevel[i]) { reason = '這裡有房子，請先拆除'; continue; }
      ok.push(i);
      cost += COSTS.road + (L.surface[i] === SURFACE.FOREST ? COSTS.clearForest : 0);
    }
    if (!ok.length) return fail(reason || '這裡已經有道路');
    return { ok: true, cost, tiles: ok };
  },

  powerline(world, { tiles }) {
    const L = world.layers;
    const ok = [];
    let cost = 0, reason = '';
    for (const i of uniq(tiles)) {
      if (L.net[i] & NET.POWERLINE) continue;
      if (L.bld[i]) { reason = '電廠本身就會傳電'; continue; }
      if (L.zone[i]) { reason = '分區本身就會傳電，不需要電線'; continue; }
      ok.push(i);
      // 跨越水面要立高塔，比較貴
      cost += COSTS.powerline * (L.surface[i] === SURFACE.WATER ? 3 : 1) + (L.surface[i] === SURFACE.FOREST ? COSTS.clearForest : 0);
    }
    if (!ok.length) return fail(reason || '這裡已經有電線');
    return { ok: true, cost, tiles: ok };
  },

  zone(world, { zone, tiles }) {
    if (!ZONE_INFO[zone]) return fail('不認得的分區');
    const L = world.layers;
    const ok = [];
    let cost = 0, reason = '';
    for (const i of uniq(tiles)) {
      if (L.zone[i] === zone) continue;
      if (L.surface[i] === SURFACE.WATER) { reason = '水上不能劃分區'; continue; }
      if (L.state[i] & STATE.SUBMERGED) { reason = '這裡已經被海水淹沒'; continue; }
      if (L.net[i] & NET.ROAD) { reason = '道路上不能劃分區'; continue; }
      if (L.defense[i]) { reason = '這裡有堤防或海堤'; continue; }
      if (L.bld[i]) { reason = '這裡有建築'; continue; }
      if (L.devLevel[i]) { reason = '這裡已經有房子，請先拆除再改分區'; continue; }
      ok.push(i);
      cost += COSTS.zone + (L.surface[i] === SURFACE.FOREST ? COSTS.clearForest : 0);
    }
    if (!ok.length) return fail(reason || '已經是這個分區了');
    return { ok: true, cost, tiles: ok };
  },

  bikelane(world, { tiles }) {
    const L = world.layers;
    const ok = [];
    for (const i of uniq(tiles)) {
      if (!(L.net[i] & NET.ROAD) || (L.net[i] & NET.BIKE)) continue;
      ok.push(i);
    }
    if (!ok.length) return fail('自行車道要畫在道路上');
    return { ok: true, cost: ok.length * TRANSIT.bikeLane.cost, tiles: ok };
  },

  busStop(world, { x, y }) {
    if (!world.inBounds(x, y)) return fail('超出地圖範圍');
    const L = world.layers;
    const i = world.index(x, y);
    if (L.surface[i] === SURFACE.WATER) return fail('不能蓋在水上');
    if (L.bld[i] || L.devLevel[i] || L.zone[i] || L.net[i]) return fail('公車站要蓋在道路旁的空地上');
    let road = false;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      if (world.inBounds(x + dx, y + dy) && L.net[world.index(x + dx, y + dy)] & NET.ROAD) road = true;
    }
    if (!road) return fail('公車站旁邊要有道路');
    return { ok: true, cost: TRANSIT.busStop.cost, tiles: [i] };
  },

  park(world, { type, x, y }) {
    const g = GREEN[type];
    if (!g || !g.footprint) return fail('不認得的公園');
    const [w, h] = g.footprint;
    if (x < 0 || y < 0 || x + w > world.size || y + h > world.size) return fail('超出地圖範圍');
    const L = world.layers;
    const tiles = footprintTiles(world, x, y, w, h);
    for (const i of tiles) {
      if (L.surface[i] === SURFACE.WATER) return fail('公園不能蓋在水上');
      if (L.bld[i] || L.devLevel[i] || L.zone[i] || L.net[i]) return fail('公園要蓋在空地上（可以先拆掉分區）');
    }
    return { ok: true, cost: g.cost, tiles };
  },

  cover(world, { flag, tiles }) {
    const L = world.layers;
    const ok = [];
    const bit = COVER_BITS[flag];
    if (!bit) return fail('不認得的設施');
    let reason = '';
    const building = (i) => L.zone[i] && L.devLevel[i];
    for (const i of uniq(tiles)) {
      if (L.cover[i] & bit) continue;
      if (flag === 'streetTrees') {
        if (!(L.net[i] & NET.ROAD)) { reason = '行道樹要種在道路上'; continue; }
      } else if (flag === 'permeable') {
        if (!(L.net[i] & NET.ROAD) && !L.zone[i]) { reason = '透水鋪面要鋪在道路或分區的基地上'; continue; }
      } else if (flag === 'rainGarden') {
        if (L.surface[i] === SURFACE.WATER || L.bld[i] || (L.net[i] & NET.ROAD) || L.devLevel[i]) { reason = '雨水花園要做在空地或還沒蓋房子的基地上'; continue; }
      } else if (flag === 'undergroundGrid') {
        if (!(L.net[i] & NET.POWERLINE)) { reason = '電線地下化要選在電線上'; continue; }
      } else if (flag === 'rainHarvest' || flag === 'roofSolar') {
        if (!building(i)) { reason = '要做在已經蓋好的建築上'; continue; }
      } else {
        if (!L.zone[i] || !L.devLevel[i]) { reason = '屋頂設施要做在已經蓋好的建築上'; continue; }
        // 綠屋頂與冷屋頂二選一
        const other = flag === 'greenRoof' ? COVER.COOL_ROOF : COVER.GREEN_ROOF;
        if (L.cover[i] & other) { reason = '這棟已經有另一種屋頂了'; continue; }
      }
      ok.push(i);
    }
    if (!ok.length) return fail(reason || '這裡已經有了');
    return { ok: true, cost: ok.length * coverCost(flag), tiles: ok, bit };
  },

  adapt(world, { type, x, y }) {
    const d = ADAPT[type];
    if (!d) return fail('不認得的設施');
    if (d.unique && [...world.instances.values()].some((s) => s.def === type)) return fail(`城市只需要一座${d.name}`);
    const [w, h] = d.footprint;
    if (x < 0 || y < 0 || x + w > world.size || y + h > world.size) return fail('超出地圖範圍');
    const L = world.layers;
    const tiles = footprintTiles(world, x, y, w, h);
    let level = -1;
    let forest = 0;
    for (const i of tiles) {
      if (L.surface[i] === SURFACE.WATER) return fail(`${d.name}不能蓋在水上`);
      if (L.state[i] & STATE.SUBMERGED) return fail('這裡已經被海水淹沒');
      if (L.bld[i] || L.devLevel[i] || L.zone[i] || (L.net[i] & NET.ROAD)) return fail(`${d.name}要蓋在空地上`);
      const lv = world.level(i);
      if (level === -1) level = lv;
      else if (lv !== level) return fail('地面不平，請先用「整平」工具');
      if (L.surface[i] === SURFACE.FOREST) forest++;
    }
    if (d.needsSea && !touchesWater(world, x, y, w, h, [WATER_BODY.SEA])) return fail(`${d.name}要蓋在海邊`);
    return { ok: true, cost: d.cost + forest * COSTS.clearForest, tiles };
  },

  defense(world, { flag, tiles }) {
    const def = ADAPT_LINE[flag];
    if (!def || !(flag === 'levee' || flag === 'seawall')) return fail('不認得的設施');
    const L = world.layers;
    const bit = flag === 'levee' ? DEFENSE.LEVEE : DEFENSE.SEAWALL;
    const kinds = flag === 'levee' ? [WATER_BODY.RIVER, WATER_BODY.LAKE] : [WATER_BODY.SEA];
    const ok = [];
    let reason = '';
    for (const i of uniq(tiles)) {
      if (L.defense[i] & bit) continue;
      if (L.surface[i] === SURFACE.WATER) { reason = `${def.name}要蓋在岸邊的陸地上`; continue; }
      if (L.bld[i] || L.devLevel[i] || L.zone[i]) { reason = '這裡有建築或分區'; continue; }
      if (!nearWater(world, i, kinds, 2)) { reason = flag === 'levee' ? '堤防要蓋在河岸或湖岸 2 格內' : '海堤要蓋在海岸 2 格內'; continue; }
      ok.push(i);
    }
    if (!ok.length) return fail(reason || '這裡已經有了');
    return { ok: true, cost: ok.length * def.cost, tiles: ok, bit };
  },

  drain(world, { tiles }) {
    const L = world.layers;
    const ok = [];
    for (const i of uniq(tiles)) if ((L.net[i] & NET.ROAD) && !(L.net[i] & NET.STORM_DRAIN)) ok.push(i);
    if (!ok.length) return fail('下水道擴建要選在道路上');
    return { ok: true, cost: ok.length * ADAPT_LINE.drain.cost, tiles: ok };
  },

  bulldoze(world, { tiles }) {
    const L = world.layers;
    const ok = new Set();
    for (const i of uniq(tiles)) {
      if (L.bld[i]) {
        const inst = world.instances.get(L.bld[i]);
        if (inst) for (const j of footprintTiles(world, inst.x, inst.y, inst.w, inst.h)) ok.add(j);
      } else if (L.net[i] || L.zone[i] || L.devLevel[i] || L.defense[i] || L.cover[i] || L.surface[i] === SURFACE.FOREST) ok.add(i);
    }
    if (!ok.size) return fail('這裡沒有東西可以拆');
    return { ok: true, cost: ok.size * COSTS.bulldoze, tiles: [...ok] };
  },

  plant(world, { type, x, y }) {
    const p = PLANTS[type];
    if (!p) return fail('不認得的電廠');
    if (world.city.denied?.includes(type)) return fail(`這個關卡不能蓋${p.name}`);
    const [w, h] = p.footprint;
    if (x < 0 || y < 0 || x + w > world.size || y + h > world.size) return fail('超出地圖範圍');
    const L = world.layers;
    const tiles = footprintTiles(world, x, y, w, h);
    let level = -1;
    let forest = 0;
    for (const i of tiles) {
      if (L.surface[i] === SURFACE.WATER) return fail(`${p.name}不能蓋在水上`);
      if (L.state[i] & STATE.SUBMERGED) return fail('這裡已經被海水淹沒');
      if (L.bld[i] || L.devLevel[i]) return fail('這裡已經有建築');
      if (L.net[i] & NET.ROAD) return fail('這裡有道路');
      if (L.zone[i]) return fail('這裡已經劃了分區，請先拆除');
      const lv = world.level(i);
      if (level === -1) level = lv;
      else if (lv !== level) return fail('地面不平，請先用「整平」工具');
      if (L.surface[i] === SURFACE.FOREST) forest++;
    }
    if (p.needsRiver && !touchesWater(world, x, y, w, h, [WATER_BODY.RIVER, WATER_BODY.LAKE])) {
      return fail('水力電廠必須緊鄰河流或湖泊');
    }
    return { ok: true, cost: plantCost(type, world.city.year) + forest * COSTS.clearForest, tiles, level };
  },
};

// ---------------- 執行 ----------------
const EXEC = {
  terrain(world, { tool, targetLevel }, v) {
    const fn = {
      [TERRAIN_TOOLS.RAISE]: raiseTile,
      [TERRAIN_TOOLS.LOWER]: lowerTile,
      [TERRAIN_TOOLS.LEVEL]: (w, i) => levelTile(w, i, targetLevel),
      [TERRAIN_TOOLS.TREES]: plantTrees,
      [TERRAIN_TOOLS.CLEAR_TREES]: clearTrees,
      [TERRAIN_TOOLS.WATER]: digWater,
    }[tool];
    const changed = v.tiles.filter((i) => fn(world, i));
    return { changed };
  },

  road(world, _cmd, v) {
    const L = world.layers;
    for (const i of v.tiles) {
      if (L.surface[i] === SURFACE.FOREST) L.surface[i] = SURFACE.GRASS;
      L.zone[i] = ZONE.NONE;
      L.net[i] |= NET.ROAD;
    }
    return { changed: v.tiles };
  },

  powerline(world, _cmd, v) {
    const L = world.layers;
    for (const i of v.tiles) {
      if (L.surface[i] === SURFACE.FOREST) L.surface[i] = SURFACE.GRASS;
      L.net[i] |= NET.POWERLINE;
    }
    return { changed: v.tiles };
  },

  zone(world, { zone }, v) {
    const L = world.layers;
    for (const i of v.tiles) {
      if (L.surface[i] === SURFACE.FOREST) L.surface[i] = SURFACE.GRASS;
      L.net[i] &= ~NET.POWERLINE; // 分區本身會導電，電線拿掉
      L.zone[i] = zone;
    }
    return { changed: v.tiles };
  },

  bikelane(world, _cmd, v) {
    for (const i of v.tiles) world.layers.net[i] |= NET.BIKE;
    return { changed: v.tiles };
  },

  busStop(world, { x, y }, v) {
    const id = world.nextInstanceId++;
    const inst = { id, def: 'busStop', kind: 'transit', x, y, w: 1, h: 1, builtYear: world.city.year, builtMonth: world.city.month };
    world.instances.set(id, inst);
    world.layers.bld[v.tiles[0]] = id;
    if (world.layers.surface[v.tiles[0]] === SURFACE.FOREST) world.layers.surface[v.tiles[0]] = SURFACE.GRASS;
    world.instancesVersion = (world.instancesVersion || 0) + 1;
    world.city.journal.push({ y: world.city.year, m: world.city.month, kind: 'transit', text: '設置公車站' });
    return { changed: v.tiles, instance: inst };
  },

  park(world, { type, x, y }, v) {
    const g = GREEN[type];
    const id = world.nextInstanceId++;
    const inst = { id, def: type, kind: 'park', x, y, w: g.footprint[0], h: g.footprint[1], builtYear: world.city.year, builtMonth: world.city.month };
    world.instances.set(id, inst);
    for (const i of v.tiles) world.layers.bld[i] = id;
    world.instancesVersion = (world.instancesVersion || 0) + 1;
    world.city.journal.push({ y: world.city.year, m: world.city.month, kind: 'green', text: `興建${g.name}` });
    return { changed: v.tiles, instance: inst };
  },

  cover(world, _cmd, v) {
    for (const i of v.tiles) world.layers.cover[i] |= v.bit;
    return { changed: v.tiles };
  },

  adapt(world, { type, x, y }, v) {
    const d = ADAPT[type];
    const L = world.layers;
    const id = world.nextInstanceId++;
    const inst = { id, def: type, kind: 'adapt', x, y, w: d.footprint[0], h: d.footprint[1], builtYear: world.city.year, builtMonth: world.city.month };
    world.instances.set(id, inst);
    for (const i of v.tiles) {
      L.bld[i] = id;
      if (L.surface[i] === SURFACE.FOREST) L.surface[i] = SURFACE.GRASS;
    }
    world.instancesVersion = (world.instancesVersion || 0) + 1;
    return { changed: v.tiles, instance: inst };
  },

  defense(world, _cmd, v) {
    const L = world.layers;
    for (const i of v.tiles) {
      L.defense[i] |= v.bit;
      if (L.surface[i] === SURFACE.FOREST) L.surface[i] = SURFACE.GRASS;
    }
    return { changed: v.tiles };
  },

  drain(world, _cmd, v) {
    for (const i of v.tiles) world.layers.net[i] |= NET.STORM_DRAIN;
    return { changed: v.tiles };
  },

  bulldoze(world, _cmd, v) {
    const L = world.layers;
    for (const i of v.tiles) {
      L.cover[i] = 0;
      L.defense[i] = 0;
      if (L.bld[i]) world.instances.delete(L.bld[i]);
      L.bld[i] = 0;
      L.net[i] = 0;
      L.zone[i] = 0;
      L.devLevel[i] = 0;
      L.pop[i] = 0;
      L.jobs[i] = 0;
      L.util[i] = 0;
      if (L.surface[i] === SURFACE.FOREST) L.surface[i] = SURFACE.GRASS;
    }
    world.instancesVersion = (world.instancesVersion || 0) + 1;
    return { changed: v.tiles };
  },

  plant(world, { type, x, y }, v) {
    const p = PLANTS[type];
    const L = world.layers;
    const id = world.nextInstanceId++;
    const inst = {
      id, def: type, kind: 'plant', x, y, w: p.footprint[0], h: p.footprint[1],
      builtYear: world.city.year, builtMonth: world.city.month, soc: 0, lastGenMWh: 0, lastCO2t: 0,
    };
    world.instances.set(id, inst);
    for (const i of v.tiles) {
      L.bld[i] = id;
      if (L.surface[i] === SURFACE.FOREST) L.surface[i] = SURFACE.GRASS;
    }
    world.instancesVersion = (world.instancesVersion || 0) + 1;
    return { changed: v.tiles, instance: inst };
  },
};

// ---------------- 工具函式 ----------------
function trackForest(world, tiles, wasForest) {
  const L = world.layers;
  const year = world.city.year;
  let cleared = 0;
  for (const i of tiles) {
    const now = L.surface[i] === SURFACE.FOREST;
    if (wasForest.has(i) && !now) {
      // 新種的小樹存的碳比較少：每年約 8 公噸，最多與成熟林相同
      const age = L.plantedYear[i] ? Math.max(0, year - L.plantedYear[i]) : Infinity;
      cleared += Math.min(EMISSIONS.clearingReleaseT, age * 8);
      L.plantedYear[i] = 0;
    } else if (!wasForest.has(i) && now) {
      L.plantedYear[i] = year;
    }
  }
  if (cleared) world.city.pendingClearT = (world.city.pendingClearT || 0) + cleared;
}

function uniq(tiles) { return [...new Set(tiles)]; }

function nearWater(world, i, kinds, r) {
  const { size } = world;
  const x = i % size, y = (i / size) | 0;
  const L = world.layers;
  for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    const nx = x + dx, ny = y + dy;
    if (nx < 0 || ny < 0 || nx >= size || ny >= size) continue;
    const j = ny * size + nx;
    if (L.surface[j] === SURFACE.WATER && kinds.includes(L.waterBody[j])) return true;
  }
  return false;
}

export function adaptAnchor(type, cx, cy) {
  const [w, h] = ADAPT[type].footprint;
  return [cx - Math.floor((w - 1) / 2), cy - Math.floor((h - 1) / 2)];
}
export { coverName };

export function footprintTiles(world, x, y, w, h) {
  const out = [];
  for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) out.push(yy * world.size + xx);
  return out;
}

function touchesWater(world, x, y, w, h, kinds) {
  const wb = world.layers.waterBody;
  for (let yy = y - 1; yy <= y + h; yy++) {
    for (let xx = x - 1; xx <= x + w; xx++) {
      if (!world.inBounds(xx, yy)) continue;
      const inside = xx >= x && xx < x + w && yy >= y && yy < y + h;
      if (!inside && kinds.includes(wb[yy * world.size + xx])) return true;
    }
  }
  return false;
}

// 有人為建設的格子：地形工具不能直接改
function isDeveloped(world, i) {
  const L = world.layers;
  return L.bld[i] !== 0 || L.net[i] !== 0 || L.zone[i] !== 0 || L.devLevel[i] !== 0;
}

// 電廠占地：讓游標所在的格子大約在占地中央
export function plantAnchor(type, cx, cy) {
  const [w, h] = PLANTS[type].footprint;
  return [cx - Math.floor((w - 1) / 2), cy - Math.floor((h - 1) / 2)];
}
