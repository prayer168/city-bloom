// 築城物語 進入點
// 模擬在 Web Worker 執行（sim/host.js），這裡只負責畫面、輸入與介面。

import { Bus } from './core/bus.js';
import { DEFAULT_MAP_SIZE } from './core/constants.js';
import { forEachInSquare } from './core/grid.js';
import { validateCommand, plantAnchor, footprintTiles, formatWan } from './sim/commands.js';
import { SimHost } from './sim/host.js';
import { Camera } from './render/camera.js';
import { Renderer } from './render/renderer.js';
import { ZONE_COLOR } from './render/tiledraw.js';
import { ZONE_INFO } from './data/buildings/zones.js';
import { PLANTS } from './data/energy.js';
import { createHud } from './ui/hud.js';
import { createToolbar, TOOLS } from './ui/toolbar.js';
import { attachInput } from './ui/input.js';
import { createNewMapDialog, createHelpDialog } from './ui/panels/newmap.js';
import { createPowerPanel } from './ui/panels/power.js';
import { createDashboard } from './ui/panels/dashboard.js';
import { createWiki } from './ui/wiki.js';
import { createClimatePanel } from './ui/panels/climate.js';
import './ui/style-climate.css';

const DEFAULT_MAP = { seed: 20261016, preset: 'river-plain', size: DEFAULT_MAP_SIZE };
const TERRAIN_TOOL_IDS = new Set(['raise', 'lower', 'level', 'trees', 'clearTrees', 'water']);

class Game {
  constructor(root) {
    this.root = root;
    this.bus = new Bus();
    this.tool = 'inspect';
    this.brush = 0;
    this.hoverTile = null;
    this.selected = null;
    this.modalOpen = false;
    this.spaceHeld = false;
    this.showFps = false;
    this.stroke = null;
    this.speed = 2;
    this.mapOptions = { ...DEFAULT_MAP };
    this.world = null;
    this.reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

    this.canvas = document.createElement('canvas');
    this.canvas.className = 'map tool-inspect';
    this.canvas.setAttribute('aria-label', '城市地圖');
    root.appendChild(this.canvas);
    this.tip = document.createElement('div');
    this.tip.className = 'cursor-tip';
    this.tip.hidden = true;
    root.appendChild(this.tip);

    this.camera = new Camera(this.mapOptions.size);
    this.host = new SimHost({
      onState: (w) => this.onState(w),
      onUpdate: (w, msg) => this.onUpdate(w, msg),
      onError: () => this.bus.emit('toast', '模擬發生錯誤，請重新整理頁面'),
    });
    this.host.init(this.mapOptions);

    this.frames = 0;
    this.fpsT = performance.now();
    this.frameMsAcc = 0;
    this.lastT = performance.now();
    this.loop = this.loop.bind(this);
    requestAnimationFrame(this.loop);
  }

  // ---------- 模擬端送來的資料 ----------
  onState(world) {
    const first = !this.world;
    this.world = world;
    this.camera.setSize(world.size);
    if (first) {
      this.renderer = new Renderer(this.canvas, world, this.camera);
      createHud(this.root, this);
      this.toolbar = createToolbar(this.root, this);
      this.newMapDialog = createNewMapDialog(this.root, this);
      this.helpDialog = createHelpDialog(this.root, this);
      this.powerPanel = createPowerPanel(this.root, this);
      this.dashboard = createDashboard(this.root, this);
      this.wiki = createWiki(this.root, this);
      this.climatePanel = createClimatePanel(this.root, this);
      this.input = attachInput(this.canvas, this);
      this.onResize = () => {
        this.renderer.resize(window.innerWidth, window.innerHeight, window.devicePixelRatio);
        this.requestDraw();
      };
      window.addEventListener('resize', this.onResize);
      this.onResize();
      this.camera.center();
    } else {
      this.renderer.setWorld(world);
    }
    this.selected = null;
    this.hoverTile = null;
    this.host.setSpeed(this.speed);
    this.bus.emit('world');
    this.requestDraw();
  }

  onUpdate(world, msg) {
    // 開著資料圖層時，每個月整張圖的數值都會變，直接重畫
    if (msg.reason === 'tick' && this.renderer.overlay !== 'none' && this.renderer.overlay !== 'power') this.renderer.clearCache();
    if (msg.changed?.length) this.renderer.tilesChanged(msg.changed);
    else if (msg.instances) this.renderer.tilesChanged([]);
    this.bus.emit('city');
    if (msg.reason === 'tick') { this.updateWeatherFx(); this.bus.emit('tick', msg); }
    this.bus.emit('hover');
    this.refreshPreview();
    this.requestDraw();
  }

  // ---------- 地圖 ----------
  newMap(opts) {
    this.mapOptions = { ...this.mapOptions, ...opts };
    this.host.init(this.mapOptions);
    this.bus.emit('toast', `已建立地圖（編號 ${this.mapOptions.seed}）`);
  }
  openNewMap() { this.newMapDialog.open(); }
  openHelp() { this.helpDialog.open(); }

  setSpeed(v) {
    this.speed = v;
    this.host.setSpeed(v);
    this.bus.emit('speed');
  }
  togglePause() {
    if (this.speed) { this.resumeSpeed = this.speed; this.setSpeed(0); }
    else this.setSpeed(this.resumeSpeed || 2);
  }

  // ---------- 工具 ----------
  setTool(id) {
    if (!TOOLS[id]) return;
    this.tool = id;
    this.canvas.classList.toggle('tool-inspect', id === 'inspect');
    this.selected = null;
    this.bus.emit('tool');
    this.refreshPreview();
  }
  setToolByKey(k) { this.toolbar.selectGroupByKey(k); }
  setBrush(r) {
    this.brush = r;
    this.bus.emit('brush');
    this.refreshPreview();
  }
  get toolDef() { return TOOLS[this.tool]; }

  brushTiles(tile) {
    const mode = this.toolDef.mode;
    const r = mode === 'brush' || mode === 'path' ? this.brush : 0;
    const out = [];
    forEachInSquare(this.world.size, tile.x, tile.y, r, (_x, _y, i) => out.push(i));
    return out;
  }

  // 依目前工具與格子，組出要送給模擬端的指令
  buildCommand(tile, extra = {}) {
    const t = this.toolDef;
    if (!tile) return null;
    if (TERRAIN_TOOL_IDS.has(this.tool)) {
      return { op: 'terrain', tool: this.tool, x: tile.x, y: tile.y, radius: this.brush, targetLevel: extra.targetLevel };
    }
    if (t.plant) {
      const [x, y] = plantAnchor(t.plant, tile.x, tile.y);
      return { op: 'plant', type: t.plant, x, y };
    }
    if (this.tool === 'busStop') return { op: 'busStop', x: tile.x, y: tile.y };
    if (t.park) {
      const w = t.park === 'bigPark' ? 2 : 1;
      return { op: 'park', type: t.park, x: tile.x - (w - 1), y: tile.y - (w - 1) };
    }
    if (t.cover) return { op: 'cover', flag: t.cover, tiles: extra.tiles ?? this.brushTiles(tile) };
    if (t.mode === 'path') return { op: this.tool, tiles: extra.tiles ?? this.brushTiles(tile) };
    if (t.mode === 'rect') return { op: 'zone', zone: t.zone, tiles: extra.tiles ?? [tile.i] };
    return null;
  }

  beginStroke(cssX, cssY) {
    const t = this.renderer.pick(cssX, cssY);
    const mode = this.toolDef.mode;
    this.stroke = { done: new Set(), start: t, last: t, targetLevel: t ? this.world.level(t.i) : null, sent: 0, failed: '' };
    if (!t) return;
    if (mode === 'click') { this.send(this.buildCommand(t)); return; }
    if (mode === 'rect') { this.updateRectPreview(t); return; }
    this.strokeTo(t);
  }

  continueStroke(cssX, cssY) {
    if (!this.stroke) return;
    const t = this.renderer.pick(cssX, cssY);
    if (!t) return;
    const mode = this.toolDef.mode;
    this.hoverTile = t;
    if (mode === 'rect') { this.updateRectPreview(t); return; }
    if (mode === 'click') return;
    if (this.stroke.targetLevel === null) this.stroke.targetLevel = this.world.level(t.i);
    this.strokeTo(t);
  }

  // 沿著上一格到這一格的直線補齊中間的格子（滑鼠移動快時不會斷掉）
  strokeTo(t) {
    const s = this.stroke;
    const from = s.last ?? t;
    const pts = lineTiles(from.x, from.y, t.x, t.y);
    s.last = t;
    const size = this.world.size;
    const tiles = [];
    for (const [x, y] of pts) {
      for (const i of this.brushTiles({ x, y, i: y * size + x })) if (!s.done.has(i)) { s.done.add(i); tiles.push(i); }
    }
    if (!tiles.length) return;
    if (TERRAIN_TOOL_IDS.has(this.tool)) {
      // 地形工具逐格送，讓整平的目標高度與「每格只升一次」都正確
      for (const i of tiles) this.send({ op: 'terrain', tool: this.tool, x: i % size, y: (i / size) | 0, radius: 0, targetLevel: s.targetLevel }, true);
    } else if (this.toolDef.cover) this.send({ op: 'cover', flag: this.toolDef.cover, tiles }, true);
    else this.send({ op: this.tool, tiles }, true);
    this.renderer.hover = { tiles: [...s.done], ok: true };
    this.requestDraw();
  }

  updateRectPreview(t) {
    const s = this.stroke;
    const a = s.start;
    const x0 = Math.min(a.x, t.x), x1 = Math.max(a.x, t.x), y0 = Math.min(a.y, t.y), y1 = Math.max(a.y, t.y);
    const tiles = [];
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) tiles.push(y * this.world.size + x);
    s.rect = tiles;
    const cmd = this.rectCommand(tiles);
    const v = validateCommand(this.world, cmd);
    const color = this.toolDef.zone ? hexA(ZONE_COLOR[ZONE_INFO[this.toolDef.zone].kind], 0.45) : 'rgba(90,200,110,0.35)';
    this.renderer.hover = { tiles, ok: v.ok, color };
    this.showTip(v.ok ? `${this.toolDef.name} ${v.tiles.length} 格 · ${formatWan(v.cost)}` : v.reason, v.ok);
    this.requestDraw();
  }

  endStroke() {
    const s = this.stroke;
    if (s && this.toolDef.mode === 'rect' && s.rect) this.send(this.rectCommand(s.rect));
    this.stroke = null;
    this.refreshPreview();
  }

  rectCommand(tiles) {
    const t = this.toolDef;
    return t.cover ? { op: 'cover', flag: t.cover, tiles } : { op: 'zone', zone: t.zone, tiles };
  }

  async send(cmd, quiet = false) {
    if (!cmd) return;
    const res = await this.host.command(cmd);
    if (!res.ok) {
      // 拖曳時同一個理由只提示一次
      if (!quiet || (this.stroke && this.stroke.failed !== res.reason)) this.bus.emit('toast', res.reason);
      if (this.stroke) this.stroke.failed = res.reason;
    } else if (cmd.op === 'plant') {
      this.bus.emit('toast', `${PLANTS[cmd.type].name}完工（${formatWan(res.cost)}）`);
    } else if (cmd.op === 'busStop') this.bus.emit('toast', `公車站設置完成（${formatWan(res.cost)}）`);
    else if (cmd.op === 'park') this.bus.emit('toast', `公園完工（${formatWan(res.cost)}）`);
  }

  // ---------- 游標與預覽 ----------
  setHover(cssX, cssY) {
    this.mouse = { x: cssX, y: cssY };
    const t = this.renderer.pick(cssX, cssY);
    const same = t && this.hoverTile && t.i === this.hoverTile.i;
    this.positionTip();
    if (same || (!t && !this.hoverTile)) return;
    this.hoverTile = t;
    this.refreshPreview();
    this.bus.emit('hover');
  }
  clearHover() {
    this.hoverTile = null;
    this.mouse = null;
    this.refreshPreview();
    this.bus.emit('hover');
  }
  select(cssX, cssY) {
    this.selected = this.renderer.pick(cssX, cssY);
    this.hoverTile = this.selected;
    this.refreshPreview();
    this.bus.emit('hover');
  }

  // 依工具顯示預覽：綠框可以蓋、紅框不行，並在游標旁顯示價格或原因
  refreshPreview() {
    if (!this.renderer || this.stroke) return;
    const t = this.selected ?? this.hoverTile;
    if (!t) { this.renderer.hover = null; this.hideTip(); this.requestDraw(); return; }
    const def = this.toolDef;
    if (this.tool === 'inspect') {
      const bid = this.world.layers.bld[t.i];
      const inst = bid && this.world.instances.get(bid);
      this.renderer.hover = { tiles: inst ? footprintTiles(this.world, inst.x, inst.y, inst.w, inst.h) : [t.i], ok: true };
      this.hideTip();
    } else {
      const cmd = this.buildCommand(t, { targetLevel: this.world.level(t.i) });
      const v = cmd ? validateCommand(this.world, cmd) : { ok: true, tiles: [t.i], cost: 0 };
      let tiles = v.tiles?.length ? v.tiles : this.brushTiles(t);
      if (def.plant) tiles = footprintTiles(this.world, cmd.x, cmd.y, ...PLANTS[def.plant].footprint).filter((i) => i >= 0 && i < this.world.count);
      if (def.park) { const w = def.park === 'bigPark' ? 2 : 1; tiles = footprintTiles(this.world, cmd.x, cmd.y, w, w).filter((i) => i >= 0 && i < this.world.count); }
      const color = def.zone ? hexA(ZONE_COLOR[ZONE_INFO[def.zone].kind], 0.45) : undefined;
      this.renderer.hover = { tiles, ok: v.ok, color };
      if (def.mode === 'brush' && !TOOLS[this.tool].cost) this.hideTip();
      else this.showTip(v.ok ? `${def.name}${v.cost ? ' · ' + formatWan(v.cost) : ''}` : v.reason, v.ok);
    }
    this.requestDraw();
  }

  showTip(text, ok) {
    this.tip.textContent = text;
    this.tip.classList.toggle('bad', !ok);
    this.tip.hidden = false;
    this.positionTip();
  }
  hideTip() { this.tip.hidden = true; }
  positionTip() {
    if (this.tip.hidden || !this.mouse) return;
    this.tip.style.transform = `translate(${Math.round(this.mouse.x + 16)}px, ${Math.round(this.mouse.y + 18)}px)`;
  }

  // ---------- 視角 ----------
  rotate(dir) {
    this.camera.rotate(dir);
    this.afterView();
    this.bus.emit('toast', ['北方在右上', '北方在右下', '北方在左下', '北方在左上'][this.camera.rot]);
  }
  zoom(dir) { if (this.camera.zoomStep(dir)) this.afterView(); }
  toggleGrid() { this.renderer.grid = !this.renderer.grid; this.afterView(); }
  toggleOverlay(name) { this.setOverlay(this.renderer.overlay === name ? 'none' : name); }
  setOverlay(name) {
    this.renderer.overlay = name;
    this.afterView();
    this.bus.emit('overlay');
  }
  toggleFps() { this.showFps = !this.showFps; this.bus.emit('fps', { fps: 0, ms: 0, visible: this.showFps }); }
  afterView() {
    this.bus.emit('view');
    this.refreshPreview();
    this.requestDraw();
  }

  requestDraw() { if (this.renderer) this.renderer.needsDraw = true; }

  // 天氣效果：大雨下雨、熱浪畫面偏暖
  updateWeatherFx() {
    const cl = this.world.city.climate;
    if (!cl || cl.temp == null) return;
    const ratio = cl.rain / Math.max(1, cl.rainNormal);
    this.renderer.fx = {
      rain: cl.rain > 120 && (ratio > 1.15 || cl.rain > 300) ? Math.min(1, cl.rain / 500) : 0,
      heat: Math.max(0, Math.min(1, (cl.tempMax - 33) / 4)),
    };
    this.requestDraw();
  }

  // 自動降低畫質：拖曳地圖時連續 2 秒低於 40 fps，就把解析度降到 1 倍（舊平板會比較順）
  checkQuality(span) {
    const moving = this.movingLoops || 0;
    this.movingLoops = 0;
    if (!this.renderer || this.renderer.maxDpr === 1 || this.renderer.dpr <= 1) return;
    const fps = (this.loops * 1000) / span;
    if (moving > this.loops * 0.6 && fps < 40) this.slowWindows = (this.slowWindows || 0) + 1;
    else this.slowWindows = 0;
    if (this.slowWindows >= 4) {
      this.renderer.maxDpr = 1;
      this.onResize();
      this.bus.emit('toast', '已自動降低畫質，讓畫面更順暢');
    }
  }

  // ---------- 主迴圈：只在需要時重畫 ----------
  loop(now) {
    const dt = Math.min(50, now - this.lastT);
    this.lastT = now;
    this.loops = (this.loops || 0) + 1;
    if (this.renderer) {
      let moving = this.input.update(dt);
      moving = this.camera.stepInertia(dt) || moving;
      if (this.bench) moving = this.bench(now) || moving;
      if (this.renderer.fx?.rain && !this.reducedMotion) this.renderer.needsDraw = true; // 雨滴動畫
      if (moving) this.movingLoops = (this.movingLoops || 0) + 1;
      if (moving || this.camera.changed || this.renderer.needsDraw) {
        this.renderer.draw(now);
        this.frames++;
        this.frameMsAcc += this.renderer.stats.lastFrameMs;
      }
    }
    if (now - this.fpsT >= 500) {
      const span = now - this.fpsT;
      this.checkQuality(span);
      const fps = Math.round((this.loops * 1000) / span);
      const ms = this.frames ? this.frameMsAcc / this.frames : 0;
      this.bus.emit('fps', { fps, ms, visible: this.showFps });
      this.frames = 0;
      this.loops = 0;
      this.frameMsAcc = 0;
      this.fpsT = now;
    }
    requestAnimationFrame(this.loop);
  }

  // 效能測試：網址加上 #bench，四段縮放各連續平移 3 秒，結果寫到主控台與 window.__bench
  startBench() {
    const t0 = performance.now();
    const per = [[], [], [], []];
    const frames = [];
    let last = t0;
    this.bench = (now) => {
      const t = now - t0;
      frames.push(now - last);
      last = now;
      const phase = Math.min(3, Math.floor(t / 3000));
      if (this.camera.zoomIndex !== phase) this.camera.zoomIndex = phase;
      else per[phase].push(this.renderer.stats.lastFrameMs);
      this.camera.panBy(Math.cos(t / 700) * 9, Math.sin(t / 900) * 6);
      if (t > 12000) {
        this.bench = null;
        const f = frames.slice(10).sort((a, b) => a - b);
        const avg = f.reduce((a, b) => a + b, 0) / f.length;
        const draw = per.map((arr) => {
          const s = arr.slice(5).sort((a, b) => a - b);
          return { avg: +(s.reduce((a, b) => a + b, 0) / s.length).toFixed(2), p95: +s[Math.floor(s.length * 0.95)].toFixed(2) };
        });
        window.__bench = { fps: Math.round(1000 / avg), p95FrameMs: +f[Math.floor(f.length * 0.95)].toFixed(2), drawMsByZoom: draw };
        console.log('[bench]', JSON.stringify(window.__bench));
        return false;
      }
      return true;
    };
  }
}

// 四方向直線（每一步只走上下或左右，道路與電線才會連起來）
export function lineTiles(x0, y0, x1, y1) {
  const out = [[x0, y0]];
  const dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
  let err = dx - dy, x = x0, y = y0;
  while (x !== x1 || y !== y1) {
    const e2 = 2 * err;
    if (x !== x1 && (e2 > -dy || y === y1)) { err -= dy; x += sx; }
    else { err += dx; y += sy; }
    out.push([x, y]);
  }
  return out;
}

function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

const game = new Game(document.getElementById('app'));
window.__zc = game; // 給自動測試與除錯用
if (location.hash === '#bench') setTimeout(() => game.startBench(), 800);
