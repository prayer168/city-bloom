// 繪製單一地形格：前方兩面牆 → 頂面 → 水岸浪花 → 格線 → 樹木
// 全部以 Canvas 幾何圖形繪製（原創造型，不使用任何外部圖檔）。

import { TILE_W, TILE_H, LEVEL_PX, BASE_LEVELS, SURFACE, SEA_LEVEL_CM, NET, UTIL, COVER, STATE, DEFENSE } from '../core/constants.js';
import { hash2 } from '../core/rng.js';
import {
  GRASS_BY_LEVEL, FOREST_BY_LEVEL, SAND, MUDFLAT, WATER_BY_DEPTH,
  WALL_BY_LEVEL, WATER_WALL, BASE_WALL, BASE,
} from './palette.js';
import { ZONE_INFO } from '../data/buildings/zones.js';
import { drawZoneBuilding, buildingHeight } from './sprites/buildings.js';
import { drawPlant, PAVED } from './sprites/plants.js';
import { bolt, box, cylinder } from './sprites/shapes.js';
import { overlayColor } from './overlays.js';

// 分區顏色：依台灣都市計畫圖慣例（住宅黃、商業紅、工業紫）
export const ZONE_COLOR = { r: '#f2cf4a', c: '#e5604f', i: '#9a7bd6' };
const ROAD = { asphalt: '#53575f', edge: '#3d4047', dash: '#ece3c4' };
const PAVEMENT = '#c9c4b8';

const HW = TILE_W / 2;
const HH = TILE_H / 2;

// view：渲染器提供的視圖資料
//   size, vlev(Uint8 視圖格層數), v2w(Int32 視圖格 → 世界索引), world, grid(bool), detail(0..2)
export function drawTile(ctx, view, vx, vy) {
  const { size, vlev, v2w, world } = view;
  const vi = vy * size + vx;
  const wi = v2w[vi];
  const lv = vlev[vi];
  const surf = world.layers.surface[wi];
  const isWater = surf === SURFACE.WATER;
  const sx = (vx - vy) * HW;
  const sy = (vx + vy) * HH - lv * LEVEL_PX;
  const variant = (hash2(wi % size, (wi / size) | 0, 7) * 4) | 0;

  // ---- 前方兩面牆 ----
  const edgeR = vx + 1 >= size;
  const edgeL = vy + 1 >= size;
  const nbR = edgeR ? -BASE_LEVELS : vlev[vi + 1];
  const nbL = edgeL ? -BASE_LEVELS : vlev[vi + size];
  const wallC = isWater ? WATER_WALL : WALL_BY_LEVEL[lv];

  if (nbR < lv) drawWall(ctx, sx, sy, lv, nbR, true, wallC, edgeR, view.detail);
  if (nbL < lv) drawWall(ctx, sx, sy, lv, nbL, false, wallC, edgeL, view.detail);

  // ---- 頂面 ----
  let fill;
  if (isWater) {
    const depthM = Math.max(0, (SEA_LEVEL_CM - world.layers.elev[wi]) / 100);
    fill = WATER_BY_DEPTH[Math.min(15, Math.round(depthM))][variant];
  } else if (surf === SURFACE.FOREST) fill = FOREST_BY_LEVEL[lv][variant];
  else if (surf === SURFACE.SAND) fill = SAND[variant];
  else if (surf === SURFACE.MUDFLAT) fill = MUDFLAT[variant];
  else fill = GRASS_BY_LEVEL[lv][variant];

  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.moveTo(sx, sy);
  ctx.lineTo(sx + HW, sy + HH);
  ctx.lineTo(sx, sy + TILE_H);
  ctx.lineTo(sx - HW, sy + HH);
  ctx.closePath();
  ctx.fill();

  // ---- 水岸浪花：水格旁邊是陸地的邊 ----
  if (isWater && view.detail > 0) {
    const s = world.layers.surface;
    ctx.strokeStyle = BASE.foam;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    let any = false;
    // 後右鄰 (vx, vy-1)：上→右 邊
    if (vy > 0 && s[v2w[vi - size]] !== SURFACE.WATER) { ctx.moveTo(sx, sy + 1); ctx.lineTo(sx + HW - 2, sy + HH); any = true; }
    // 後左鄰 (vx-1, vy)：左→上 邊
    if (vx > 0 && s[v2w[vi - 1]] !== SURFACE.WATER) { ctx.moveTo(sx - HW + 2, sy + HH); ctx.lineTo(sx, sy + 1); any = true; }
    // 前右鄰 (vx+1, vy)：右→下 邊（只在鄰格比水面高時看得到）
    if (!edgeR && s[v2w[vi + 1]] !== SURFACE.WATER && nbR >= lv) { ctx.moveTo(sx + HW - 2, sy + HH); ctx.lineTo(sx, sy + TILE_H - 1); any = true; }
    if (!edgeL && s[v2w[vi + size]] !== SURFACE.WATER && nbL >= lv) { ctx.moveTo(sx, sy + TILE_H - 1); ctx.lineTo(sx - HW + 2, sy + HH); any = true; }
    if (any) ctx.stroke();
  }

  // ---- 格線 ----
  if (view.grid) {
    ctx.strokeStyle = 'rgba(20,30,20,0.16)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(sx - HW, sy + HH);
    ctx.lineTo(sx, sy);
    ctx.lineTo(sx + HW, sy + HH);
    ctx.stroke();
  }

  const L = world.layers;
  const net = L.net[wi];
  const zone = L.zone[wi];
  const bldId = L.bld[wi];
  const dim = view.overlay !== 'none';
  if (dim) ctx.globalAlpha = 0.55;

  // ---- 電廠 ----
  if (bldId) {
    const pv = view.plantView.get(bldId);
    if (pv && PAVED.has(pv.def)) diamond(ctx, sx, sy, 0.04, PAVEMENT);
    if (pv && pv.fx === vx && pv.fy === vy) {
      const [ox, oy] = [(pv.vx0 - pv.vy0) * HW, (pv.vx0 + pv.vy0) * HH - lv * LEVEL_PX];
      drawPlant(ctx, pv.def, ox, oy, pv.W, pv.H, pv.inst, view.detail, view.south);
    }
  }

  const cv = L.cover[wi];
  const st = L.state[wi];
  // ---- 雨水花園（空地或基地上） ----
  if (cv & COVER.RAIN_GARDEN) drawRainGarden(ctx, sx, sy, wi);

  // ---- 道路 ----
  if (net & NET.ROAD) {
    drawRoad(ctx, view, vx, vy, sx, sy, lv);
    if (cv & COVER.PERMEABLE) dots(ctx, sx, sy, 'rgba(190,210,170,0.75)', 0.32, 0.68);
    if ((net & NET.STORM_DRAIN) && view.detail > 0) drainGrates(ctx, sx, sy);
    if (cv & COVER.STREET_TREES) drawStreetTrees(ctx, sx, sy, view, vx, vy, lv);
  }

  // ---- 堤防、海堤 ----
  const def = L.defense[wi];
  if (def & DEFENSE.LEVEE) {
    box(ctx, sx, sy, 0.12, 0.12, 0.88, 0.88, 5, '#8dbb6b');
    box(ctx, sx, sy, 0.3, 0.3, 0.7, 0.7, 1.5, '#a7cf84', 5);
  }
  if (def & DEFENSE.SEAWALL) {
    box(ctx, sx, sy, 0.2, 0.2, 0.8, 0.8, 9, '#aab1b9');
    box(ctx, sx, sy, 0.16, 0.16, 0.84, 0.84, 1.5, '#8a929b', 9);
  }

  // ---- 淹水、漲潮、被海水淹沒（畫在建築之前，看起來像泡在水裡） ----
  if (st & STATE.SUBMERGED) diamond(ctx, sx, sy, 0, 'rgba(46,120,170,0.82)');
  else {
    const fd = L.floodDepth[wi];
    if (fd >= 10) diamond(ctx, sx, sy, 0, `rgba(70,130,200,${Math.min(0.78, 0.35 + fd / 250)})`);
    if (st & STATE.TIDAL) tidalStripes(ctx, sx, sy);
  }

  // ---- 分區與建築（資料中心等特殊建築占用的分區格不畫） ----
  if (zone && !bldId) {
    const info = ZONE_INFO[zone];
    const dev = L.devLevel[wi];
    if (!dev) drawZoneLot(ctx, sx, sy, info);
    else {
      diamond(ctx, sx, sy, 0.06, PAVEMENT);
      if (cv & COVER.PERMEABLE) dots(ctx, sx, sy, 'rgba(150,175,120,0.8)', 0.1, 0.9);
      if (st & STATE.SUBMERGED) diamond(ctx, sx, sy, 0, 'rgba(46,120,170,0.82)');
      else if (L.floodDepth[wi] >= 10) diamond(ctx, sx, sy, 0, `rgba(70,130,200,${Math.min(0.78, 0.35 + L.floodDepth[wi] / 250)})`);
      edge(ctx, sx, sy, ZONE_COLOR[info.kind], 1.2);
      drawZoneBuilding(ctx, sx, sy, info.kind, info.dense, dev, wi % size, (wi / size) | 0, view.detail);
      const z = buildingHeight(info.kind, info.dense, dev);
      if (cv & (COVER.GREEN_ROOF | COVER.COOL_ROOF)) {
        // 屋頂：綠屋頂是一片植物，冷屋頂是反光的白色
        box(ctx, sx, sy, 0.24, 0.24, 0.76, 0.76, 1.5, cv & COVER.GREEN_ROOF ? '#4caf50' : '#f4f7fa', z);
      }
      if (cv & COVER.ROOF_SOLAR) {
        box(ctx, sx, sy, 0.3, 0.28, 0.72, 0.5, 1.2, '#2b4f8f', z + 1.5);
        box(ctx, sx, sy, 0.3, 0.55, 0.72, 0.72, 1.2, '#2b4f8f', z + 1.5);
      }
      if (cv & COVER.RAIN_HARVEST) cylinder(ctx, sx, sy, 0.76, 0.3, 0.08, 6, '#4f8fcf', z);
      if (st & STATE.DAMAGED) box(ctx, sx, sy, 0.34, 0.34, 0.6, 0.62, 1, '#3f7fdf', z + 0.5); // 受損：屋頂蓋上藍色帆布
    }
  }

  // ---- 電線 ----
  if (net & NET.POWERLINE) {
    if (cv & COVER.UNDERGROUND_GRID) drawUnderground(ctx, view, vx, vy, sx, sy, lv);
    else drawPowerline(ctx, view, vx, vy, sx, sy, lv);
  }

  // ---- 樹木 ----
  if (surf === SURFACE.FOREST && !zone && !bldId && !net) drawTrees(ctx, sx, sy, wi, size, lv, view.detail);
  if (dim) ctx.globalAlpha = 1;

  // ---- 資料圖層 ----
  if (dim) {
    const c = overlayColor(view.overlay, L, wi, view);
    if (c) {
      if (view.overlay === 'traffic') drawRoadOverlay(ctx, view, vx, vy, sx, sy, lv, c);
      else diamond(ctx, sx, sy, 0, c);
    }
  }

  // ---- 沒電標誌 ----
  if (zone && !bldId && view.detail > 0) {
    const u = L.util[wi];
    const dev = L.devLevel[wi];
    const unpowered = !(u & UTIL.POWERED);
    if (unpowered || ((u & (UTIL.BLACKOUT | UTIL.STORM_OUTAGE)) && dev)) {
      const info = ZONE_INFO[zone];
      const z = dev ? buildingHeight(info.kind, info.dense, dev) + 10 : 8;
      if (dev || view.detail >= 2) bolt(ctx, sx, sy + HH - z, dev ? 1 : 0.7, unpowered ? '#ffd23f' : '#ff9a3c');
    }
  }
}

// 點狀紋理（透水鋪面）
function dots(ctx, sx, sy, color, a, b) {
  ctx.fillStyle = color;
  for (let u = a + 0.08; u < b; u += 0.16) for (let v = a + 0.08; v < b; v += 0.16) {
    const [x, y] = LP(sx, sy, u, v);
    ctx.fillRect(x - 1, y - 0.5, 2, 1);
  }
}
function drainGrates(ctx, sx, sy) {
  ctx.fillStyle = '#23262b';
  for (const [u, v] of [[0.33, 0.33], [0.67, 0.67]]) {
    const [x, y] = LP(sx, sy, u, v);
    ctx.fillRect(x - 2.5, y - 1, 5, 2);
  }
}
function tidalStripes(ctx, sx, sy) {
  ctx.strokeStyle = 'rgba(80,150,210,0.6)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  for (const t of [0.25, 0.5, 0.75]) {
    const p = LP(sx, sy, t, 0.05), q = LP(sx, sy, t, 0.95);
    ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]);
  }
  ctx.stroke();
}
function drawRainGarden(ctx, sx, sy, wi) {
  diamond(ctx, sx, sy, 0.12, '#5f9e4b');
  ctx.fillStyle = 'rgba(90,170,220,0.85)';
  const [x, y] = LP(sx, sy, 0.45 + (wi % 3) * 0.05, 0.55);
  ctx.beginPath(); ctx.ellipse(x, y, 8, 3.5, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#d97ab0';
  for (const [u, v] of [[0.3, 0.3], [0.7, 0.35], [0.35, 0.75]]) { const [px, py] = LP(sx, sy, u, v); ctx.fillRect(px - 1, py - 2, 2, 2); }
}
// 地下電纜：地面上只看得到虛線標記
function drawUnderground(ctx, view, vx, vy, sx, sy, lv) {
  ctx.strokeStyle = 'rgba(240,170,60,0.9)';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  const [cx, cy] = LP(sx, sy, 0.5, 0.5);
  let any = false;
  for (const [dx, dy, eu, ev] of [[1, 0, 1, 0.5], [-1, 0, 0, 0.5], [0, 1, 0.5, 1], [0, -1, 0.5, 0]]) {
    if (!linked(view, vx + dx, vy + dy, lv, NET.POWERLINE, true)) continue;
    const [ex, ey] = LP(sx, sy, eu, ev);
    ctx.moveTo(cx, cy); ctx.lineTo(ex, ey); any = true;
  }
  if (!any) { ctx.moveTo(cx - 6, cy); ctx.lineTo(cx + 6, cy); }
  ctx.stroke();
  ctx.setLineDash([]);
}

// 菱形（inset = 往內縮的比例）
function diamond(ctx, sx, sy, inset, fill) {
  const a = inset, b = 1 - inset;
  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.moveTo(sx + (a - a) * HW, sy + (a + a) * HH);
  ctx.lineTo(sx + (b - a) * HW, sy + (b + a) * HH);
  ctx.lineTo(sx + (b - b) * HW, sy + (b + b) * HH);
  ctx.lineTo(sx + (a - b) * HW, sy + (a + b) * HH);
  ctx.closePath();
  ctx.fill();
}

function edge(ctx, sx, sy, color, w) {
  ctx.strokeStyle = color;
  ctx.lineWidth = w;
  ctx.beginPath();
  ctx.moveTo(sx, sy + 1);
  ctx.lineTo(sx + HW - 2, sy + HH);
  ctx.lineTo(sx, sy + TILE_H - 1);
  ctx.lineTo(sx - HW + 2, sy + HH);
  ctx.closePath();
  ctx.stroke();
}

// 空的分區：淡淡的顏色 + 內框；高密度分區多一圈
function drawZoneLot(ctx, sx, sy, info) {
  const c = ZONE_COLOR[info.kind];
  ctx.globalAlpha *= info.dense ? 0.42 : 0.28;
  diamond(ctx, sx, sy, 0.08, c);
  ctx.globalAlpha /= info.dense ? 0.42 : 0.28;
  ctx.strokeStyle = c;
  ctx.lineWidth = 1.5;
  for (const inset of info.dense ? [0.1, 0.22] : [0.1]) {
    const a = inset, b = 1 - inset;
    ctx.beginPath();
    ctx.moveTo(sx, sy + 2 * a * HH);
    ctx.lineTo(sx + (b - a) * HW, sy + (a + b) * HH);
    ctx.lineTo(sx, sy + 2 * b * HH);
    ctx.lineTo(sx - (b - a) * HW, sy + (a + b) * HH);
    ctx.closePath();
    ctx.stroke();
  }
}

// 局部座標 (u, v) ∈ [0,1]² → 畫面座標
const LP = (sx, sy, u, v) => [sx + (u - v) * HW, sy + (u + v) * HH];

function quadUV(ctx, sx, sy, u0, v0, u1, v1) {
  const a = LP(sx, sy, u0, v0), b = LP(sx, sy, u1, v0), c = LP(sx, sy, u1, v1), d = LP(sx, sy, u0, v1);
  ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.closePath();
}

// 相鄰的視圖格是否有某種網路，而且高差不超過 1 層（可以接坡道）
function linked(view, vx, vy, lv, flag, alsoBld = false) {
  const { size, v2w, vlev, world } = view;
  if (vx < 0 || vy < 0 || vx >= size || vy >= size) return false;
  const vi = vy * size + vx;
  const wi = v2w[vi];
  const ok = (world.layers.net[wi] & flag) || (alsoBld && world.layers.bld[wi]);
  return !!ok && Math.abs(vlev[vi] - lv) <= (alsoBld ? 15 : 1);
}

function drawRoad(ctx, view, vx, vy, sx, sy, lv) {
  const a = 0.3, b = 0.7;
  const e = [
    linked(view, vx + 1, vy, lv, NET.ROAD), // +u
    linked(view, vx - 1, vy, lv, NET.ROAD), // -u
    linked(view, vx, vy + 1, lv, NET.ROAD), // +v
    linked(view, vx, vy - 1, lv, NET.ROAD), // -v
  ];
  ctx.fillStyle = ROAD.asphalt;
  ctx.beginPath();
  quadUV(ctx, sx, sy, a, a, b, b);
  if (e[0]) quadUV(ctx, sx, sy, b - 0.01, a, 1, b);
  if (e[1]) quadUV(ctx, sx, sy, 0, a, a + 0.01, b);
  if (e[2]) quadUV(ctx, sx, sy, a, b - 0.01, b, 1);
  if (e[3]) quadUV(ctx, sx, sy, a, 0, b, a + 0.01);
  ctx.fill();
  // 自行車道：道路兩側的綠色線
  const wiR = view.v2w[vy * view.size + vx];
  if (view.world.layers.net[wiR] & NET.BIKE) {
    ctx.fillStyle = '#3fbf6f';
    ctx.beginPath();
    const s0 = a - 0.06, s1 = a, t0 = b, t1 = b + 0.06;
    if (e[0] || e[1] || (!e[2] && !e[3])) { quadUV(ctx, sx, sy, e[1] ? 0 : a, s0, e[0] ? 1 : b, s1); quadUV(ctx, sx, sy, e[1] ? 0 : a, t0, e[0] ? 1 : b, t1); }
    if (e[2] || e[3]) { quadUV(ctx, sx, sy, s0, e[3] ? 0 : a, s1, e[2] ? 1 : b); quadUV(ctx, sx, sy, t0, e[3] ? 0 : a, t1, e[2] ? 1 : b); }
    ctx.fill();
  }
  if (view.detail < 2) return;
  // 中央虛線
  ctx.strokeStyle = ROAD.dash;
  ctx.lineWidth = 1;
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  const m = 0.5;
  const line = (u0, v0, u1, v1) => { const p = LP(sx, sy, u0, v0), q = LP(sx, sy, u1, v1); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); };
  if (e[0]) line(m, m, 1, m);
  if (e[1]) line(0, m, m, m);
  if (e[2]) line(m, m, m, 1);
  if (e[3]) line(m, 0, m, m);
  ctx.stroke();
  ctx.setLineDash([]);
}

// 行道樹：道路兩側的小圓樹
function drawStreetTrees(ctx, sx, sy, view, vx, vy, lv) {
  const along = linked(view, vx + 1, vy, lv, NET.ROAD) || linked(view, vx - 1, vy, lv, NET.ROAD);
  const pts = along ? [[0.25, 0.15], [0.75, 0.15], [0.25, 0.85], [0.75, 0.85]] : [[0.15, 0.25], [0.15, 0.75], [0.85, 0.25], [0.85, 0.75]];
  pts.sort((a, b) => a[0] + a[1] - (b[0] + b[1]));
  for (const [u, v] of pts) {
    const [x, y] = LP(sx, sy, u, v);
    ctx.fillStyle = BASE.trunk;
    ctx.fillRect(x - 0.8, y - 5, 1.6, 5);
    ctx.fillStyle = '#3c8f3f';
    ctx.beginPath();
    ctx.arc(x, y - 7, 4, 0, Math.PI * 2);
    ctx.fill();
  }
}

// 交通圖層：把道路本身塗上車流顏色
function drawRoadOverlay(ctx, view, vx, vy, sx, sy, lv, color) {
  const a = 0.26, b = 0.74;
  const e = [
    linked(view, vx + 1, vy, lv, NET.ROAD), linked(view, vx - 1, vy, lv, NET.ROAD),
    linked(view, vx, vy + 1, lv, NET.ROAD), linked(view, vx, vy - 1, lv, NET.ROAD),
  ];
  ctx.fillStyle = color;
  ctx.beginPath();
  quadUV(ctx, sx, sy, a, a, b, b);
  if (e[0]) quadUV(ctx, sx, sy, b - 0.01, a, 1, b);
  if (e[1]) quadUV(ctx, sx, sy, 0, a, a + 0.01, b);
  if (e[2]) quadUV(ctx, sx, sy, a, b - 0.01, b, 1);
  if (e[3]) quadUV(ctx, sx, sy, a, 0, b, a + 0.01);
  ctx.fill();
}

const POLE_H = 18;
function drawPowerline(ctx, view, vx, vy, sx, sy, lv) {
  const [cx, cy] = LP(sx, sy, 0.5, 0.5);
  const topY = cy - POLE_H;
  // 電線：連到相鄰的電線或電廠（畫到格子邊緣的中點）
  ctx.strokeStyle = '#2b2a28';
  ctx.lineWidth = 1;
  ctx.beginPath();
  const nbs = [[1, 0, 1, 0.5], [-1, 0, 0, 0.5], [0, 1, 0.5, 1], [0, -1, 0.5, 0]];
  for (const [dx, dy, eu, ev] of nbs) {
    if (!linked(view, vx + dx, vy + dy, lv, NET.POWERLINE, true)) continue;
    const nlv = view.vlev[(vy + dy) * view.size + vx + dx];
    const [ex, ey] = LP(sx, sy, eu, ev);
    const zEdge = POLE_H + ((nlv - lv) * LEVEL_PX) / 2;
    for (const off of [-3, 3]) {
      ctx.moveTo(cx + off, topY + 2);
      ctx.lineTo(ex + off, ey - zEdge + 2);
    }
  }
  ctx.stroke();
  // 電線桿
  ctx.fillStyle = '#6d5a48';
  ctx.fillRect(cx - 1, topY, 2, POLE_H);
  ctx.fillStyle = '#4a4038';
  ctx.fillRect(cx - 5, topY + 1, 10, 2);
}

function drawWall(ctx, sx, sy, lv, nb, right, c, isEdge, detail) {
  // 右前牆：右頂點 → 下頂點；左前牆：下頂點 → 左頂點
  const ax = right ? sx + HW : sx - HW;
  const ay = sy + HH;
  const bx = sx;
  const by = sy + TILE_H;
  const color = right ? c.right : c.left;

  // 地面以上的部分
  const aboveBottom = Math.max(nb, 0);
  const dropA = (lv - aboveBottom) * LEVEL_PX;
  if (dropA > 0) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(bx, by);
    ctx.lineTo(bx, by + dropA);
    ctx.lineTo(ax, ay + dropA);
    ctx.closePath();
    ctx.fill();
    if (detail > 0 && lv - aboveBottom > 1) {
      // 每一層一條分層線，讓學生看得出高差有幾層
      ctx.strokeStyle = c.line;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let k = 1; k < lv - aboveBottom; k++) {
        const o = k * LEVEL_PX;
        ctx.moveTo(ax, ay + o);
        ctx.lineTo(bx, by + o);
      }
      ctx.stroke();
    }
  }
  // 地圖邊緣：往下畫出地基，看起來像一塊模型
  if (isEdge) {
    const top = dropA;
    const dropB = top + BASE_LEVELS * LEVEL_PX;
    ctx.fillStyle = right ? BASE_WALL.right : BASE_WALL.left;
    ctx.beginPath();
    ctx.moveTo(ax, ay + top);
    ctx.lineTo(bx, by + top);
    ctx.lineTo(bx, by + dropB);
    ctx.lineTo(ax, ay + dropB);
    ctx.closePath();
    ctx.fill();
  }
}

function drawTrees(ctx, sx, sy, wi, size, lv, detail) {
  const x = wi % size, y = (wi / size) | 0;
  const count = detail === 0 ? 1 : 3;
  const conifer = lv >= 7;
  // 樹的位置用格子座標雜湊決定（每次重畫都一樣），由後往前畫
  const pts = [];
  for (let k = 0; k < count; k++) {
    const u = 0.22 + hash2(x, y, 11 + k) * 0.56;
    const v = 0.22 + hash2(x, y, 23 + k) * 0.56;
    pts.push([u, v, 0.8 + hash2(x, y, 37 + k) * 0.45]);
  }
  pts.sort((a, b) => a[0] + a[1] - (b[0] + b[1]));
  for (const [u, v, sc] of pts) {
    const px = sx + (u - v) * HW;
    const py = sy + (u + v) * HH;
    ctx.fillStyle = BASE.trunk;
    ctx.fillRect(px - 1, py - 5 * sc, 2, 5 * sc);
    if (conifer) {
      ctx.fillStyle = BASE.conifer;
      ctx.beginPath();
      ctx.moveTo(px, py - 17 * sc);
      ctx.lineTo(px + 6 * sc, py - 6 * sc);
      ctx.lineTo(px - 6 * sc, py - 6 * sc);
      ctx.closePath();
      ctx.moveTo(px, py - 21 * sc);
      ctx.lineTo(px + 4.5 * sc, py - 12 * sc);
      ctx.lineTo(px - 4.5 * sc, py - 12 * sc);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.fillStyle = BASE.canopy;
      ctx.beginPath();
      ctx.arc(px, py - 10 * sc, 6 * sc, 0, Math.PI * 2);
      ctx.fill();
      if (detail > 0) {
        ctx.fillStyle = BASE.canopyLight;
        ctx.beginPath();
        ctx.arc(px - 2 * sc, py - 12 * sc, 3 * sc, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
}

// 單格可能佔用的畫面範圍（相對於上頂點），給分塊查詢用
export const TILE_EXTENT = Object.freeze({
  up: 230,                                     // 最高的建築（4×4 電廠從前方格往後、往上延伸）
  down: TILE_H + (15 + BASE_LEVELS) * LEVEL_PX, // 最深的牆
  side: HW * 4,                                // 4×4 電廠往左右延伸
});
