// 鏡頭：中心點（世界畫面座標）、三段縮放、四方向旋轉、慣性平移

import { ZOOM_LEVELS } from '../core/constants.js';
import { mapBounds, screenToGround, tileTop } from './iso.js';

export class Camera {
  constructor(size) {
    this.size = size;
    this.x = 0;
    this.y = size * 16;
    this.zoomIndex = 1; // 預設 ×0.5
    this.rot = 0;
    this.vw = 800; // 視窗寬（CSS px）
    this.vh = 600;
    this.vx = 0;   // 慣性速度（世界單位 / 毫秒）
    this.vy = 0;
    this.changed = true;
  }

  get zoom() { return ZOOM_LEVELS[this.zoomIndex]; }

  setViewport(w, h) { this.vw = w; this.vh = h; this.clamp(); this.changed = true; }

  setSize(size) { this.size = size; this.center(); }

  center() {
    this.x = 0;
    this.y = this.size * 16;
    this.clamp();
    this.changed = true;
  }

  // CSS 像素 ↔ 世界畫面座標
  toWorld(cssX, cssY) {
    const z = this.zoom;
    return [(cssX - this.vw / 2) / z + this.x, (cssY - this.vh / 2) / z + this.y];
  }
  toScreen(wx, wy) {
    const z = this.zoom;
    return [(wx - this.x) * z + this.vw / 2, (wy - this.y) * z + this.vh / 2];
  }

  panBy(dxCss, dyCss) {
    const z = this.zoom;
    this.x -= dxCss / z;
    this.y -= dyCss / z;
    this.clamp();
    this.changed = true;
  }

  // 以畫面上某點為錨點縮放（滑鼠位置不動）
  zoomStep(dir, anchorX = this.vw / 2, anchorY = this.vh / 2) {
    const next = Math.max(0, Math.min(ZOOM_LEVELS.length - 1, this.zoomIndex + dir));
    if (next === this.zoomIndex) return false;
    const [wx, wy] = this.toWorld(anchorX, anchorY);
    this.zoomIndex = next;
    const z = this.zoom;
    this.x = wx - (anchorX - this.vw / 2) / z;
    this.y = wy - (anchorY - this.vh / 2) / z;
    this.clamp();
    this.changed = true;
    return true;
  }

  // 旋轉 90°（dir = +1 順時針，-1 逆時針），保持畫面中心的地點不變
  rotate(dir) {
    const n = this.size;
    const [gx, gy] = screenToGround(this.x, this.y);
    const cvx = Math.max(0, Math.min(n, gx)), cvy = Math.max(0, Math.min(n, gy));
    const [wx, wy] = groundViewToWorld(cvx, cvy, this.rot, n);
    this.rot = (this.rot + dir + 4) & 3;
    const [nvx, nvy] = groundWorldToView(wx, wy, this.rot, n);
    [this.x, this.y] = tileTop(nvx, nvy, 0);
    this.clamp();
    this.changed = true;
  }

  clamp() {
    const b = mapBounds(this.size);
    const marginX = this.vw / (2 * this.zoom) * 0.5;
    const marginY = this.vh / (2 * this.zoom) * 0.5;
    this.x = Math.max(b.x0 + marginX * 0.2, Math.min(b.x1 - marginX * 0.2, this.x));
    this.y = Math.max(b.y0 + marginY * 0.2, Math.min(b.y1 - marginY * 0.2, this.y));
  }

  // 慣性：放開拖曳後繼續滑行，回傳是否仍在移動
  stepInertia(dtMs) {
    if (Math.abs(this.vx) < 0.005 && Math.abs(this.vy) < 0.005) { this.vx = this.vy = 0; return false; }
    this.x -= this.vx * dtMs;
    this.y -= this.vy * dtMs;
    const decay = Math.pow(0.9, dtMs / 16);
    this.vx *= decay;
    this.vy *= decay;
    this.clamp();
    this.changed = true;
    return true;
  }
}

// 連續地面座標的旋轉（格 k 佔 [k, k+1)，所以鏡射用 size 而不是 size-1）
export function groundWorldToView(x, y, rot, n) {
  switch (rot & 3) {
    case 0: return [x, y];
    case 1: return [n - y, x];
    case 2: return [n - x, n - y];
    default: return [y, n - x];
  }
}
export function groundViewToWorld(vx, vy, rot, n) {
  switch (rot & 3) {
    case 0: return [vx, vy];
    case 1: return [vy, n - vx];
    case 2: return [n - vx, n - vy];
    default: return [n - vy, vx];
  }
}
