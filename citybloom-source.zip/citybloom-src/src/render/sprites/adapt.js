// 氣候調適設施造型（原創）。座標以占地左上角（視圖）為原點，W × H 為占地格數。

import { P, poly, box, cylinder } from './shapes.js';

export const ADAPT_PAVED = new Set(['pumpStation', 'recycledWater', 'desalination', 'shelter', 'coolingCenter', 'warningCenter']);

export const ADAPT_SPRITES = {
  // 滯洪池：外圈草坡、內圈泥土斜面、中間的水（平常水位低）
  detentionPond(ctx, ox, oy, W, H) {
    poly(ctx, [P(ox, oy, 0.04, 0.04), P(ox, oy, W - 0.04, 0.04), P(ox, oy, W - 0.04, H - 0.04), P(ox, oy, 0.04, H - 0.04)], '#83bf69');
    poly(ctx, [P(ox, oy, 0.3, 0.3), P(ox, oy, W - 0.3, 0.3), P(ox, oy, W - 0.3, H - 0.3), P(ox, oy, 0.3, H - 0.3)], '#7a8f55');
    poly(ctx, [P(ox, oy, 0.5, 0.5), P(ox, oy, W - 0.5, 0.5), P(ox, oy, W - 0.5, H - 0.5), P(ox, oy, 0.5, H - 0.5)], '#4f9fd6');
    poly(ctx, [P(ox, oy, 0.62, 0.62), P(ox, oy, W - 0.9, 0.62), P(ox, oy, W - 0.9, 0.9), P(ox, oy, 0.62, 0.9)], 'rgba(255,255,255,0.25)');
    // 進水口
    box(ctx, ox, oy, 0.05, H / 2 - 0.12, 0.35, H / 2 + 0.12, 2.5, '#9aa3ad');
    // 步道欄杆
    ctx.strokeStyle = '#e8dcb8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    const a = P(ox, oy, 0.15, 0.15), b = P(ox, oy, W - 0.15, 0.15), c = P(ox, oy, W - 0.15, H - 0.15);
    ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]);
    ctx.stroke();
  },

  // 抽水站：小廠房 + 粗水管
  pumpStation(ctx, ox, oy) {
    box(ctx, ox, oy, 0.18, 0.2, 0.82, 0.72, 14, '#a9b8c6');
    box(ctx, ox, oy, 0.14, 0.16, 0.86, 0.76, 2, '#4f6378', 14);
    cylinder(ctx, ox, oy, 0.82, 0.88, 0.09, 6, '#3f7fbf');
    cylinder(ctx, ox, oy, 0.6, 0.9, 0.09, 6, '#3f7fbf');
    // 藍色水滴標誌
    const [x, y] = P(ox, oy, 0.5, 0.72, 8);
    ctx.fillStyle = '#2f8fd8';
    ctx.beginPath(); ctx.moveTo(x, y - 5); ctx.quadraticCurveTo(x + 4, y + 1, x, y + 3); ctx.quadraticCurveTo(x - 4, y + 1, x, y - 5); ctx.fill();
  },

  // 再生水廠：圓形沉澱池 + 處理槽 + 小辦公室
  recycledWater(ctx, ox, oy) {
    for (const [u, v] of [[0.55, 0.55], [1.45, 0.55]]) {
      cylinder(ctx, ox, oy, u, v, 0.38, 5, '#b8c4cc');
      const [x, y] = P(ox, oy, u, v, 5);
      ctx.fillStyle = '#5fb8a8';
      ctx.beginPath(); ctx.ellipse(x, y, 19, 9.5, 0, 0, Math.PI * 2); ctx.fill();
    }
    box(ctx, ox, oy, 0.25, 1.15, 1.2, 1.8, 7, '#8fc3d1');
    poly(ctx, [P(ox, oy, 0.32, 1.22, 7), P(ox, oy, 1.13, 1.22, 7), P(ox, oy, 1.13, 1.73, 7), P(ox, oy, 0.32, 1.73, 7)], '#6fc0b0');
    box(ctx, ox, oy, 1.35, 1.2, 1.85, 1.8, 11, '#e4e8ec');
    box(ctx, ox, oy, 1.32, 1.17, 1.88, 1.83, 1.5, '#2f8f7b', 11);
  },

  // 海水淡化廠：白色廠房、藍色條紋、薄膜管架、儲水槽
  desalination(ctx, ox, oy) {
    box(ctx, ox, oy, 0.2, 0.2, 1.3, 1.1, 16, '#eef2f5');
    box(ctx, ox, oy, 0.2, 0.2, 1.3, 1.1, 2.5, '#3f7fbf', 10);
    for (let k = 0; k < 4; k++) box(ctx, ox, oy, 0.25 + k * 0.27, 1.3, 0.42 + k * 0.27, 1.85, 6, '#9fb4c4');
    cylinder(ctx, ox, oy, 1.6, 0.6, 0.3, 14, '#cfdbe4');
    cylinder(ctx, ox, oy, 1.6, 0.6, 0.31, 2, '#3f7fbf', 14);
  },

  // 避難中心：大屋頂的活動中心，門口綠色避難標誌
  shelter(ctx, ox, oy) {
    box(ctx, ox, oy, 0.12, 0.15, 0.88, 0.8, 12, '#e3d3b0');
    box(ctx, ox, oy, 0.08, 0.1, 0.92, 0.85, 3, '#b7633f', 12);
    const [x, y] = P(ox, oy, 0.5, 0.82, 9);
    ctx.fillStyle = '#2f9a5b';
    ctx.fillRect(x - 5, y - 4, 10, 7);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.moveTo(x - 3, y + 1); ctx.lineTo(x, y - 3); ctx.lineTo(x + 3, y + 1); ctx.closePath(); ctx.fill();
  },

  // 涼爽中心：淺藍色建築、遮陽棚、樹
  coolingCenter(ctx, ox, oy) {
    box(ctx, ox, oy, 0.15, 0.15, 0.85, 0.7, 11, '#d3e8f5');
    box(ctx, ox, oy, 0.12, 0.12, 0.88, 0.73, 2, '#4f97cf', 11);
    box(ctx, ox, oy, 0.2, 0.7, 0.8, 0.88, 1.5, '#7fc2ea', 7);
    const [x, y] = P(ox, oy, 0.85, 0.88);
    ctx.fillStyle = '#6b4a2b'; ctx.fillRect(x - 1, y - 6, 2, 6);
    ctx.fillStyle = '#3c8f3f'; ctx.beginPath(); ctx.arc(x, y - 9, 5, 0, Math.PI * 2); ctx.fill();
    // 雪花符號
    const [sx, sy] = P(ox, oy, 0.5, 0.7, 6);
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.3;
    ctx.beginPath();
    for (let k = 0; k < 3; k++) { const a = (k * Math.PI) / 3; ctx.moveTo(sx - Math.cos(a) * 3.5, sy - Math.sin(a) * 3.5); ctx.lineTo(sx + Math.cos(a) * 3.5, sy + Math.sin(a) * 3.5); }
    ctx.stroke();
  },

  // 災害預警中心：建築 + 氣象雷達球 + 天線
  warningCenter(ctx, ox, oy) {
    box(ctx, ox, oy, 0.15, 0.2, 0.85, 0.8, 10, '#c3cbd4');
    box(ctx, ox, oy, 0.4, 0.4, 0.65, 0.65, 8, '#a5afba', 10);
    const [x, y] = P(ox, oy, 0.52, 0.52, 18);
    ctx.fillStyle = '#f4f6f8';
    ctx.beginPath(); ctx.arc(x, y - 2, 7, Math.PI, 0); ctx.lineTo(x + 7, y + 1); ctx.lineTo(x - 7, y + 1); ctx.fill();
    ctx.strokeStyle = '#8a96a3'; ctx.lineWidth = 0.8; ctx.stroke();
    const [ax, ay] = P(ox, oy, 0.25, 0.3, 10);
    ctx.fillStyle = '#5b636b'; ctx.fillRect(ax - 0.7, ay - 16, 1.4, 16);
    ctx.fillStyle = '#e04a3a'; ctx.fillRect(ax - 1.5, ay - 18, 3, 2.5);
  },
};
