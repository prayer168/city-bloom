// AI 資料中心與智慧城市設施造型（原創）

import { P, box, cylinder } from './shapes.js';

export const AI_PAVED = new Set(['dataCenter', 'aiSignals', 'aiGrid', 'aiWeather', 'aiWater']);

export const AI_SPRITES = {
  // 資料中心：兩棟長方形機房、屋頂成排的冷卻風扇、藍色指示燈；升級後屋頂樣子不同
  dataCenter(ctx, ox, oy, W, H, inst, detail) {
    const up = inst?.upgrades || {};
    const Hh = 28;
    box(ctx, ox, oy, 0.25, 0.25, W - 0.25, 1.35, Hh, '#4b5566', 0, { top: '#7d8796' });
    box(ctx, ox, oy, 0.25, 1.6, W - 0.25, H - 0.25, Hh, '#465061', 0, { top: '#7d8796' });
    // 牆面的藍色燈帶（兩層）
    for (const [v0, v1] of [[0.25, 1.35], [1.6, H - 0.25]]) for (const z of [8, 18]) {
      box(ctx, ox, oy, 0.24, v1 - 0.02, W - 0.26, v1, 2.5, '#4fb4ff', z);
      box(ctx, ox, oy, W - 0.26, v0 + 0.05, W - 0.24, v1 - 0.05, 2.5, '#3a9be0', z);
    }
    // 屋頂：氣冷是一排排風扇；液冷是平整的熱交換器
    for (const [v0, v1] of [[0.35, 1.25], [1.7, H - 0.35]]) {
      if (up.liquid) box(ctx, ox, oy, 0.4, v0 + 0.1, W - 0.4, v1 - 0.1, 3, '#5d7ea6', Hh);
      else for (let u = 0.45; u < W - 0.4; u += 0.55) {
        const [x, y] = P(ox, oy, u + 0.2, (v0 + v1) / 2, Hh + 1);
        ctx.fillStyle = '#6b7380';
        ctx.beginPath(); ctx.ellipse(x, y, 7, 3.5, 0, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#3f454f'; ctx.lineWidth = 1; ctx.stroke();
      }
    }
    // 廢熱回收：橘色管線通往外面
    if (up.heatRecovery) {
      const a = P(ox, oy, 0.2, H / 2, 6), b = P(ox, oy, -0.3, H / 2, 6);
      ctx.strokeStyle = '#e8913a'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
    }
    // 綠電契約：屋頂的綠色葉子標誌
    if (up.green) {
      const [x, y] = P(ox, oy, W / 2, 0.8, Hh + 6);
      ctx.fillStyle = '#3cc87a';
      ctx.beginPath(); ctx.ellipse(x, y, 6, 3.5, -0.5, 0, Math.PI * 2); ctx.fill();
    }
    // 熱氣（沒有液冷時比較明顯）
    if (detail > 0 && !up.liquid) {
      ctx.fillStyle = 'rgba(255,170,90,0.18)';
      const [x, y] = P(ox, oy, W / 2, H / 2, Hh + 10);
      ctx.beginPath(); ctx.ellipse(x, y, 30, 10, 0, 0, Math.PI * 2); ctx.fill();
    }
  },

  // AI 智慧號誌：控制機房 + 號誌桿
  aiSignals(ctx, ox, oy) {
    box(ctx, ox, oy, 0.2, 0.25, 0.7, 0.75, 9, '#c9d3dd');
    box(ctx, ox, oy, 0.18, 0.23, 0.72, 0.77, 1.5, '#5b6f86', 9);
    const [x, y] = P(ox, oy, 0.85, 0.85);
    ctx.fillStyle = '#4a4f57'; ctx.fillRect(x - 0.8, y - 20, 1.6, 20);
    ctx.fillStyle = '#2a2d33'; ctx.fillRect(x - 3, y - 24, 6, 13);
    [['#e5604f', -21], ['#f2c94c', -17], ['#3cc87a', -13]].forEach(([c, dy]) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y + dy, 1.6, 0, Math.PI * 2); ctx.fill(); });
  },

  // AI 智慧電網：調度中心 + 變電設備
  aiGrid(ctx, ox, oy) {
    box(ctx, ox, oy, 0.15, 0.15, 0.6, 0.6, 10, '#cfd6de');
    box(ctx, ox, oy, 0.13, 0.13, 0.62, 0.62, 1.5, '#c98500', 10);
    box(ctx, ox, oy, 0.6, 0.62, 0.85, 0.85, 7, '#8a929b');
    cylinder(ctx, ox, oy, 0.3, 0.8, 0.08, 9, '#b0b7bf');
  },

  // AI 氣象預警：雷達球 + 資料天線
  aiWeather(ctx, ox, oy) {
    box(ctx, ox, oy, 0.2, 0.2, 0.8, 0.8, 8, '#bcc6d1');
    const [x, y] = P(ox, oy, 0.5, 0.5, 8);
    ctx.fillStyle = '#f4f6f8';
    ctx.beginPath(); ctx.arc(x, y - 6, 8, Math.PI, 0); ctx.lineTo(x + 8, y - 4); ctx.lineTo(x - 8, y - 4); ctx.fill();
    ctx.fillStyle = '#4fb4ff';
    ctx.beginPath(); ctx.arc(x, y - 10, 2, 0, Math.PI * 2); ctx.fill();
  },

  // AI 水資源管理：水塔 + 感測器
  aiWater(ctx, ox, oy) {
    cylinder(ctx, ox, oy, 0.45, 0.45, 0.28, 14, '#8fc3d1');
    cylinder(ctx, ox, oy, 0.45, 0.45, 0.29, 2, '#3f7fbf', 14);
    box(ctx, ox, oy, 0.68, 0.62, 0.88, 0.88, 6, '#d4dae1');
    const [x, y] = P(ox, oy, 0.78, 0.75, 7);
    ctx.fillStyle = '#4fb4ff'; ctx.beginPath(); ctx.arc(x, y, 1.5, 0, Math.PI * 2); ctx.fill();
  },
};
