// 電廠造型（原創）。座標以占地左上角（視圖）為原點，W × H 為視圖中的占地格數。

import { hash2 } from '../../core/rng.js';
import { shade } from '../palette.js';
import { P, poly, box, cylinder } from './shapes.js';

// south：世界的南方在目前視角是哪個方向（'+u' '-u' '+v' '-v'）
export function drawPlant(ctx, def, ox, oy, W, H, inst, detail, south = '+v') {
  const fn = PLANT_SPRITES[def];
  if (fn) fn(ctx, ox, oy, W, H, inst, detail, south);
}

// 電廠占地地面是否要鋪水泥（太陽能與風力保留草地）
export const PAVED = new Set(['coal', 'gas', 'nuclear', 'hydro', 'battery', 'busStop']);

const PLANT_SPRITES = {
  park: (ctx, ox, oy, W, H) => parkSprite(ctx, ox, oy, W, H),
  bigPark: (ctx, ox, oy, W, H) => parkSprite(ctx, ox, oy, W, H),

  busStop(ctx, ox, oy) {
    // 候車亭：屋頂 + 背板 + 站牌
    box(ctx, ox, oy, 0.25, 0.3, 0.8, 0.42, 9, '#7fa7c9');
    box(ctx, ox, oy, 0.2, 0.25, 0.85, 0.65, 1.5, '#2f6f9f', 9);
    const [x, y] = P(ox, oy, 0.82, 0.78);
    ctx.fillStyle = '#5b636b';
    ctx.fillRect(x - 0.8, y - 16, 1.6, 16);
    ctx.fillStyle = '#2f8f5b';
    ctx.fillRect(x - 3.5, y - 19, 7, 5);
  },

  coal(ctx, ox, oy, W, H) {
    // 煤堆
    const c = P(ox, oy, 0.9, H - 0.9);
    ctx.fillStyle = '#2d2a28';
    ctx.beginPath();
    ctx.ellipse(c[0], c[1] - 3, 34, 15, 0, Math.PI, 0);
    ctx.lineTo(c[0] + 34, c[1] - 3);
    ctx.ellipse(c[0], c[1] - 3, 34, 15, 0, 0, Math.PI);
    ctx.fill();
    ctx.fillStyle = '#3d3936';
    ctx.beginPath();
    ctx.ellipse(c[0] - 4, c[1] - 9, 22, 9, 0, Math.PI, 0);
    ctx.fill();
    // 主廠房與鍋爐
    box(ctx, ox, oy, 1.6, 0.4, W - 0.4, H - 1.6, 30, '#8a4b3a');
    box(ctx, ox, oy, 2.2, 0.6, W - 0.7, 1.8, 42, '#9a5a45');
    // 兩根高煙囪，頂端紅白相間
    for (const [u, v] of [[0.8, 0.7], [1.5, 0.5]]) {
      cylinder(ctx, ox, oy, u, v, 0.16, 78, '#b9b4ae');
      cylinder(ctx, ox, oy, u, v, 0.165, 6, '#d24a3c', 64);
      cylinder(ctx, ox, oy, u, v, 0.165, 4, '#f2efe9', 72);
    }
    // 煙
    smoke(ctx, P(ox, oy, 0.8, 0.7, 84), 'rgba(110,110,110,0.45)');
    smoke(ctx, P(ox, oy, 1.5, 0.5, 84), 'rgba(110,110,110,0.4)');
  },

  gas(ctx, ox, oy, W, H) {
    box(ctx, ox, oy, 0.4, 0.9, W - 0.3, H - 0.3, 22, '#9aa7b5');
    box(ctx, ox, oy, 0.6, 1.1, W - 0.6, H - 0.6, 6, '#b7c2cc', 22);
    cylinder(ctx, ox, oy, 0.7, 0.5, 0.14, 56, '#c3c7cb');
    // 天然氣儲槽（球形）
    const t = P(ox, oy, W - 0.7, 0.55, 0);
    ctx.fillStyle = '#e8eaec';
    ctx.beginPath();
    ctx.arc(t[0], t[1] - 14, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#c8ccd0';
    ctx.beginPath();
    ctx.arc(t[0] + 4, t[1] - 11, 9, -0.2, Math.PI * 0.9);
    ctx.fill();
    smoke(ctx, P(ox, oy, 0.7, 0.5, 60), 'rgba(235,235,235,0.5)');
  },

  nuclear(ctx, ox, oy, W, H) {
    // 冷卻塔 ×2（雙曲面）
    for (const [u, v] of [[1.0, 1.0], [2.4, 0.9]]) coolingTower(ctx, P(ox, oy, u, v), 30, 68);
    // 反應爐圓頂
    const d = P(ox, oy, W - 1.1, H - 1.1);
    box(ctx, ox, oy, W - 1.9, H - 1.9, W - 0.3, H - 0.3, 16, '#c9c4bb');
    ctx.fillStyle = '#ddd8cf';
    ctx.beginPath();
    ctx.ellipse(d[0], d[1] - 16, 30, 26, 0, Math.PI, 0);
    ctx.fill();
    ctx.fillStyle = '#efebe4';
    ctx.beginPath();
    ctx.ellipse(d[0] - 8, d[1] - 26, 10, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    box(ctx, ox, oy, 0.4, H - 1.4, 1.6, H - 0.3, 12, '#b9b2a6');
  },

  hydro(ctx, ox, oy, W, H) {
    box(ctx, ox, oy, 0.15, 0.2, W - 0.15, H - 0.2, 16, '#bdb8ad');
    // 壓力水管與出水口（藍色條紋）
    ctx.fillStyle = '#4a8fd0';
    for (let k = 0; k < 3; k++) {
      const a = P(ox, oy, 0.4 + k * 0.5, H - 0.2, 2), b = P(ox, oy, 0.6 + k * 0.5, H - 0.2, 2);
      ctx.fillRect(Math.min(a[0], b[0]), a[1] - 10, Math.abs(b[0] - a[0]) || 6, 8);
    }
    box(ctx, ox, oy, 0.5, 0.4, W - 0.6, 1.0, 8, '#a59f93', 16);
  },

  wind(ctx, ox, oy, W, H, inst) {
    const spots = [[0.7, 0.8], [2.2, 0.6], [1.3, 2.2]];
    spots.sort((a, b) => a[0] + a[1] - (b[0] + b[1]));
    for (const [u, v] of spots) {
      const [x, y] = P(ox, oy, u, v);
      ctx.fillStyle = '#d9dde0';
      ctx.fillRect(x - 1.5, y - 66, 3, 66);
      ctx.fillStyle = '#f4f6f7';
      ctx.fillRect(x - 3, y - 70, 8, 5);
      const ang = hash2(inst?.id ?? 1, Math.round(u * 10), 3) * Math.PI * 2;
      ctx.strokeStyle = '#f4f6f7';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let k = 0; k < 3; k++) {
        const a = ang + (k * Math.PI * 2) / 3;
        ctx.moveTo(x, y - 68);
        ctx.lineTo(x + Math.cos(a) * 24, y - 68 + Math.sin(a) * 24);
      }
      ctx.stroke();
      ctx.fillStyle = '#9aa3aa';
      ctx.beginPath();
      ctx.arc(x, y - 68, 2, 0, Math.PI * 2);
      ctx.fill();
    }
    void W; void H;
  },

  // 太陽能板一律朝南（台灣在北半球，板子朝南、北邊墊高），旋轉視角時也一樣
  solar(ctx, ox, oy, W, H, inst, detail, south) {
    const alongU = south === '+v' || south === '-v'; // 南方在 v 軸方向：板子沿 u 排列
    const N = alongU ? H : W;
    const L = alongU ? W : H;
    const rows = Math.round(N * 1.6);
    const at = (a, b, z) => (alongU ? P(ox, oy, a, b, z) : P(ox, oy, b, a, z));
    const southPositive = south === '+v' || south === '+u';
    for (let k = 0; k < rows; k++) {
      const r = k; // 由後往前畫（座標小的在後面）
      const b0 = 0.15 + (r * (N - 0.3)) / rows;
      const b1 = b0 + ((N - 0.3) / rows) * 0.62;
      // 低邊在南側、高邊在北側
      const lowB = southPositive ? b1 : b0, highB = southPositive ? b0 : b1;
      const a1 = at(0.15, lowB, 2), a2 = at(L - 0.15, lowB, 2);
      const c2 = at(L - 0.15, highB, 8), c1 = at(0.15, highB, 8);
      poly(ctx, [a1, a2, c2, c1], '#284a7a');
      if (detail >= 1) {
        ctx.strokeStyle = 'rgba(160,190,230,0.45)';
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        for (let q = 1; q < L * 2; q++) {
          const t = 0.15 + ((L - 0.3) * q) / (L * 2);
          const p0 = at(t, lowB, 2), p1 = at(t, highB, 8);
          ctx.moveTo(p0[0], p0[1]);
          ctx.lineTo(p1[0], p1[1]);
        }
        ctx.stroke();
      }
    }
    void inst;
  },

  battery(ctx, ox, oy, W, H) {
    const cells = [[0.2, 0.2], [1.05, 0.2], [0.2, 1.05], [1.05, 1.05]];
    for (const [u, v] of cells) {
      box(ctx, ox, oy, u, v, u + 0.72, v + 0.62, 9, '#eef0ec');
      box(ctx, ox, oy, u, v + 0.62, u + 0.72, v + 0.66, 9, '#4caf6d');
    }
    void W; void H;
  },
};

// 公園：草地、步道、幾棵大樹（2×2 的有小水池）
function parkSprite(ctx, ox, oy, W, H) {
  poly(ctx, [P(ox, oy, 0.05, 0.05), P(ox, oy, W - 0.05, 0.05), P(ox, oy, W - 0.05, H - 0.05), P(ox, oy, 0.05, H - 0.05)], '#7cc46a');
  ctx.strokeStyle = '#e8dcb8';
  ctx.lineWidth = 2;
  ctx.beginPath();
  const a = P(ox, oy, 0.1, H / 2), b = P(ox, oy, W - 0.1, H / 2), c = P(ox, oy, W / 2, 0.1), d = P(ox, oy, W / 2, H - 0.1);
  ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.moveTo(c[0], c[1]); ctx.lineTo(d[0], d[1]);
  ctx.stroke();
  if (W > 1) {
    const p = P(ox, oy, W * 0.7, H * 0.3);
    ctx.fillStyle = '#5aa7dc';
    ctx.beginPath();
    ctx.ellipse(p[0], p[1], 14, 7, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  const trees = W > 1 ? [[0.35, 0.35], [0.4, 1.4], [1.5, 1.5], [1.4, 0.8]] : [[0.3, 0.3], [0.72, 0.72]];
  trees.sort((p1, p2) => p1[0] + p1[1] - (p2[0] + p2[1]));
  for (const [u, v] of trees) {
    const [x, y] = P(ox, oy, u, v);
    ctx.fillStyle = '#6b4a2b';
    ctx.fillRect(x - 1.2, y - 7, 2.4, 7);
    ctx.fillStyle = '#2f7a38';
    ctx.beginPath(); ctx.arc(x, y - 12, 8, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#4c9a4e';
    ctx.beginPath(); ctx.arc(x - 2.5, y - 14.5, 4, 0, Math.PI * 2); ctx.fill();
  }
}

function coolingTower(ctx, base, r, h) {
  const [x, y] = base;
  const waist = r * 0.62, top = r * 0.72;
  ctx.fillStyle = '#d2cec6';
  ctx.beginPath();
  ctx.moveTo(x - r, y);
  ctx.quadraticCurveTo(x - waist * 0.9, y - h * 0.65, x - top, y - h);
  ctx.lineTo(x + top, y - h);
  ctx.quadraticCurveTo(x + waist * 0.9, y - h * 0.65, x + r, y);
  ctx.ellipse(x, y, r, r * 0.45, 0, 0, Math.PI);
  ctx.fill();
  // 右半陰影
  ctx.fillStyle = 'rgba(80,80,80,0.18)';
  ctx.beginPath();
  ctx.moveTo(x + r * 0.15, y + r * 0.44);
  ctx.quadraticCurveTo(x + waist * 0.2, y - h * 0.6, x + top * 0.25, y - h);
  ctx.lineTo(x + top, y - h);
  ctx.quadraticCurveTo(x + waist * 0.9, y - h * 0.65, x + r, y);
  ctx.ellipse(x, y, r, r * 0.45, 0, 0, Math.PI / 2.2);
  ctx.fill();
  ctx.fillStyle = shade('#d2cec6', 0.7);
  ctx.beginPath();
  ctx.ellipse(x, y - h, top, top * 0.42, 0, 0, Math.PI * 2);
  ctx.fill();
  // 水蒸氣（白色，不是污染）
  ctx.fillStyle = 'rgba(255,255,255,0.75)';
  for (const [dx, dy, rr] of [[0, -10, 14], [-9, -20, 11], [8, -24, 12], [0, -32, 9]]) {
    ctx.beginPath();
    ctx.arc(x + dx, y - h + dy, rr, 0, Math.PI * 2);
    ctx.fill();
  }
}

function smoke(ctx, [x, y], color) {
  ctx.fillStyle = color;
  for (const [dx, dy, r] of [[0, -4, 6], [5, -11, 7], [11, -19, 8], [18, -26, 7]]) {
    ctx.beginPath();
    ctx.arc(x + dx, y + dy, r, 0, Math.PI * 2);
    ctx.fill();
  }
}
