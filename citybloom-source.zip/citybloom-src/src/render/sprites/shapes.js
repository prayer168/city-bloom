// 等角立體的基本形狀。座標 (u, v, z)：
//   u 沿視圖 vx 方向（畫面右下）、v 沿視圖 vy 方向（畫面左下），單位是格；z 是往上的像素。
//   (ox, oy) 是參考格（u = v = 0）在地面高度的上頂點。
// 看得到的兩個側面：v = v1 那面朝左前（較亮），u = u1 那面朝右前（較暗）。

import { shade } from '../palette.js';

export function P(ox, oy, u, v, z = 0) {
  return [ox + (u - v) * 32, oy + (u + v) * 16 - z];
}

export function poly(ctx, pts, fill) {
  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let k = 1; k < pts.length; k++) ctx.lineTo(pts[k][0], pts[k][1]);
  ctx.closePath();
  ctx.fill();
}

// 長方體；color 為基準色，自動算出三面的明暗。回傳頂面四點。
export function box(ctx, ox, oy, u0, v0, u1, v1, h, color, z0 = 0, opts = {}) {
  const top = opts.top ?? shade(color, 1.08);
  const left = opts.left ?? color;
  const right = opts.right ?? shade(color, 0.78);
  const a = P(ox, oy, u0, v1, z0), b = P(ox, oy, u1, v1, z0), c = P(ox, oy, u1, v0, z0);
  const a2 = P(ox, oy, u0, v1, z0 + h), b2 = P(ox, oy, u1, v1, z0 + h), c2 = P(ox, oy, u1, v0, z0 + h);
  const d2 = P(ox, oy, u0, v0, z0 + h);
  poly(ctx, [a, b, b2, a2], left);
  poly(ctx, [b, c, c2, b2], right);
  poly(ctx, [d2, c2, b2, a2], top);
  return [d2, c2, b2, a2];
}

// 斜屋頂（屋脊沿 u 方向）
export function gableRoof(ctx, ox, oy, u0, v0, u1, v1, z, rh, roofColor, wallColor) {
  const vm = (v0 + v1) / 2;
  const back = [P(ox, oy, u0, v0, z), P(ox, oy, u1, v0, z), P(ox, oy, u1, vm, z + rh), P(ox, oy, u0, vm, z + rh)];
  const front = [P(ox, oy, u0, vm, z + rh), P(ox, oy, u1, vm, z + rh), P(ox, oy, u1, v1, z), P(ox, oy, u0, v1, z)];
  const gable = [P(ox, oy, u1, v0, z), P(ox, oy, u1, v1, z), P(ox, oy, u1, vm, z + rh)];
  poly(ctx, back, shade(roofColor, 0.82));
  poly(ctx, gable, shade(wallColor, 0.78));
  poly(ctx, front, roofColor);
}

// 一排排窗戶（畫在 v = v1 的左前面與 u = u1 的右前面）
export function windows(ctx, ox, oy, u0, v0, u1, v1, z0, h, floorH, color, cols = 3) {
  ctx.fillStyle = color;
  const floors = Math.floor((h - 3) / floorH);
  for (let f = 0; f < floors; f++) {
    const z = z0 + 3 + f * floorH;
    for (let k = 0; k < cols; k++) {
      const t0 = (k + 0.25) / cols, t1 = (k + 0.7) / cols;
      // 左前面
      quad(ctx, P(ox, oy, u0 + (u1 - u0) * t0, v1, z), P(ox, oy, u0 + (u1 - u0) * t1, v1, z), floorH * 0.5);
      // 右前面
      quad(ctx, P(ox, oy, u1, v0 + (v1 - v0) * t0, z), P(ox, oy, u1, v0 + (v1 - v0) * t1, z), floorH * 0.5);
    }
  }
}
function quad(ctx, a, b, hgt) {
  ctx.beginPath();
  ctx.moveTo(a[0], a[1]);
  ctx.lineTo(b[0], b[1]);
  ctx.lineTo(b[0], b[1] - hgt);
  ctx.lineTo(a[0], a[1] - hgt);
  ctx.closePath();
  ctx.fill();
}

// 圓柱（煙囪、儲槽）：中心 (u, v)，半徑 r（格），高 h
export function cylinder(ctx, ox, oy, u, v, r, h, color, z0 = 0) {
  const [cx, cy] = P(ox, oy, u, v, z0);
  const rx = r * 45, ry = r * 22.5;
  ctx.fillStyle = shade(color, 0.85);
  ctx.beginPath();
  ctx.moveTo(cx - rx, cy);
  ctx.lineTo(cx - rx, cy - h);
  ctx.ellipse(cx, cy - h, rx, ry, 0, Math.PI, 0, false);
  ctx.lineTo(cx + rx, cy);
  ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI, false);
  ctx.closePath();
  ctx.fill();
  // 左半邊比較亮
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(cx - rx, cy);
  ctx.lineTo(cx - rx, cy - h);
  ctx.lineTo(cx, cy - h + ry);
  ctx.lineTo(cx, cy + ry);
  ctx.ellipse(cx, cy, rx, ry, 0, Math.PI / 2, Math.PI, false);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = shade(color, 1.12);
  ctx.beginPath();
  ctx.ellipse(cx, cy - h, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
}

// 閃電標誌（沒電、停電）
export function bolt(ctx, x, y, s, fill) {
  ctx.fillStyle = '#1b1b1b';
  ctx.beginPath();
  ctx.arc(x, y, 7.5 * s, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.moveTo(x + 1.5 * s, y - 6 * s);
  ctx.lineTo(x - 3.5 * s, y + 1 * s);
  ctx.lineTo(x - 0.2 * s, y + 1 * s);
  ctx.lineTo(x - 1.5 * s, y + 6 * s);
  ctx.lineTo(x + 3.5 * s, y - 1 * s);
  ctx.lineTo(x + 0.2 * s, y - 1 * s);
  ctx.closePath();
  ctx.fill();
}
