// 分區上自動長出的建築（每格一棟，等級越高越大越高）
// 造型原創：住宅有斜屋頂的透天厝與屋頂水塔的公寓；商業是店面與玻璃辦公大樓；工業是鋸齒屋頂廠房與煙囪。

import { hash2 } from '../../core/rng.js';
import { shade } from '../palette.js';
import { box, gableRoof, windows, cylinder } from './shapes.js';

const HOUSE_WALLS = ['#efe6d2', '#e7dcc8', '#f3efe6', '#e9d9c0'];
const HOUSE_ROOFS = ['#b8574a', '#8f5a45', '#5e6f86', '#a8673f'];
const APT_WALLS = ['#d9cdb8', '#cfc6b6', '#e2d3bd', '#c9c0b2'];
const SHOP_WALLS = ['#f0e2cf', '#e8d6c9', '#efe9dd'];
const AWNINGS = ['#d9534f', '#2f8f83', '#e0a83a', '#4b74b8'];
const OFFICE_GLASS = ['#7fa8c2', '#86b4b9', '#9aaecb', '#6f9bb3'];
const FACTORY = ['#b9b4a8', '#a9aab0', '#c2b8a4'];

// zoneKind: 'r' | 'c' | 'i'；dense: 是否高密度；level 1–4
// (ox, oy) = 這一格的上頂點；hx, hy = 格子世界座標（用來決定外觀變化）
export function drawZoneBuilding(ctx, ox, oy, zoneKind, dense, level, hx, hy, detail) {
  const h = hash2(hx, hy, 91);
  const pick = (arr) => arr[Math.floor(h * arr.length) % arr.length];
  if (zoneKind === 'r') {
    if (!dense) return house(ctx, ox, oy, level, pick(HOUSE_WALLS), pick(HOUSE_ROOFS), h);
    return apartment(ctx, ox, oy, level, pick(APT_WALLS), detail, h);
  }
  if (zoneKind === 'c') {
    if (!dense || level <= 1 && h < 0.4) return shop(ctx, ox, oy, dense ? level + 1 : level, pick(SHOP_WALLS), pick(AWNINGS), detail);
    return office(ctx, ox, oy, level, pick(OFFICE_GLASS), detail, h);
  }
  return factory(ctx, ox, oy, dense, level, pick(FACTORY), detail, h);
}

// 建築頂端的大約高度（給停電標誌放位置）
export function buildingHeight(zoneKind, dense, level) {
  if (zoneKind === 'r') return dense ? [0, 18, 28, 42, 60][level] : [0, 14, 18][level];
  if (zoneKind === 'c') return dense ? [0, 20, 34, 52, 76][level] : [0, 12, 18][level];
  return dense ? [0, 30, 36, 44, 52][level] : [0, 10, 22][level];
}

function house(ctx, ox, oy, level, wall, roof, h) {
  if (level <= 1) {
    box(ctx, ox, oy, 0.25, 0.28, 0.75, 0.72, 8, wall);
    gableRoof(ctx, ox, oy, 0.22, 0.25, 0.78, 0.75, 8, 6, roof, wall);
    return;
  }
  // 兩層透天厝 + 旁邊一間小屋
  box(ctx, ox, oy, 0.14, 0.2, 0.62, 0.66, 12, wall);
  gableRoof(ctx, ox, oy, 0.11, 0.17, 0.65, 0.69, 12, 6, roof, wall);
  const w2 = h > 0.5 ? '#e4e9ee' : shade(wall, 0.96);
  box(ctx, ox, oy, 0.6, 0.55, 0.88, 0.86, 7, w2);
  gableRoof(ctx, ox, oy, 0.58, 0.53, 0.9, 0.88, 7, 4, shade(roof, 1.08), w2);
}

function apartment(ctx, ox, oy, level, wall, detail, h) {
  const H = [0, 18, 28, 42, 60][level];
  const inset = level >= 3 ? 0.12 : 0.16;
  box(ctx, ox, oy, inset, inset, 1 - inset, 1 - inset, H, wall);
  if (detail >= 2) windows(ctx, ox, oy, inset, inset, 1 - inset, 1 - inset, 0, H, 7, 'rgba(55,70,90,0.55)', 3);
  // 屋頂水塔（台灣公寓常見）
  cylinder(ctx, ox, oy, 0.62 - inset * 0.2, 0.42, 0.07, 6, '#d8dde2', H);
  if (h > 0.6 && level >= 2) box(ctx, ox, oy, 0.25, 0.25, 0.42, 0.42, 4, shade(wall, 0.9), H);
}

function shop(ctx, ox, oy, level, wall, awning, detail) {
  const H = level <= 1 ? 10 : 16;
  box(ctx, ox, oy, 0.15, 0.18, 0.85, 0.82, H, wall);
  // 騎樓上方的遮雨棚（左前面）
  box(ctx, ox, oy, 0.12, 0.8, 0.88, 0.9, 2, awning, 5);
  if (detail >= 2 && level > 1) windows(ctx, ox, oy, 0.15, 0.18, 0.85, 0.82, 7, H - 7, 6, 'rgba(60,80,100,0.5)', 3);
}

function office(ctx, ox, oy, level, glass, detail, h) {
  const H = [0, 20, 34, 52, 76][level];
  const inset = 0.14;
  box(ctx, ox, oy, inset, inset, 1 - inset, 1 - inset, H, glass, 0, { top: shade(glass, 1.15) });
  if (detail >= 2) {
    // 每層樓之間的橫帶
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 1;
    for (let z = 6; z < H - 2; z += 6) {
      const pts = [[inset, 1 - inset], [1 - inset, 1 - inset], [1 - inset, inset]].map(([u, v]) => [ox + (u - v) * 32, oy + (u + v) * 16 - z]);
      ctx.beginPath();
      ctx.moveTo(pts[0][0], pts[0][1]);
      ctx.lineTo(pts[1][0], pts[1][1]);
      ctx.lineTo(pts[2][0], pts[2][1]);
      ctx.stroke();
    }
  }
  if (level >= 3) box(ctx, ox, oy, 0.35, 0.35, 0.62, 0.62, 6, '#c9ced4', H);
  if (level === 4 && h > 0.5) cylinder(ctx, ox, oy, 0.5, 0.5, 0.02, 14, '#e8e8e8', H + 6);
}

function factory(ctx, ox, oy, dense, level, color, detail, h) {
  if (!dense) {
    box(ctx, ox, oy, 0.12, 0.15, 0.88, 0.85, level <= 1 ? 8 : 10, color);
    sawtooth(ctx, ox, oy, 0.12, 0.15, 0.88, 0.85, level <= 1 ? 8 : 10, color);
    if (level >= 2) cylinder(ctx, ox, oy, 0.25, 0.3, 0.06, 22, '#9b8f84');
    return;
  }
  const H = [0, 14, 18, 22, 26][level];
  box(ctx, ox, oy, 0.1, 0.2, 0.9, 0.9, H, color);
  sawtooth(ctx, ox, oy, 0.1, 0.2, 0.9, 0.9, H, color);
  cylinder(ctx, ox, oy, 0.22, 0.2, 0.07, 30 + level * 6, '#8f8579');
  if (level >= 2) cylinder(ctx, ox, oy, 0.42, 0.14, 0.06, 26 + level * 5, '#a0968a');
  if (level >= 3) cylinder(ctx, ox, oy, 0.8, 0.4, 0.13, 12, '#cfd3d6', H * 0.2);
  void detail; void h;
}

// 鋸齒狀廠房屋頂
function sawtooth(ctx, ox, oy, u0, v0, u1, v1, z, color) {
  const n = 3;
  for (let k = 0; k < n; k++) {
    const a = u0 + ((u1 - u0) * k) / n, b = u0 + ((u1 - u0) * (k + 1)) / n;
    const pts = [[a, v0, z], [b, v0, z + 5], [b, v1, z + 5], [a, v1, z]].map(([u, v, zz]) => [ox + (u - v) * 32, oy + (u + v) * 16 - zz]);
    ctx.fillStyle = shade(color, 1.12);
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let q = 1; q < 4; q++) ctx.lineTo(pts[q][0], pts[q][1]);
    ctx.closePath();
    ctx.fill();
    // 朝右前的垂直玻璃面
    const g = [[b, v0, z], [b, v1, z], [b, v1, z + 5], [b, v0, z + 5]].map(([u, v, zz]) => [ox + (u - v) * 32, oy + (u + v) * 16 - zz]);
    ctx.fillStyle = 'rgba(70,100,130,0.75)';
    ctx.beginPath();
    ctx.moveTo(g[0][0], g[0][1]);
    for (let q = 1; q < 4; q++) ctx.lineTo(g[q][0], g[q][1]);
    ctx.closePath();
    ctx.fill();
  }
}
