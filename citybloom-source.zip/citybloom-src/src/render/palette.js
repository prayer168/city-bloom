// 原創配色：呼應 90 年代點陣遊戲的飽和色塊，但所有顏色與造型都是自行設計。
// 光源在左上方：頂面最亮、左前牆次之、右前牆最暗。

function hexToRgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function rgbToHex([r, g, b]) {
  const c = (v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
  return `#${c(r)}${c(g)}${c(b)}`;
}
export function shade(hex, f) {
  const [r, g, b] = hexToRgb(hex);
  return f >= 1
    ? rgbToHex([r + (255 - r) * (f - 1), g + (255 - g) * (f - 1), b + (255 - b) * (f - 1)])
    : rgbToHex([r * f, g * f, b * f]);
}
export function mix(a, b, t) {
  const A = hexToRgb(a), B = hexToRgb(b);
  return rgbToHex([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]);
}

// 每種顏色預先做 4 個細微明暗變化，讓地面有點陣質感
const VARIANTS = [0.96, 1.0, 1.03, 0.985];
function variants(hex) { return VARIANTS.map((f) => shade(hex, f)); }

export const BASE = {
  grassLow: '#6aa84f',
  grassHigh: '#8fae5a',
  forestFloor: '#4f8a3e',
  sand: '#e3cf8e',
  mudflat: '#9a8e6c',
  waterShallow: '#4a98d4',
  waterDeep: '#1f4f8c',
  foam: '#cfe9f7',
  soil: '#a7744a',
  rock: '#948c80',
  canopy: '#2f7034',
  canopyLight: '#46914a',
  conifer: '#2a5e3a',
  trunk: '#6b4a2b',
  void: '#1b2130',
  voidLow: '#232b3d',
};

// 依層數漸變的草地顏色（高處偏黃、偏淡）
export const GRASS_BY_LEVEL = Array.from({ length: 16 }, (_, lv) =>
  variants(mix(BASE.grassLow, BASE.grassHigh, Math.min(1, Math.max(0, (lv - 1) / 12)))));
export const FOREST_BY_LEVEL = Array.from({ length: 16 }, (_, lv) =>
  variants(mix(BASE.forestFloor, '#6c8e4a', Math.min(1, Math.max(0, (lv - 1) / 14)))));
export const SAND = variants(BASE.sand);
export const MUDFLAT = variants(BASE.mudflat);

// 水深 0–15 m 的顏色
export const WATER_BY_DEPTH = Array.from({ length: 16 }, (_, d) =>
  variants(mix(BASE.waterShallow, BASE.waterDeep, Math.min(1, d / 10))));

// 牆面：低處是泥土，高處逐漸變成岩石
export function wallColors(level) {
  const t = Math.min(1, Math.max(0, (level - 4) / 8));
  const base = mix(BASE.soil, BASE.rock, t);
  return { left: shade(base, 0.92), right: shade(base, 0.72), line: shade(base, 0.6) };
}
export const WALL_BY_LEVEL = Array.from({ length: 16 }, (_, lv) => wallColors(lv));
export const WATER_WALL = { left: shade(BASE.waterShallow, 0.82), right: shade(BASE.waterShallow, 0.66), line: shade(BASE.waterShallow, 0.55) };
export const BASE_WALL = { left: shade('#6e5440', 0.95), right: shade('#6e5440', 0.75), line: shade('#6e5440', 0.6) };
