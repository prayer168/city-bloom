// 資料圖層：把每格的數值換成顏色，疊在地面上
// 每個圖層都附圖例與一句說明，給學生判讀用

import { NET, UTIL, SURFACE } from '../core/constants.js';
import { AQI_LEVELS } from '../data/environment.js';
import { TRAFFIC } from '../data/transport.js';

function hexToRgb(h) { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function ramp(stops) {
  const cs = stops.map(([t, c]) => [t, hexToRgb(c)]);
  return (t, a) => {
    t = Math.max(0, Math.min(1, t));
    let k = 0;
    while (k < cs.length - 2 && t > cs[k + 1][0]) k++;
    const [t0, c0] = cs[k], [t1, c1] = cs[k + 1];
    const f = t1 > t0 ? (t - t0) / (t1 - t0) : 0;
    return `rgba(${Math.round(c0[0] + (c1[0] - c0[0]) * f)},${Math.round(c0[1] + (c1[1] - c0[1]) * f)},${Math.round(c0[2] + (c1[2] - c0[2]) * f)},${a})`;
  };
}

const densityRamp = ramp([[0, '#d9f2ef'], [0.35, '#4fc3b7'], [1, '#1f4f9c']]);
const valueRamp = ramp([[0, '#6b3fa0'], [0.4, '#3f8fd2'], [0.7, '#7fd17f'], [1, '#f5d23f']]);
const crimeRamp = ramp([[0, '#fff1c9'], [0.4, '#f5a03a'], [1, '#9c1f1f']]);
const carbonRamp = ramp([[0, '#f6e7c8'], [0.45, '#e8913a'], [1, '#8f1d1d']]);
const heatRamp = ramp([[0, '#2c7bb6'], [0.35, '#abd9e9'], [0.55, '#ffffbf'], [0.75, '#fdae61'], [1, '#d7191c']]);
const floodRamp = ramp([[0, '#cfe8ff'], [0.25, '#6fb1f0'], [0.6, '#2f6fd0'], [1, '#14307a']]);
const trafficRamp = ramp([[0, '#3ccf6e'], [0.5, '#f2d33c'], [0.75, '#f28b30'], [1, '#c4231b']]);

export const OVERLAYS = {
  power: {
    name: '電力', legend: [['#3cd278', '有電'], ['#ffa028', '輪流停電'], ['#eb463c', '沒接上電廠']],
    note: '電線、分區、電廠會傳電，道路不會。',
  },
  density: {
    name: '人口與工作密度', gradient: ['#d9f2ef', '#4fc3b7', '#1f4f9c'], low: '少', high: '多',
    note: '住宅看居民，商業與工業看工作數。',
  },
  landValue: {
    name: '地價', gradient: ['#6b3fa0', '#3f8fd2', '#7fd17f', '#f5d23f'], low: '便宜', high: '昂貴',
    note: '靠水邊、綠地、市中心比較貴；污染、犯罪、塞車會讓地價下降。高樓只會蓋在地價高的地方。',
  },
  pollution: {
    name: '空氣污染', legend: AQI_LEVELS.map((l) => [l.color, l.name]),
    note: '工廠、燃煤與燃氣電廠、塞車的道路會產生污染，會往下風處飄。冬天吹東北季風、夏天吹西南季風。',
  },
  heat: {
    name: '地表溫度', gradient: ['#2c7bb6', '#abd9e9', '#ffffbf', '#fdae61', '#d7191c'], low: '比氣溫涼', high: '比氣溫熱 10 °C',
    note: '午後地面摸起來有多熱。道路、密集的建築、冷氣與車輛的廢熱會讓地面變熱；樹林、水、公園、行道樹、綠屋頂、冷屋頂會降溫。',
  },
  flood: {
    name: '淹水潛勢', gradient: ['#cfe8ff', '#6fb1f0', '#2f6fd0', '#14307a'], low: '10 公分', high: '1 公尺以上',
    note: '如果一天下 350 毫米的大雨（約颱風等級），哪裡會淹、淹多深。低窪的地方、水泥地多的地方最容易淹；滯洪池、透水鋪面、雨水花園、抽水站、堤防都能讓藍色變少。斜線是漲潮會淹的海岸。',
  },
  carbon: {
    name: '碳排放熱點', gradient: ['#199e70', '#f6e7c8', '#e8913a', '#8f1d1d'], low: '吸收', high: '排放多',
    note: '每格每月排放多少二氧化碳。電廠、工業區最多，塞車的道路次之；綠色是樹林吸收的地方。（對數刻度）',
  },
  crime: {
    name: '治安', gradient: ['#fff1c9', '#f5a03a', '#9c1f1f'], low: '安全', high: '需要關注',
    note: '人口越密集、地價越低的地方越需要關注治安。（警察局在之後的階段加入）',
  },
  traffic: {
    name: '交通', legend: [['#3ccf6e', '順暢'], ['#f2d33c', '車多'], ['#f28b30', '擁擠'], ['#c4231b', '塞車']],
    note: `每格道路約可順暢通過 ${TRAFFIC.roadCapacity} 輛通勤車。公車站與自行車道可以減少車流。`,
  },
};

// 回傳這一格要疊的顏色（或 null）
export function overlayColor(mode, L, i, view = {}) {
  switch (mode) {
    case 'power': {
      const conductive = (L.net[i] & NET.POWERLINE) || L.zone[i] || L.bld[i];
      if (!conductive) return null;
      const u = L.util[i];
      return !(u & UTIL.POWERED) ? 'rgba(235,70,60,0.55)' : (u & UTIL.BLACKOUT) ? 'rgba(255,160,40,0.6)' : 'rgba(60,210,120,0.5)';
    }
    case 'density': {
      const v = L.pop[i] + L.jobs[i];
      if (!v) return L.zone[i] ? 'rgba(217,242,239,0.25)' : null;
      return densityRamp(v / 450, 0.65);
    }
    case 'landValue':
      if (L.surface[i] === SURFACE.WATER) return null;
      return valueRamp((L.landValue[i] - 30) / 130, 0.6);
    case 'pollution': {
      const v = L.pollution[i];
      if (v < 6) return null;
      const k = AQI_LEVELS.findIndex((l) => v < l.max);
      const lvl = AQI_LEVELS[k < 0 ? 3 : k];
      // 「良好」只淡淡標示，讓有問題的地方比較明顯
      return hexA(lvl.color, k === 0 ? 0.12 + v / 250 : Math.min(0.8, 0.35 + v / 250));
    }
    case 'heat': {
      const air = view.air ?? 25;
      return heatRamp((L.surfTemp[i] - air + 3) / 13, 0.6);
    }
    case 'carbon': {
      const v = L.carbon[i];
      if (v < -0.1) return 'rgba(25,158,112,0.5)';
      if (v < 0.3) return null;
      return carbonRamp(Math.log10(1 + v) / Math.log10(201), 0.7);
    }
    case 'crime': {
      const v = L.crime[i];
      if (v < 8) return null;
      return crimeRamp(v / 120, Math.min(0.75, 0.3 + v / 200));
    }
    case 'flood': {
      if (L.surface[i] === SURFACE.WATER) return null;
      if (L.state[i] & 16) return 'rgba(20,48,122,0.85)';
      if (L.state[i] & 8) return 'rgba(111,177,240,0.7)';
      const d = L.floodRisk[i];
      if (d < 10) return null;
      return floodRamp(Math.min(1, d / 100), 0.75);
    }
    case 'traffic':
      if (!(L.net[i] & NET.ROAD)) return null;
      return trafficRamp(L.traffic[i] / 192, 0.85);
    default:
      return null;
  }
}

function hexA(hex, a) {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}
