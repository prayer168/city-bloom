// 等角投影數學（純函式，不碰 DOM，可測試）
//
// 座標系：
//   世界格座標 (x, y)：資料存放位置，不隨旋轉改變
//   視圖格座標 (vx, vy)：依目前旋轉方向換算後的位置，決定畫面上的前後
//   世界畫面座標 (sx, sy)：未縮放像素，視圖格 (0,0) 地面頂點在 (0,0)
//
// 一格菱形的四個頂點（高度 h 層）：
//   上 (sx, sy)   右 (sx+32, sy+16)   下 (sx, sy+32)   左 (sx-32, sy+16)
// 右下邊緊鄰 (vx+1, vy)，左下邊緊鄰 (vx, vy+1)，所以 vx+vy 越大越靠前。

import { TILE_W, TILE_H, LEVEL_PX, BASE_LEVELS, MAX_LEVEL } from '../core/constants.js';

const HW = TILE_W / 2;
const HH = TILE_H / 2;

// 旋轉 rot = 0..3（每次順時針 90°）
export function worldToView(x, y, rot, size) {
  const m = size - 1;
  switch (rot & 3) {
    case 0: return [x, y];
    case 1: return [m - y, x];
    case 2: return [m - x, m - y];
    default: return [y, m - x];
  }
}

export function viewToWorld(vx, vy, rot, size) {
  const m = size - 1;
  switch (rot & 3) {
    case 0: return [vx, vy];
    case 1: return [vy, m - vx];
    case 2: return [m - vx, m - vy];
    default: return [m - vy, vx];
  }
}

// 視圖格在高度 level 時，菱形上頂點的世界畫面座標
export function tileTop(vx, vy, level) {
  return [(vx - vy) * HW, (vx + vy) * HH - level * LEVEL_PX];
}

// 世界畫面座標 → 地面（第 0 層）上的視圖格（小數）
export function screenToGround(px, py) {
  const s = py / HH;
  const u = px / HW;
  return [(s + u) / 2, (s - u) / 2];
}

// 整張地圖在世界畫面座標的範圍（含最高地形與地基）
export function mapBounds(size) {
  return {
    x0: -size * HW,
    x1: size * HW,
    y0: -MAX_LEVEL * LEVEL_PX - 32,
    y1: (2 * size) * HH + (BASE_LEVELS + 1) * LEVEL_PX,
  };
}

// 一格的輪廓（頂面 + 前方兩面牆）多邊形，用於拾取與外框
// dropR / dropL：右前、左前牆往下的像素數
export function tileSilhouette(vx, vy, level, dropR, dropL) {
  const [sx, sy] = tileTop(vx, vy, level);
  return [
    sx, sy,
    sx + HW, sy + HH,
    sx + HW, sy + HH + dropR,
    sx, sy + TILE_H + dropR,
    sx, sy + TILE_H + dropL,
    sx - HW, sy + HH + dropL,
    sx - HW, sy + HH,
  ];
}

export function pointInPolygon(px, py, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 2; i < poly.length; j = i, i += 2) {
    const xi = poly[i], yi = poly[i + 1];
    const xj = poly[j], yj = poly[j + 1];
    if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

// 牆的高度：本格層數 − 前方鄰格層數（邊緣則降到地基）
export function wallDrops(levelAt, vx, vy, size) {
  const h = levelAt(vx, vy);
  const hr = vx + 1 < size ? levelAt(vx + 1, vy) : -BASE_LEVELS;
  const hl = vy + 1 < size ? levelAt(vx, vy + 1) : -BASE_LEVELS;
  return [Math.max(0, h - hr) * LEVEL_PX, Math.max(0, h - hl) * LEVEL_PX];
}

// 由世界畫面座標找出被點到的格子（考慮地形高度與牆面）
// levelAt(vx, vy) 回傳視圖格的層數。回傳視圖格 [vx, vy] 或 null。
export function pickViewTile(px, py, size, levelAt) {
  const [gx, gy] = screenToGround(px, py);
  const bx = Math.floor(gx), by = Math.floor(gy);
  // 被抬高的格子會出現在畫面較上方，所以要往「前方」找候選
  const reach = Math.ceil((MAX_LEVEL * LEVEL_PX) / TILE_H) + 2;
  const cands = [];
  for (let k = -2; k <= reach; k++) {
    cands.push([bx + k, by + k], [bx + k + 1, by + k], [bx + k, by + k + 1]);
  }
  cands.sort((a, b) => b[0] + b[1] - (a[0] + a[1]));
  for (const [vx, vy] of cands) {
    if (vx < 0 || vy < 0 || vx >= size || vy >= size) continue;
    const lv = levelAt(vx, vy);
    const [dR, dL] = wallDrops(levelAt, vx, vy, size);
    if (pointInPolygon(px, py, tileSilhouette(vx, vy, lv, dR, dL))) return [vx, vy];
  }
  return null;
}

export const ISO = Object.freeze({ HW, HH });
