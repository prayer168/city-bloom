// 渲染器
// 採「畫面分塊快取」：把世界畫面切成 256×256（CSS px）的方塊，每塊畫一次後存成離屏畫布。
// 平移時只是把現成的方塊貼上去，所以很快；地形改變時只重畫受影響的方塊。
// 記憶體以「像素預算」管理，超過就丟掉最久沒用的方塊（LRU），適合學校平板。

import { TILE_W, TILE_H, LEVEL_PX, BASE_LEVELS, MAX_LEVEL } from '../core/constants.js';
import { elevToLevel } from '../sim/world.js';
import { worldToView, viewToWorld, tileTop, pickViewTile, mapBounds } from './iso.js';
import { drawTile, TILE_EXTENT } from './tiledraw.js';
import { BASE } from './palette.js';

const HW = TILE_W / 2;
const HH = TILE_H / 2;
const CACHE_CSS = 256;

export class Renderer {
  constructor(canvas, world, camera) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.camera = camera;
    this.grid = true;
    this.overlay = 'none'; // 'none' | 'power'
    this.hover = null;     // { tiles: [世界索引...], ok: bool, color? }
    this.plantView = new Map();
    this.instancesVersionSeen = -1;
    this.dpr = 1;
    this.cache = new Map(); // key → canvas（Map 的插入順序當作 LRU 順序）
    this.cacheKey = '';
    this.needsDraw = true;
    this.stats = { lastFrameMs: 0, cacheTiles: 0, rendered: 0 };
    this.setWorld(world);
  }

  setWorld(world) {
    this.world = world;
    this.size = world.size;
    this.vlev = new Uint8Array(this.size * this.size);
    this.v2w = new Int32Array(this.size * this.size);
    this.rebuildView();
  }

  // 依目前旋轉方向建立「視圖格 → 世界索引」與「視圖格層數」表
  rebuildView() {
    const { size, world } = this;
    const rot = this.camera.rot;
    const { elev, surface } = world.layers;
    for (let vy = 0; vy < size; vy++) {
      for (let vx = 0; vx < size; vx++) {
        const [x, y] = viewToWorld(vx, vy, rot, size);
        const wi = y * size + x;
        const vi = vy * size + vx;
        this.v2w[vi] = wi;
        this.vlev[vi] = elevToLevel(elev[wi], surface[wi]);
      }
    }
    this.viewRot = rot;
    this.rebuildPlants();
    this.clearCache();
  }

  // 每座電廠在目前視角下的占地範圍；在最前面那一格畫整座電廠
  rebuildPlants() {
    const { size, world } = this;
    const rot = this.camera.rot;
    this.plantView = new Map();
    for (const inst of world.instances.values()) {
      const corners = [[inst.x, inst.y], [inst.x + inst.w - 1, inst.y], [inst.x, inst.y + inst.h - 1], [inst.x + inst.w - 1, inst.y + inst.h - 1]]
        .map(([x, y]) => worldToView(x, y, rot, size));
      const vxs = corners.map((c) => c[0]), vys = corners.map((c) => c[1]);
      const vx0 = Math.min(...vxs), vy0 = Math.min(...vys), vx1 = Math.max(...vxs), vy1 = Math.max(...vys);
      this.plantView.set(inst.id, { def: inst.def, inst, vx0, vy0, W: vx1 - vx0 + 1, H: vy1 - vy0 + 1, fx: vx1, fy: vy1 });
    }
    this.instancesVersionSeen = world.instancesVersion;
  }

  clearCache() {
    this.cache.clear();
    this.needsDraw = true;
  }

  // 格子改變：更新層數表，並作廢受影響的快取方塊（逐格計算，零散的變化不會作廢整張圖）
  tilesChanged(worldIndices) {
    const { size, world } = this;
    const rot = this.camera.rot;
    const { elev, surface } = world.layers;
    if (world.instancesVersion !== this.instancesVersionSeen) this.rebuildPlants();
    const W = CACHE_CSS / this.camera.zoom;
    const keys = new Set();
    for (const wi of worldIndices) {
      const [vx, vy] = worldToView(wi % size, (wi / size) | 0, rot, size);
      this.vlev[vy * size + vx] = elevToLevel(elev[wi], surface[wi]);
      // 牆面與電線取決於鄰格，所以範圍放寬；建築會往上延伸
      const [sx, sy] = tileTop(vx, vy, 0);
      const x0 = sx - TILE_EXTENT.side - HW, x1 = sx + TILE_EXTENT.side + HW;
      const y0 = sy - HH * 2 - MAX_LEVEL * LEVEL_PX - TILE_EXTENT.up, y1 = sy + HH * 2 + TILE_EXTENT.down;
      for (let cy = Math.floor(y0 / W); cy <= Math.floor(y1 / W); cy++) {
        for (let cx = Math.floor(x0 / W); cx <= Math.floor(x1 / W); cx++) keys.add(cx + ',' + cy);
      }
    }
    for (const k of keys) this.cache.delete(k);
    if (keys.size) this.needsDraw = true;
  }

  invalidateRect(x0, y0, x1, y1) {
    const W = CACHE_CSS / this.camera.zoom;
    const cx0 = Math.floor(x0 / W), cx1 = Math.floor(x1 / W);
    const cy0 = Math.floor(y0 / W), cy1 = Math.floor(y1 / W);
    for (let cy = cy0; cy <= cy1; cy++) {
      for (let cx = cx0; cx <= cx1; cx++) this.cache.delete(cx + ',' + cy);
    }
    this.needsDraw = true;
  }

  resize(cssW, cssH, dpr) {
    this.dpr = Math.min(this.maxDpr ?? 2, dpr || 1);
    this.canvas.width = Math.round(cssW * this.dpr);
    this.canvas.height = Math.round(cssH * this.dpr);
    this.canvas.style.width = cssW + 'px';
    this.canvas.style.height = cssH + 'px';
    this.camera.setViewport(cssW, cssH);
    this.clearCache();
  }

  levelAtView = (vx, vy) => this.vlev[vy * this.size + vx];

  // 由 CSS 座標找出世界格座標
  pick(cssX, cssY) {
    const [wx, wy] = this.camera.toWorld(cssX, cssY);
    const hit = pickViewTile(wx, wy, this.size, this.levelAtView);
    if (!hit) return null;
    const [x, y] = viewToWorld(hit[0], hit[1], this.camera.rot, this.size);
    return { x, y, i: y * this.size + x };
  }

  // 畫一個快取方塊：找出所有可能碰到這個矩形的格子，依前後順序畫
  renderCacheTile(cx, cy) {
    const z = this.camera.zoom;
    const W = CACHE_CSS / z;
    const px = Math.round(CACHE_CSS * this.dpr);
    const scale = px / W; // 與主畫面貼圖用同一個比例，避免接縫
    const canvas = document.createElement('canvas');
    canvas.width = px;
    canvas.height = px;
    const ctx = canvas.getContext('2d');
    const x0 = cx * W, y0 = cy * W, x1 = x0 + W, y1 = y0 + W;
    ctx.setTransform(scale, 0, 0, scale, -x0 * scale, -y0 * scale);
    ctx.imageSmoothingEnabled = false;
    ctx.lineJoin = 'round';

    const view = {
      size: this.size, vlev: this.vlev, v2w: this.v2w, world: this.world,
      grid: this.grid && z >= 1, detail: z >= 1 ? 2 : z >= 0.5 ? 1 : 0,
      overlay: this.overlay, plantView: this.plantView,
      south: ['+v', '-u', '-v', '+u'][this.camera.rot & 3],
      air: this.world.city.climate?.temp,
    };
    const n = this.size;
    // u = vx - vy 決定水平位置，s = vx + vy 決定前後
    const uMin = Math.ceil((x0 - TILE_EXTENT.side) / HW), uMax = Math.floor((x1 + TILE_EXTENT.side) / HW);
    const sMin = Math.floor((y0 - TILE_EXTENT.down) / HH);
    const sMax = Math.ceil((y1 + MAX_LEVEL * LEVEL_PX + TILE_EXTENT.up) / HH);
    let count = 0;
    for (let s = Math.max(0, sMin); s <= Math.min(2 * n - 2, sMax); s++) {
      let u0 = Math.max(uMin, -s, s - 2 * (n - 1));
      const u1 = Math.min(uMax, s, 2 * (n - 1) - s);
      if (((u0 + s) & 1) !== 0) u0++;
      for (let u = u0; u <= u1; u += 2) {
        const vx = (s + u) >> 1, vy = (s - u) >> 1;
        // 精確剔除：這格實際的上下範圍
        const lv = this.vlev[vy * n + vx];
        const top = s * HH - lv * LEVEL_PX - TILE_EXTENT.up;
        const bottom = s * HH + TILE_H + (lv + BASE_LEVELS) * LEVEL_PX;
        if (bottom < y0 || top > y1) continue;
        drawTile(ctx, view, vx, vy);
        count++;
      }
    }
    this.stats.rendered += count;
    return canvas;
  }

  getCacheTile(cx, cy) {
    const key = cx + ',' + cy;
    let c = this.cache.get(key);
    if (c) {
      this.cache.delete(key);
      this.cache.set(key, c); // 移到最新
      return c;
    }
    return null;
  }

  draw(now = performance.now()) {
    const t0 = performance.now();
    const cam = this.camera;
    if (this.viewRot !== cam.rot) this.rebuildView();
    if (this.world.instancesVersion !== this.instancesVersionSeen) this.rebuildPlants();
    const key = cam.zoomIndex + '|' + this.dpr + '|' + this.grid + '|' + this.overlay;
    if (key !== this.cacheKey) { this.cache.clear(); this.cacheKey = key; }

    const ctx = this.ctx;
    const dpr = this.dpr;
    const z = cam.zoom;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    // 背景（純色，比漸層便宜）
    ctx.fillStyle = BASE.void;
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // 可見的快取方塊
    const W = CACHE_CSS / z;
    const T = Math.round(CACHE_CSS * dpr);
    const [wx0, wy0] = cam.toWorld(0, 0);
    const [wx1, wy1] = cam.toWorld(cam.vw, cam.vh);
    const b = mapBounds(this.size);
    const cx0 = Math.floor(Math.max(wx0, b.x0) / W), cx1 = Math.floor(Math.min(wx1, b.x1) / W);
    const cy0 = Math.floor(Math.max(wy0, b.y0) / W), cy1 = Math.floor(Math.min(wy1, b.y1) / W);
    // 方塊對齊整數裝置像素，避免接縫
    const S = T / W; // 世界單位 → 裝置像素
    const offX = Math.round(-cam.x * S + (cam.vw / 2) * dpr);
    const offY = Math.round(-cam.y * S + (cam.vh / 2) * dpr);

    let pending = false;
    const budgetEnd = t0 + 14; // 一幀最多花 14 ms 畫新方塊，其餘留到下一幀
    // 由畫面中央往外補畫，讓使用者先看到中間
    const order = [];
    for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) order.push([cx, cy]);
    const mcx = (cx0 + cx1) / 2, mcy = (cy0 + cy1) / 2;
    order.sort((a, b2) => Math.hypot(a[0] - mcx, a[1] - mcy) - Math.hypot(b2[0] - mcx, b2[1] - mcy));
    for (const [cx, cy] of order) {
      let c = this.getCacheTile(cx, cy);
      if (!c) {
        if (performance.now() > budgetEnd) { pending = true; continue; }
        c = this.renderCacheTile(cx, cy);
        this.cache.set(cx + ',' + cy, c);
      }
      ctx.drawImage(c, cx * T + offX, cy * T + offY);
    }
    this.trimCache(cx1 - cx0 + 1, cy1 - cy0 + 1);

    // 天氣效果
    if (this.fx) this.drawWeather(ctx, now);

    // 游標與筆刷外框
    if (this.hover && this.hover.tiles.length) this.drawHover(ctx, S, z, offX, offY);

    this.needsDraw = pending;
    cam.changed = false;
    this.stats.lastFrameMs = performance.now() - t0;
    this.stats.cacheTiles = this.cache.size;
    void now;
    return pending;
  }

  drawWeather(ctx, now) {
    const { rain, heat, wind = 0, dry = 0 } = this.fx;
    const W = this.canvas.width, Hh = this.canvas.height;
    if (dry > 0) {
      ctx.fillStyle = `rgba(200,160,60,${0.06 + 0.08 * dry})`;
      ctx.fillRect(0, 0, W, Hh);
    }
    if (heat > 0) {
      ctx.fillStyle = `rgba(255,140,40,${0.06 + 0.1 * heat})`;
      ctx.fillRect(0, 0, W, Hh);
    }
    if (rain > 0) {
      ctx.fillStyle = `rgba(30,45,70,${0.08 + 0.12 * rain + 0.18 * wind})`;
      ctx.fillRect(0, 0, W, Hh);
      ctx.strokeStyle = `rgba(200,220,255,${0.35 + 0.2 * wind})`;
      ctx.lineWidth = this.dpr * (1 + 0.6 * wind);
      ctx.beginPath();
      const n = Math.round(60 + 180 * rain + 120 * wind);
      const t = now * (0.6 + wind * 0.5);
      const slant = 3 + wind * 14; // 颱風時雨斜得很厲害
      for (let k = 0; k < n; k++) {
        const x = ((k * 7919) % W + t * (0.25 + wind)) % W;
        const y = ((k * 104729) % Hh + t) % Hh;
        ctx.moveTo(x, y);
        ctx.lineTo(x - slant * this.dpr, y + 12 * this.dpr);
      }
      ctx.stroke();
    }
  }

  // 預算：可見方塊數 × 3，至少 24 塊
  trimCache(visW, visH) {
    const max = Math.max(24, visW * visH * 3);
    while (this.cache.size > max) {
      const oldest = this.cache.keys().next().value;
      this.cache.delete(oldest);
    }
  }

  drawHover(ctx, S, z, offX, offY) {
    const { size } = this;
    const rot = this.camera.rot;
    ctx.setTransform(S, 0, 0, S, offX, offY);
    ctx.lineJoin = 'round';
    const ok = this.hover.ok !== false;
    const tint = this.hover.color;
    for (const wi of this.hover.tiles) {
      const [vx, vy] = worldToView(wi % size, (wi / size) | 0, rot, size);
      const lv = this.vlev[vy * size + vx];
      const [sx, sy] = tileTop(vx, vy, lv);
      // 頂面亮框
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + HW, sy + HH);
      ctx.lineTo(sx, sy + TILE_H);
      ctx.lineTo(sx - HW, sy + HH);
      ctx.closePath();
      ctx.fillStyle = !ok ? 'rgba(255,90,90,0.3)' : tint || 'rgba(255,255,255,0.22)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.lineWidth = 3 / z;
      ctx.stroke();
      ctx.strokeStyle = ok ? '#ffffff' : '#ff8080';
      ctx.lineWidth = 1.5 / z;
      ctx.stroke();
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
  }
}
