import { describe, it, expect } from 'vitest';
import { flatWorld, smallTown, must, row, rect } from './helpers.js';
import { tick } from '../src/sim/tick.js';
import { updateWeather } from '../src/climate/weather.js';
import { updateHeatIsland } from '../src/climate/heatisland.js';
import { globalWarming, localWarming, seaLevelRise } from '../src/climate/scenario.js';
import { updatePower, coolingFactor, capacityFactor, tileDemandMWh } from '../src/sim/systems/power.js';
import { BASE_TEMP } from '../src/data/climate.js';

function denseCity(month = 7) {
  const w = flatWorld(64, { month });
  must(w, { op: 'road', tiles: [...row(w, 30, 10, 50), ...rect(w, 30, 10, 30, 50)] });
  must(w, { op: 'zone', zone: 2, tiles: rect(w, 20, 20, 29, 29) });
  must(w, { op: 'zone', zone: 4, tiles: rect(w, 31, 20, 40, 29) });
  for (const i of rect(w, 20, 20, 40, 29)) if (w.layers.zone[i]) { w.layers.devLevel[i] = 4; w.layers.pop[i] = w.layers.zone[i] === 2 ? 450 : 0; w.layers.jobs[i] = w.layers.zone[i] === 4 ? 320 : 0; }
  updateWeather(w);
  return w;
}

describe('暖化情境（IPCC AR6）', () => {
  it('2081–2100：低 1.8、中 2.7、高 4.4 °C', () => {
    expect(globalWarming('low', 2090)).toBeCloseTo(1.8, 5);
    expect(globalWarming('mid', 2090)).toBeCloseTo(2.7, 5);
    expect(globalWarming('high', 2090)).toBeCloseTo(4.4, 5);
  });
  it('高排放情境下，2080 年比低排放熱；2025 年三者相同（以現在為零點）', () => {
    expect(localWarming('high', 2080)).toBeGreaterThan(localWarming('low', 2080) + 1.5);
    expect(localWarming('mid', 2025)).toBeCloseTo(0, 6);
  });
  it('海平面：2100 年中排放約 +0.56 m（相對 1995–2014），加速 3 倍時更早到達', () => {
    expect(seaLevelRise('mid', 2100) + seaLevelRise('mid', 2025, 0) * 0).toBeGreaterThan(0.4);
    expect(seaLevelRise('mid', 2050, 3)).toBeGreaterThan(seaLevelRise('mid', 2050, 1));
  });
  it('城市自己的排放不會改變全球升溫（科學正確性）', () => {
    const a = flatWorld(64), b = flatWorld(64);
    smallTown(a, 'coal'); smallTown(b, 'solar');
    for (let k = 0; k < 24; k++) { tick(a); tick(b); }
    expect(a.city.climate.globalDT).toBe(b.city.climate.globalDT);
    expect(a.city.climate.temp).toBe(b.city.climate.temp);
  });
});

describe('每月天氣', () => {
  it('平均起來接近臺南平年值', () => {
    const w = flatWorld(32);
    let sum = 0;
    for (let y = 0; y < 20; y++) { w.city.year = 2025; w.city.seed = y + 1; w.city.month = 7; sum += updateWeather(w).temp; }
    expect(sum / 20).toBeCloseTo(BASE_TEMP[6], 0);
  });
  it('雨季水力發電比乾季多；乾旱（雨量少）時水力下降', () => {
    expect(capacityFactor('hydro', 8, { rainIndex: 1 })).toBeGreaterThan(capacityFactor('hydro', 1, { rainIndex: 1 }));
    expect(capacityFactor('hydro', 8, { rainIndex: 0.3 })).toBeLessThan(capacityFactor('hydro', 8, { rainIndex: 1 }));
  });
});

describe('都市熱島（設計書驗收項目）', () => {
  it('市中心比郊區熱，熱島強度為正', () => {
    const w = denseCity();
    const cl = updateHeatIsland(w);
    expect(cl.heatIsland).toBeGreaterThan(2);
    expect(w.layers.surfTemp[w.index(25, 25)]).toBeGreaterThan(w.layers.surfTemp[w.index(5, 5)] + 2);
  });

  it('在市中心增加公園後，該區地表溫度下降至少 1 °C', () => {
    const a = denseCity(), b = denseCity();
    must(b, { op: 'bulldoze', tiles: rect(b, 24, 24, 25, 25) });
    must(b, { op: 'park', type: 'bigPark', x: 24, y: 24 });
    updateHeatIsland(a); updateHeatIsland(b);
    let da = 0, db = 0, n = 0;
    for (const i of rect(a, 22, 22, 27, 27)) { da += a.layers.surfTemp[i]; db += b.layers.surfTemp[i]; n++; }
    expect(da / n - db / n).toBeGreaterThan(1);
  });

  it('行道樹、綠屋頂、冷屋頂都會降溫', () => {
    for (const flag of ['streetTrees', 'greenRoof', 'coolRoof']) {
      const a = denseCity(), b = denseCity();
      const tiles = flag === 'streetTrees' ? row(b, 30, 10, 50) : rect(b, 20, 20, 29, 29);
      must(b, { op: 'cover', flag, tiles });
      updateHeatIsland(a); updateHeatIsland(b);
      const probe = flag === 'streetTrees' ? b.index(20, 30) : b.index(25, 25);
      expect(b.layers.surfTemp[probe], flag).toBeLessThan(a.layers.surfTemp[probe]);
    }
  });

  it('夏天熱島比冬天明顯', () => {
    const s = denseCity(7), wi = denseCity(1);
    expect(updateHeatIsland(s).heatIsland).toBeGreaterThan(updateHeatIsland(wi).heatIsland);
  });
});

describe('冷氣用電與熱島的正回饋', () => {
  it('越熱越耗電：7 月住商用電比 1 月多，超過 24 °C 每度多 6%', () => {
    expect(coolingFactor(29.4) / coolingFactor(17.8)).toBeCloseTo(1 + 0.06 * 5.4, 5);
  });

  it('熱島區域的每格用電比郊區同樣的建築多', () => {
    const w = denseCity();
    updateHeatIsland(w);
    // 郊區放一棟一樣的公寓
    must(w, { op: 'road', tiles: row(w, 60, 50, 62) });
    must(w, { op: 'zone', zone: 2, tiles: [w.index(56, 59)] });
    const far = w.index(56, 59);
    w.layers.devLevel[far] = 4; w.layers.pop[far] = 450;
    updateHeatIsland(w);
    const core = tileDemandMWh(w.layers, w.index(25, 25), 7, w.localTemp);
    const rural = tileDemandMWh(w.layers, far, 7, w.localTemp);
    expect(core).toBeGreaterThan(rural);
  });

  it('冷氣廢熱讓下個月更熱（熱 → 開冷氣 → 廢熱 → 更熱）', () => {
    const w = denseCity();
    must(w, { op: 'plant', type: 'gas', x: 45, y: 20 });
    must(w, { op: 'powerline', tiles: rect(w, 41, 21, 44, 21) });
    updateHeatIsland(w);
    const before = w.layers.surfTemp[w.index(25, 25)];
    updatePower(w); // 算出冷氣用電
    updateHeatIsland(w);
    expect(w.layers.surfTemp[w.index(25, 25)]).toBeGreaterThan(before);
  });
});
