import { describe, it, expect } from 'vitest';
import { NEWS, NEWS_CAT, pickNews } from '../src/data/news.js';
import { Rng } from '../src/core/rng.js';

const base = { month: 8, has: {}, ev: {}, fc: {}, hot: false, coastal: false, waterLevel: 0, aqiLevel: 0, renew: 0, recentFlood: false };

describe('城市消息輪播', () => {
  it('每則消息都有類別、內容與不重複的編號', () => {
    const ids = new Set();
    for (const n of NEWS) {
      expect(NEWS_CAT[n.cat]).toBeTruthy();
      expect(ids.has(n.id)).toBe(false);
      ids.add(n.id);
    }
    for (const cat of Object.keys(NEWS_CAT)) expect(NEWS.filter((n) => n.cat === cat).length).toBeGreaterThanOrEqual(6);
  });

  it('科學小故事都寫出真實年份，不說成「今年」', () => {
    for (const n of NEWS.filter((x) => x.cat === 'story')) {
      expect(n.text).toMatch(/1[89]\d\d|20\d\d/);
      expect(n.text).not.toMatch(/今年/);
    }
  });

  it('只出現符合城市狀況的消息：冬天沒有登革熱，熱浪時有高溫提醒', () => {
    const rng = new Rng(3);
    const winterIds = new Set(Array.from({ length: 400 }, () => pickNews({ ...base, month: 1 }, () => rng.next()).id));
    expect(winterIds.has('p-dengue')).toBe(false);
    expect(winterIds.has('p-co')).toBe(true);
    const heat = { ...base, ev: { heatwave: true }, hot: true };
    const heatIds = Array.from({ length: 200 }, () => pickNews(heat, () => rng.next()).id);
    expect(heatIds).toContain('p-heat');
    expect(heatIds).toContain('g-elder-heat');
  });

  it('跟現況有關的消息比較常出現', () => {
    const rng = new Rng(5);
    const typhoon = { ...base, fc: { typhoon: true } };
    const n = 2000;
    const hits = Array.from({ length: n }, () => pickNews(typhoon, () => rng.next()).id).filter((id) => id === 'p-typhoon').length;
    const general = Array.from({ length: n }, () => pickNews(typhoon, () => rng.next()).id).filter((id) => id === 'p-recycle').length;
    expect(hits).toBeGreaterThan(general * 2.5);
  });

  it('最近播過的不重複，帶數字的消息會填入城市資料', () => {
    const recent = NEWS.filter((x) => !x.when).map((x) => x.id).slice(0, 10);
    const rng = new Rng(9);
    for (let i = 0; i < 100; i++) expect(recent).not.toContain(pickNews(base, () => rng.next(), recent).id);
    const g = NEWS.find((x) => x.id === 'p-greenshare');
    const t = g.text({ ...base, renew: 0.34 });
    expect(t).toContain('34%');
    expect(t).not.toMatch(/undefined|NaN/);
  });
});
