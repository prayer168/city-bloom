import { describe, it, expect } from 'vitest';
import { Rng, mulberry32, makeValueNoise } from '../src/core/rng.js';
import { idx, inBounds, forEachInSquare, forEachInRadius } from '../src/core/grid.js';
import { World, elevToLevel, levelToElev, LAYER_SPEC } from '../src/sim/world.js';
import { SEA_LEVEL_CM, SURFACE } from '../src/core/constants.js';

describe('亂數可重現', () => {
  it('同一個種子產生同一串數字', () => {
    const a = mulberry32(42), b = mulberry32(42);
    for (let k = 0; k < 100; k++) expect(a()).toBe(b());
  });
  it('不同種子產生不同數字', () => {
    expect(new Rng(1).next()).not.toBe(new Rng(2).next());
  });
  it('雜訊值在 0–1 之間', () => {
    const n = makeValueNoise(7);
    for (let k = 0; k < 500; k++) {
      const v = n.fbm(k * 0.37, k * 0.19, 4);
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThanOrEqual(1);
    }
  });
});

describe('格子索引', () => {
  it('索引 = y × size + x', () => {
    expect(idx(128, 5, 3)).toBe(3 * 128 + 5);
    expect(inBounds(128, 127, 0)).toBe(true);
    expect(inBounds(128, 128, 0)).toBe(false);
    expect(inBounds(128, -1, 5)).toBe(false);
  });
  it('方形範圍在邊緣會被裁切', () => {
    let n = 0;
    forEachInSquare(128, 0, 0, 2, () => n++);
    expect(n).toBe(9); // 3 × 3（只有右下象限）
  });
  it('圓形範圍附距離', () => {
    const ds = [];
    forEachInRadius(128, 50, 50, 1, (_x, _y, _i, d) => ds.push(d));
    expect(ds.length).toBe(5);
    expect(Math.max(...ds)).toBe(1);
  });
});

describe('WorldState', () => {
  it('每條圖層長度 = 格數，128 × 128 全部圖層約 1 MB 以內', () => {
    const w = new World(128);
    let bytes = 0;
    for (const name of Object.keys(LAYER_SPEC)) {
      expect(w.layers[name].length).toBe(128 * 128);
      bytes += w.layers[name].byteLength;
    }
    expect(bytes).toBeLessThan(1.1 * 1024 * 1024);
  });
  it('海拔與畫面層數換算', () => {
    expect(elevToLevel(SEA_LEVEL_CM - 1, SURFACE.GRASS)).toBe(0);
    expect(elevToLevel(SEA_LEVEL_CM, SURFACE.GRASS)).toBe(1);
    expect(elevToLevel(SEA_LEVEL_CM + 199, SURFACE.GRASS)).toBe(1);
    expect(elevToLevel(SEA_LEVEL_CM + 200, SURFACE.GRASS)).toBe(2);
    expect(elevToLevel(SEA_LEVEL_CM + 9999, SURFACE.GRASS)).toBe(15);
    // 同樣海拔的水面比陸地低一層
    expect(elevToLevel(SEA_LEVEL_CM + 500, SURFACE.WATER)).toBe(elevToLevel(SEA_LEVEL_CM + 500, SURFACE.GRASS) - 1);
    for (let lv = 1; lv <= 15; lv++) expect(elevToLevel(levelToElev(lv), SURFACE.GRASS)).toBe(lv);
  });
});
