import { describe, it, expect } from 'vitest';
import { flatWorld, smallTown, must, row, rect } from './helpers.js';
import { tick } from '../src/sim/tick.js';
import { dispatchDay } from '../src/sim/systems/power.js';
import { advise, aiLedger } from '../src/sim/advisor.js';
import { DATACENTER } from '../src/data/ai.js';

function town(months = 12) {
  const w = flatWorld(64);
  smallTown(w, 'coal');
  // 再加一座燃氣電廠，讓資料中心有足夠的電
  must(w, { op: 'plant', type: 'gas', x: 45, y: 25 });
  must(w, { op: 'powerline', tiles: [...rect(w, 44, 21, 44, 26)] });
  for (let k = 0; k < months; k++) tick(w);
  return w;
}
const run = (w, k) => { for (let i = 0; i < k; i++) tick(w); };

describe('AI 資料中心', () => {
  it('蓋了資料中心後，用電、用水與周圍地表溫度都上升（原提示詞驗收項目）', () => {
    const a = town(), b = town();
    must(b, { op: 'dataCenter', x: 5, y: 21 });
    run(a, 2); run(b, 2);
    expect(b.city.power.demandMWh).toBeGreaterThan(a.city.power.demandMWh + 3000);
    expect(b.city.power.dataCenterMWh).toBeGreaterThan(5000);
    expect(b.city.water.demandM3).toBeGreaterThan(a.city.water.demandM3);
    expect(b.city.water.dataCenterM3).toBeGreaterThan(0);
    // 資料中心旁邊（3 格外）的地表溫度比沒有資料中心時高
    const i = b.index(10, 22);
    expect(b.layers.surfTemp[i]).toBeGreaterThan(a.layers.surfTemp[i] + 0.5);
    // 稅收
    expect(b.city.lastMonth.income.ai).toBeGreaterThan(0);
    // 碳排放有一部分要算在資料中心
    expect(b.city.aiCarbon.co2t).toBeGreaterThan(0);
  });

  it('液冷：省電又省水；廢熱回收：周圍比較不熱', () => {
    const a = town(), b = town();
    must(a, { op: 'dataCenter', x: 5, y: 21 });
    must(b, { op: 'dataCenter', x: 5, y: 21 });
    const id = [...b.instances.values()].find((x) => x.def === 'dataCenter').id;
    must(b, { op: 'upgradeDC', id, upgrade: 'liquid' });
    must(b, { op: 'upgradeDC', id, upgrade: 'heatRecovery' });
    run(a, 2); run(b, 2);
    expect(b.city.power.dataCenterMWh).toBeLessThan(a.city.power.dataCenterMWh * 0.85);
    expect(b.city.water.dataCenterM3).toBeLessThan(a.city.water.dataCenterM3 * 0.3);
    const i = b.index(10, 22);
    expect(b.layers.surfTemp[i]).toBeLessThan(a.layers.surfTemp[i]);
  });

  it('遠端綠電契約讓綠電比例上升、發電碳排下降', () => {
    const a = town(), b = town();
    must(a, { op: 'dataCenter', x: 5, y: 21 });
    must(b, { op: 'dataCenter', x: 5, y: 21 });
    must(b, { op: 'upgradeDC', id: [...b.instances.values()].find((x) => x.def === 'dataCenter').id, upgrade: 'green' });
    run(a, 2); run(b, 2);
    expect(b.city.power.renewableShare).toBeGreaterThan(a.city.power.renewableShare + 0.2);
    expect(b.city.power.co2t).toBeLessThan(a.city.power.co2t);
  });

  it('資料中心只能蓋在工業區', () => {
    const w = town(1);
    expect(() => must(w, { op: 'dataCenter', x: 5, y: 17 })).toThrow(/工業區/);
  });
});

describe('智慧城市設施與算力', () => {
  it('開啟 AI 智慧號誌後，交通排放下降（原提示詞驗收項目）', () => {
    const a = town(), b = town();
    for (const w of [a, b]) {
      must(w, { op: 'dataCenter', x: 5, y: 21 });
      // 把道路改窄：只留一條路，讓車流擁擠一些
    }
    must(b, { op: 'smart', type: 'aiSignals', x: 32, y: 17 });
    run(a, 3); run(b, 3);
    expect(b.city.compute.services.aiSignals).toBeGreaterThan(0.9);
    expect(b.city.carbon.transport).toBeLessThan(a.city.carbon.transport);
  });

  it('沒有資料中心就沒有算力，智慧設施不會運作', () => {
    const w = town();
    must(w, { op: 'smart', type: 'aiSignals', x: 32, y: 17 });
    run(w, 2);
    expect(w.city.compute.supply).toBe(0);
    expect(w.city.compute.services.aiSignals).toBe(0);
  });

  it('算力不夠時，每個設施依比例降低效果', () => {
    const w = town();
    must(w, { op: 'dataCenter', x: 5, y: 21 });
    for (const [t, x] of [['aiSignals', 32], ['aiGrid', 33], ['aiWeather', 34], ['aiWater', 35]]) must(w, { op: 'smart', type: t, x, y: 17 });
    run(w, 2);
    // 需求 20 + 30 + 25 + 15 = 90 ≤ 100：剛好夠
    expect(w.city.compute.ratio).toBe(1);
    w.city.water = { ...w.city.water, level: 3 }; // 嚴重限水：蒸發式冷卻降載 30%
    run(w, 1);
    expect(w.city.compute.supply).toBeLessThan(DATACENTER.compute);
  });

  it('AI 智慧電網把缺電時段的用電移到電多的時段（需量反應）', () => {
    const plants = [{ def: 'solar' }, { def: 'solar' }];
    const demand = [8, 8, 8, 8];
    const a = dispatchDay(plants, demand, 7);
    const b = dispatchDay(plants, demand, 7, null, { flex: 0.12 });
    expect(b.unserved).toBeLessThan(a.unserved);
    expect(b.curtailed).toBeLessThanOrEqual(a.curtailed);
    expect(b.shifted).toBeGreaterThan(0);
  });

  it('AI 水資源管理讓用水量減少', () => {
    const a = town(), b = town();
    for (const w of [a, b]) must(w, { op: 'dataCenter', x: 5, y: 21 });
    must(b, { op: 'smart', type: 'aiWater', x: 32, y: 17 });
    run(a, 2); run(b, 2);
    expect(b.city.water.demandM3).toBeLessThan(a.city.water.demandM3 * 0.95);
  });

  it('AI 氣象預警：多看一個月的天氣展望', () => {
    const w = town();
    must(w, { op: 'dataCenter', x: 5, y: 21 });
    must(w, { op: 'smart', type: 'aiWeather', x: 32, y: 17 });
    run(w, 2);
    expect(w.city.climate.outlook).toBeTruthy();
    expect(w.city.climate.forecast.hasWarning).toBe(true);
  });
});

describe('AI 市政顧問（規則式）', () => {
  it('不同目標的顧問，對同一座城市給出不同的建議', () => {
    const w = town();
    const eco = advise(w, 'economy');
    const carbon = advise(w, 'carbon');
    expect(eco.recs.length).toBeGreaterThan(0);
    expect(carbon.recs.length).toBeGreaterThan(0);
    // 經濟顧問建議引進資料中心，減碳顧問建議先不要
    expect(eco.recs.map((r) => r.title)).toContain('引進 AI 資料中心');
    expect(carbon.recs.map((r) => r.title)).toContain('先不要引進 AI 資料中心');
    // 每個建議都要說明依據，也要誠實說出沒考慮到的事
    for (const r of [...eco.recs, ...carbon.recs]) { expect(r.why).toBeTruthy(); expect(r.blind).toBeTruthy(); }
  });
  it('AI 帳本：列出資料中心的好處與代價', () => {
    const w = town();
    expect(aiLedger(w)).toBeNull();
    must(w, { op: 'dataCenter', x: 5, y: 21 });
    run(w, 2);
    const l = aiLedger(w);
    expect(l.income).toBeGreaterThan(0);
    expect(l.mwhShare).toBeGreaterThan(0.3);
    expect(l.water).toBeGreaterThan(0);
  });
});
