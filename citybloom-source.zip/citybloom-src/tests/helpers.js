// 測試用：建立一塊平坦、全是草地的小地圖
import { World } from '../src/sim/world.js';
import { SEA_LEVEL_CM, SURFACE } from '../src/core/constants.js';
import { applyCommand } from '../src/sim/commands.js';

export function flatWorld(size = 64, { month = 1, funds = 1e9 } = {}) {
  const w = new World(size, { seed: 99, funds });
  w.layers.elev.fill(SEA_LEVEL_CM + 300);
  w.layers.surface.fill(SURFACE.GRASS);
  w.city.month = month;
  return w;
}

export const row = (w, y, x0, x1) => {
  const out = [];
  for (let x = x0; x <= x1; x++) out.push(y * w.size + x);
  return out;
};

export const rect = (w, x0, y0, x1, y1) => {
  const out = [];
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) out.push(y * w.size + x);
  return out;
};

export function must(w, cmd) {
  const r = applyCommand(w, cmd);
  if (!r.ok) throw new Error(`指令失敗：${cmd.op} ${r.reason}`);
  return r;
}

// 一個典型小鎮：道路一條，兩側住宅 / 商業 / 工業，加一座電廠用電線接過來
export function smallTown(w, plantType = 'coal') {
  must(w, { op: 'road', tiles: row(w, 20, 5, 40) });
  must(w, { op: 'zone', zone: 2, tiles: rect(w, 5, 17, 20, 19) });  // 高密度住宅
  must(w, { op: 'zone', zone: 4, tiles: rect(w, 21, 17, 30, 19) }); // 高密度商業
  must(w, { op: 'zone', zone: 6, tiles: rect(w, 5, 21, 30, 23) });  // 高密度工業
  must(w, { op: 'plant', type: plantType, x: 45, y: 17 });
  must(w, { op: 'powerline', tiles: row(w, 18, 31, 44) });
  // 道路不導電：在路上架一段電線，讓南邊的工業區也接上電網
  must(w, { op: 'powerline', tiles: [20 * w.size + 30] });
}
