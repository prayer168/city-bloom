import { describe, it, expect } from 'vitest';
import { generateMap, MAP_PRESETS } from '../src/sim/mapgen.js';
import { applyCommand } from '../src/sim/commands.js';
import { SURFACE, SEA_LEVEL_CM } from '../src/core/constants.js';

function stats(w) {
  const s = [0, 0, 0, 0, 0];
  for (let i = 0; i < w.count; i++) s[w.surface[i]]++;
  return s.map((v) => v / w.count);
}

describe('地圖生成', () => {
  it('同一個編號與地形產生完全相同的地圖', () => {
    for (const { id } of MAP_PRESETS) {
      const a = generateMap({ seed: 123, preset: id });
      const b = generateMap({ seed: 123, preset: id });
      expect(Buffer.from(a.layers.elev.buffer).equals(Buffer.from(b.layers.elev.buffer))).toBe(true);
      expect(Buffer.from(a.layers.surface.buffer).equals(Buffer.from(b.layers.surface.buffer))).toBe(true);
    }
  });

  it('不同編號產生不同地圖', () => {
    const a = generateMap({ seed: 1 });
    const b = generateMap({ seed: 2 });
    expect(Buffer.from(a.layers.elev.buffer).equals(Buffer.from(b.layers.elev.buffer))).toBe(false);
  });

  it('河川平原：有河、有足夠的平地可以蓋城市', () => {
    for (const seed of [1, 7, 20261016]) {
      const w = generateMap({ seed, preset: 'river-plain' });
      const [grass, forest, water] = stats(w);
      expect(water).toBeGreaterThan(0.01);
      expect(grass).toBeGreaterThan(0.45);
      expect(forest).toBeGreaterThan(0.1);
      expect(forest).toBeLessThan(0.35);
      let low = 0;
      for (let i = 0; i < w.count; i++) if (w.surface[i] !== SURFACE.WATER && w.level(i) <= 4) low++;
      expect(low / w.count).toBeGreaterThan(0.5);
    }
  });

  it('海岸城市：有海（低於海平面）、有沙岸，且臨海處是低平地', () => {
    for (const seed of [1, 7, 20261016]) {
      const w = generateMap({ seed, preset: 'coast' });
      let sea = 0, sand = 0;
      for (let i = 0; i < w.count; i++) {
        if (w.surface[i] === SURFACE.WATER && w.elev[i] < SEA_LEVEL_CM) sea++;
        if (w.surface[i] === SURFACE.SAND || w.surface[i] === SURFACE.MUDFLAT) sand++;
      }
      expect(sea / w.count).toBeGreaterThan(0.1);
      expect(sand).toBeGreaterThan(50);
    }
  });

  it('丘陵山城：地勢起伏比平原大', () => {
    const spread = (w) => {
      let min = 99, max = 0;
      for (let i = 0; i < w.count; i++) if (w.surface[i] !== SURFACE.WATER) { min = Math.min(min, w.level(i)); max = Math.max(max, w.level(i)); }
      return max - min;
    };
    expect(spread(generateMap({ seed: 5, preset: 'hills' }))).toBeGreaterThanOrEqual(8);
  });

  it('96 × 96 小地圖也能正常生成', () => {
    const w = generateMap({ seed: 3, preset: 'coast', size: 96 });
    expect(w.size).toBe(96);
    expect(stats(w)[SURFACE.WATER]).toBeGreaterThan(0.05);
  });
});

describe('地形工具', () => {
  const flat = () => {
    const w = generateMap({ seed: 1 });
    w.layers.elev.fill(SEA_LEVEL_CM + 300);
    w.layers.surface.fill(SURFACE.GRASS);
    return w;
  };

  it('升高一次 = 一層，最高 15 層', () => {
    const w = flat();
    const i = w.index(10, 10);
    const lv0 = w.level(i);
    applyCommand(w, { op: 'terrain', tool: 'raise', x: 10, y: 10 });
    expect(w.level(i)).toBe(lv0 + 1);
    for (let k = 0; k < 30; k++) applyCommand(w, { op: 'terrain', tool: 'raise', x: 10, y: 10 });
    expect(w.level(i)).toBe(15);
    const r = applyCommand(w, { op: 'terrain', tool: 'raise', x: 10, y: 10 });
    expect(r.changed.length).toBe(0);
  });

  it('降到海平面以下會變成水；在水上升高會填出陸地', () => {
    const w = flat();
    const i = w.index(20, 20);
    for (let k = 0; k < 5; k++) applyCommand(w, { op: 'terrain', tool: 'lower', x: 20, y: 20 });
    expect(w.surface[i]).toBe(SURFACE.WATER);
    expect(w.level(i)).toBe(0);
    applyCommand(w, { op: 'terrain', tool: 'raise', x: 20, y: 20 });
    expect(w.surface[i]).toBe(SURFACE.GRASS);
    expect(w.level(i)).toBe(1);
  });

  it('整平：筆刷範圍內都變成目標層數', () => {
    const w = flat();
    applyCommand(w, { op: 'terrain', tool: 'raise', x: 30, y: 30 });
    applyCommand(w, { op: 'terrain', tool: 'level', x: 30, y: 30, radius: 1, targetLevel: 6 });
    for (let y = 29; y <= 31; y++) for (let x = 29; x <= 31; x++) expect(w.level(w.index(x, y))).toBe(6);
  });

  it('種樹只能種在草地；挖水讓水面比原地面低一層', () => {
    const w = flat();
    const i = w.index(40, 40);
    const lv = w.level(i);
    expect(applyCommand(w, { op: 'terrain', tool: 'trees', x: 40, y: 40 }).changed.length).toBe(1);
    expect(w.surface[i]).toBe(SURFACE.FOREST);
    expect(applyCommand(w, { op: 'terrain', tool: 'trees', x: 40, y: 40 }).changed.length).toBe(0);
    applyCommand(w, { op: 'terrain', tool: 'clearTrees', x: 40, y: 40 });
    applyCommand(w, { op: 'terrain', tool: 'water', x: 40, y: 40 });
    expect(w.surface[i]).toBe(SURFACE.WATER);
    expect(w.level(i)).toBe(lv - 1);
  });

  it('超出地圖的指令被拒絕', () => {
    const w = flat();
    expect(applyCommand(w, { op: 'terrain', tool: 'raise', x: 500, y: 0 }).ok).toBe(false);
  });
});
