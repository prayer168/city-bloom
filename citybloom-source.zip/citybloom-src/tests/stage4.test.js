import { describe, it, expect } from 'vitest';
import { flatWorld, smallTown, must, rect } from './helpers.js';
import { tick } from '../src/sim/tick.js';
import { updateCarbon } from '../src/sim/systems/carbon.js';
import { updatePower } from '../src/sim/systems/power.js';
import { updateTraffic } from '../src/sim/systems/traffic.js';
import { SURFACE } from '../src/core/constants.js';
import { EMISSIONS } from '../src/data/emissions.js';
import { WIKI } from '../src/data/wiki.js';

function town(type = 'coal', months = 36) {
  const w = flatWorld(64);
  smallTown(w, type);
  for (let k = 0; k < months; k++) tick(w);
  return w;
}

describe('碳排放四大來源', () => {
  it('四大來源加總 = 總排放；淨排放 = 總排放 − 吸收', () => {
    const w = town();
    const c = w.city.carbon;
    expect(c.power + c.transport + c.buildings + c.industry).toBeCloseTo(c.gross, 6);
    expect(c.net).toBeCloseTo(c.gross + c.absorb, 6);
    for (const k of ['power', 'transport', 'buildings', 'industry']) expect(c[k]).toBeGreaterThan(0);
  });

  it('燃煤城市以發電為最大來源，比例接近台灣（發電過半）', () => {
    const c = town().city.carbon;
    expect(c.shares.power).toBeGreaterThan(0.5);
    expect(c.shares.transport).toBeGreaterThan(0.03);
    expect(c.perCapita).toBeGreaterThan(3);
  });

  it('碳排圖層：電廠與工業格子最高，加總等於總排放', () => {
    const w = town();
    let sum = 0;
    for (let i = 0; i < w.count; i++) sum += w.layers.carbon[i];
    expect(sum).toBeCloseTo(w.city.carbon.net, 0);
    expect(w.layers.carbon[w.index(46, 18)]).toBeGreaterThan(w.layers.carbon[w.index(10, 18)]);
  });

  it('把燃煤換成太陽能 + 儲能，城市淨碳排明顯下降（原提示詞驗收項目）', () => {
    const coal = town('coal', 36);
    const before = coal.city.carbon.net;
    // 同一座城市：拆掉燃煤，改蓋太陽能與儲能
    must(coal, { op: 'bulldoze', tiles: [coal.index(46, 18)] });
    for (const [x, y] of [[45, 17], [45, 21], [45, 25], [49, 21], [49, 25], [53, 21]]) must(coal, { op: 'plant', type: 'solar', x, y });
    must(coal, { op: 'plant', type: 'battery', x: 49, y: 17 });
    must(coal, { op: 'plant', type: 'battery', x: 51, y: 17 });
    must(coal, { op: 'plant', type: 'gas', x: 53, y: 25 });
    updatePower(coal); updateTraffic(coal);
    const after = updateCarbon(coal).net;
    expect(after).toBeLessThan(before * 0.6);
    expect(coal.city.power.renewableShare).toBeGreaterThan(0.25);
  });

  it('種樹會吸收碳，但一片樹林抵不過一座燃煤電廠（教學重點）', () => {
    const w = town();
    const base = updateCarbon(w).net;
    let planted = 0;
    for (let y = 40; y < 64; y++) for (let x = 0; x < 64; x++) planted += must(w, { op: 'terrain', tool: 'trees', x, y }).changed.length;
    const after = updateCarbon(w);
    expect(after.net).toBeCloseTo(base + planted * EMISSIONS.forestPerTileMonth, 3);
    expect(after.net).toBeLessThan(base);
    expect(-after.absorb).toBeLessThan(after.power); // 一千多公頃的樹也抵不過發電排放
  });

  it('原生樹林不算吸收；砍掉樹林會釋放碳', () => {
    const w = flatWorld(64);
    for (const i of rect(w, 0, 0, 63, 9)) w.layers.surface[i] = SURFACE.FOREST; // 原生林
    expect(updateCarbon(w).absorb).toBe(0);
    must(w, { op: 'zone', zone: 1, tiles: rect(w, 0, 0, 9, 9) }); // 在樹林上劃分區，100 公頃被清除
    const c = updateCarbon(w);
    expect(c.landuse).toBeCloseTo(100 * EMISSIONS.clearingReleaseT, 6);
    expect(updateCarbon(w).landuse).toBe(0); // 只算當月
  });

  it('公車站讓交通碳排下降', () => {
    const a = town('coal', 36);
    const ta = a.city.carbon.transport;
    // 住宅區北邊加一條路，公車站設在路旁
    must(a, { op: 'road', tiles: rect(a, 5, 16, 20, 16) });
    for (const x of [8, 16]) must(a, { op: 'busStop', x, y: 15 });
    updateTraffic(a);
    expect(updateCarbon(a).transport).toBeLessThan(ta);
  });

  it('人均碳排放 = 一年排放 ÷ 人口', () => {
    const w = town('coal', 40);
    const c = w.city.carbon;
    expect(c.perCapita).toBeCloseTo(c.annual / w.city.population, 6);
  });
});

describe('小百科', () => {
  it('每則都有標題與說明，相關條目都存在', () => {
    for (const [k, e] of Object.entries(WIKI)) {
      expect(e.title, k).toBeTruthy();
      expect(e.body.length, k).toBeGreaterThan(30);
      for (const r of e.related || []) expect(WIKI[r], `${k} → ${r}`).toBeTruthy();
    }
  });
});
