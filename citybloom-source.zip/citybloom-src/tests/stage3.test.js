import { describe, it, expect } from 'vitest';
import { flatWorld, smallTown, must, row, rect } from './helpers.js';
import { tick } from '../src/sim/tick.js';
import { updateTraffic } from '../src/sim/systems/traffic.js';
import { updatePollution, updateLandValue, updateCrime } from '../src/sim/systems/environment.js';
import { applyCommand } from '../src/sim/commands.js';
import { NET, SURFACE } from '../src/core/constants.js';
import { TRAFFIC } from '../src/data/transport.js';

// 手動放好建築，不用等成長（測試比較快、也比較穩定）
function setDev(w, tiles, level, pop = 0, jobs = 0) {
  for (const i of tiles) { w.layers.devLevel[i] = level; w.layers.pop[i] = pop; w.layers.jobs[i] = jobs; }
}

// 西邊一片住宅、東邊一片工業，中間只有一條路
function commuteTown(extraRoad = false) {
  const w = flatWorld(64);
  must(w, { op: 'road', tiles: row(w, 30, 2, 60) });
  must(w, { op: 'zone', zone: 2, tiles: rect(w, 2, 27, 15, 29) });
  must(w, { op: 'zone', zone: 6, tiles: rect(w, 47, 27, 60, 29) });
  setDev(w, rect(w, 2, 27, 15, 29), 4, 450);
  setDev(w, rect(w, 47, 27, 60, 29), 4, 0, 280);
  if (extraRoad) {
    // 平行的第二條路：繞上去再下來
    must(w, { op: 'road', tiles: [...row(w, 24, 10, 52), ...rect(w, 10, 25, 10, 29), ...rect(w, 52, 25, 52, 29)] });
  }
  return w;
}

describe('交通', () => {
  it('住宅到工業區的通勤車流集中在唯一的道路上', () => {
    const w = commuteTown();
    const t = updateTraffic(w);
    const mid = w.index(31, 30);
    expect(w.layers.traffic[mid]).toBeGreaterThan(128); // 超過容量
    expect(t.congestedRoads).toBeGreaterThan(0);
    expect(t.carShare).toBeCloseTo(TRAFFIC.baseCarShare, 5);
    expect(t.avgCommuteKm).toBeGreaterThan(3);
  });

  it('多一條平行道路，壅塞會分散', () => {
    const one = commuteTown(false);
    const two = commuteTown(true);
    for (let k = 0; k < 3; k++) { updateTraffic(one); updateTraffic(two); } // 讓車流依壅塞重新分配
    expect(two.trafficLoad[two.index(31, 30)]).toBeLessThan(one.trafficLoad[one.index(31, 30)] * 0.85);
    expect(two.trafficLoad[two.index(31, 24)]).toBeGreaterThan(0);
  });

  it('公車站附近的居民改搭公車，路上的車變少', () => {
    const a = commuteTown();
    const b = commuteTown();
    for (const x of [5, 12]) must(b, { op: 'busStop', x, y: 31 });
    const ta = updateTraffic(a), tb = updateTraffic(b);
    expect(tb.busShare).toBeGreaterThan(0.2);
    expect(tb.carShare).toBeLessThan(ta.carShare);
    expect(tb.carKmPerDay).toBeLessThan(ta.carKmPerDay);
  });

  it('自行車道只影響短程通勤', () => {
    const w = commuteTown();
    must(w, { op: 'bikelane', tiles: row(w, 30, 2, 15) });
    const t = updateTraffic(w);
    expect(t.bikeShare).toBe(0); // 到工業區超過 2.5 公里，不會騎車
    const near = flatWorld(64);
    must(near, { op: 'road', tiles: row(near, 30, 2, 25) });
    must(near, { op: 'zone', zone: 2, tiles: rect(near, 2, 27, 8, 29) });
    must(near, { op: 'zone', zone: 6, tiles: rect(near, 12, 27, 18, 29) });
    setDev(near, rect(near, 2, 27, 8, 29), 2, 180);
    setDev(near, rect(near, 12, 27, 18, 29), 2, 0, 130);
    must(near, { op: 'bikelane', tiles: row(near, 30, 2, 18) });
    expect(updateTraffic(near).bikeShare).toBeGreaterThan(0.05);
  });

  it('公車站要蓋在道路旁', () => {
    const w = flatWorld(32);
    expect(applyCommand(w, { op: 'busStop', x: 10, y: 10 }).ok).toBe(false);
    must(w, { op: 'road', tiles: row(w, 11, 5, 15) });
    expect(applyCommand(w, { op: 'busStop', x: 10, y: 10 }).ok).toBe(true);
  });
});

describe('空氣污染', () => {
  function factoryWorld(month = 1) {
    const w = flatWorld(64, { month });
    must(w, { op: 'zone', zone: 6, tiles: rect(w, 30, 30, 33, 33) });
    setDev(w, rect(w, 30, 30, 33, 33), 4, 0, 280);
    return w;
  }

  it('工廠附近污染最高，越遠越低', () => {
    const w = factoryWorld();
    updatePollution(w);
    const P = w.layers.pollution;
    const at = (x, y) => P[w.index(x, y)];
    expect(at(31, 31)).toBeGreaterThan(at(35, 31));
    expect(at(35, 31)).toBeGreaterThan(at(39, 31));
    expect(at(31, 31)).toBeGreaterThan(50);
  });

  it('季風：冬天東北季風把污染吹向西南，夏天西南季風吹向東北', () => {
    const win = factoryWorld(1);
    updatePollution(win);
    const sum = (w, x, y) => w.layers.pollution[w.index(x, y)];
    // 冬天：西南（左下）比東北（右上）髒
    expect(sum(win, 27, 36)).toBeGreaterThan(sum(win, 36, 27));
    const sum2 = factoryWorld(7);
    updatePollution(sum2);
    expect(sum(sum2, 36, 27)).toBeGreaterThan(sum(sum2, 27, 36));
  });

  it('周圍種樹，擴散出去的污染變少', () => {
    const bare = factoryWorld();
    const green = factoryWorld();
    for (const i of rect(green, 26, 26, 37, 37)) if (!green.layers.zone[i]) green.layers.surface[i] = SURFACE.FOREST;
    updatePollution(bare); updatePollution(green);
    expect(green.layers.pollution[green.index(24, 36)]).toBeLessThan(bare.layers.pollution[bare.index(24, 36)]);
  });

  it('燃煤電廠發電越多，污染越多', () => {
    const lo = flatWorld(64), hi = flatWorld(64);
    must(lo, { op: 'plant', type: 'coal', x: 30, y: 30 });
    must(hi, { op: 'plant', type: 'coal', x: 30, y: 30 });
    [...lo.instances.values()][0].lastCF = 0.1;
    [...hi.instances.values()][0].lastCF = 0.7;
    updatePollution(lo); updatePollution(hi);
    expect(hi.layers.pollution[hi.index(31, 31)]).toBeGreaterThan(lo.layers.pollution[lo.index(31, 31)] * 3);
  });
});

describe('地價與犯罪', () => {
  it('水岸地價比內陸高；污染會拉低地價', () => {
    const w = flatWorld(64);
    for (let y = 0; y < 64; y++) { const i = w.index(5, y); w.layers.surface[i] = SURFACE.WATER; w.layers.waterBody[i] = 2; }
    updateLandValue(w);
    expect(w.layers.landValue[w.index(6, 30)]).toBeGreaterThan(w.layers.landValue[w.index(40, 30)]);
    const before = w.layers.landValue[w.index(40, 30)];
    w.layers.pollution[w.index(40, 30)] = 200;
    updateLandValue(w);
    expect(w.layers.landValue[w.index(40, 30)]).toBeLessThan(before);
  });

  it('人口密集、地價低的地方犯罪指數較高', () => {
    const w = flatWorld(64);
    must(w, { op: 'zone', zone: 2, tiles: rect(w, 10, 10, 14, 14) });
    must(w, { op: 'zone', zone: 1, tiles: rect(w, 40, 40, 44, 44) });
    setDev(w, rect(w, 10, 10, 14, 14), 4, 450);
    setDev(w, rect(w, 40, 40, 44, 44), 1, 40);
    for (const i of rect(w, 10, 10, 14, 14)) w.layers.landValue[i] = 60;
    for (const i of rect(w, 40, 40, 44, 44)) w.layers.landValue[i] = 150;
    updateCrime(w);
    expect(w.layers.crime[w.index(12, 12)]).toBeGreaterThan(w.layers.crime[w.index(42, 42)] * 2);
  });
});

describe('成長與交通、地價的關係', () => {
  it('住宅到不了任何工作時不會升級，城市仍可成長', () => {
    const w = flatWorld(64);
    smallTown(w, 'coal');
    // 一塊與其他道路不相連的住宅區
    must(w, { op: 'road', tiles: row(w, 50, 5, 20) });
    must(w, { op: 'zone', zone: 2, tiles: rect(w, 5, 48, 20, 49) });
    must(w, { op: 'powerline', tiles: rect(w, 30, 24, 30, 47) });
    for (let k = 0; k < 48; k++) tick(w);
    expect(w.city.population).toBeGreaterThan(1000);
    let isolated = 0;
    for (const i of rect(w, 5, 48, 20, 49)) isolated = Math.max(isolated, w.layers.devLevel[i]);
    expect(isolated).toBeLessThanOrEqual(1);
  });

  it('同樣的種子與操作，結果完全一樣（加入交通與污染後）', () => {
    const run = () => { const w = flatWorld(64); smallTown(w); for (let k = 0; k < 24; k++) tick(w); return w; };
    const a = run(), b = run();
    expect(Buffer.from(a.layers.pollution.buffer).equals(Buffer.from(b.layers.pollution.buffer))).toBe(true);
    expect(Buffer.from(a.layers.traffic.buffer).equals(Buffer.from(b.layers.traffic.buffer))).toBe(true);
    expect(a.city.population).toBe(b.city.population);
  });

  it('道路車流寫在 traffic 圖層，非道路格為 0', () => {
    const w = commuteTown();
    updateTraffic(w);
    for (let i = 0; i < w.count; i++) if (!(w.layers.net[i] & NET.ROAD)) expect(w.layers.traffic[i]).toBe(0);
  });
});
