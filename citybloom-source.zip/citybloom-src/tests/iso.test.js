import { describe, it, expect } from 'vitest';
import {
  worldToView, viewToWorld, tileTop, screenToGround, pickViewTile, wallDrops,
} from '../src/render/iso.js';
import { groundWorldToView, groundViewToWorld } from '../src/render/camera.js';
import { LEVEL_PX } from '../src/core/constants.js';

const N = 128;

describe('旋轉', () => {
  it('四個方向都能來回換算', () => {
    for (let rot = 0; rot < 4; rot++) {
      for (const [x, y] of [[0, 0], [127, 0], [5, 99], [64, 64], [127, 127]]) {
        const [vx, vy] = worldToView(x, y, rot, N);
        expect(vx).toBeGreaterThanOrEqual(0);
        expect(vy).toBeLessThan(N);
        expect(viewToWorld(vx, vy, rot, N)).toEqual([x, y]);
      }
    }
  });
  it('連續旋轉四次回到原位', () => {
    let p = [10, 20];
    for (let k = 0; k < 4; k++) {
      const [vx, vy] = worldToView(p[0], p[1], 1, N);
      p = [vx, vy];
    }
    expect(p).toEqual([10, 20]);
  });
  it('連續座標的旋轉與格座標一致（格中心）', () => {
    for (let rot = 0; rot < 4; rot++) {
      const [vx, vy] = worldToView(7, 30, rot, N);
      const [fx, fy] = groundWorldToView(7.5, 30.5, rot, N);
      expect([fx - 0.5, fy - 0.5]).toEqual([vx, vy]);
      expect(groundViewToWorld(fx, fy, rot, N)).toEqual([7.5, 30.5]);
    }
  });
});

describe('投影', () => {
  it('格中心反投影回同一格', () => {
    for (const [vx, vy] of [[0, 0], [3, 9], [100, 2], [127, 127]]) {
      const [sx, sy] = tileTop(vx, vy, 0);
      const [gx, gy] = screenToGround(sx, sy + 16);
      expect([Math.floor(gx), Math.floor(gy)]).toEqual([vx, vy]);
    }
  });
  it('高度越高，畫面越上面', () => {
    expect(tileTop(5, 5, 3)[1]).toBe(tileTop(5, 5, 0)[1] - 3 * LEVEL_PX);
  });
});

describe('點選格子（考慮高度）', () => {
  it('平地：點格中心選到該格', () => {
    const levelAt = () => 1;
    const [sx, sy] = tileTop(40, 50, 1);
    expect(pickViewTile(sx, sy + 16, N, levelAt)).toEqual([40, 50]);
  });
  it('被抬高的格子擋住後面的格子', () => {
    // (40,50) 抬高 6 層；點它的頂面，即使那個位置在地面上屬於後面的格子
    const levelAt = (vx, vy) => (vx === 40 && vy === 50 ? 7 : 1);
    const [sx, sy] = tileTop(40, 50, 7);
    expect(pickViewTile(sx, sy + 16, N, levelAt)).toEqual([40, 50]);
    const [gx, gy] = screenToGround(sx, sy + 16 + LEVEL_PX);
    expect([Math.floor(gx), Math.floor(gy)]).not.toEqual([40, 50]);
  });
  it('點到懸崖牆面時選到牆的主人', () => {
    const levelAt = (vx, vy) => (vx === 40 && vy === 50 ? 7 : 1);
    const [sx, sy] = tileTop(40, 50, 7);
    // 右前牆中間
    expect(pickViewTile(sx + 16, sy + 24 + 20, N, levelAt)).toEqual([40, 50]);
  });
  it('地圖外面選不到', () => {
    expect(pickViewTile(-99999, -99999, N, () => 1)).toBeNull();
  });
  it('牆高 = 本格減前方鄰格；地圖邊緣降到地基', () => {
    const levelAt = (vx, vy) => (vx === 10 && vy === 10 ? 5 : 2);
    expect(wallDrops(levelAt, 10, 10, N)).toEqual([3 * LEVEL_PX, 3 * LEVEL_PX]);
    expect(wallDrops(() => 2, 127, 127, N)).toEqual([5 * LEVEL_PX, 5 * LEVEL_PX]);
  });
});
