import { describe, it, expect } from 'vitest';
import { World, WATER_BODY } from '../src/sim/world.js';
import { SEA_LEVEL_CM, SURFACE, UTIL, STATE, NET, COVER } from '../src/core/constants.js';
import { flatWorld, smallTown, must, row, rect } from './helpers.js';
import { tick } from '../src/sim/tick.js';
import { computeFlood, floodSummary } from '../src/sim/systems/flood.js';
import { updateSeaLevel } from '../src/climate/sealevel.js';
import { updateWeather } from '../src/climate/weather.js';
import { updateHeatIsland } from '../src/climate/heatisland.js';
import { updatePower } from '../src/sim/systems/power.js';
import { updateWater } from '../src/sim/systems/water.js';
import { settleDisasters, computeResilience } from '../src/sim/systems/disaster.js';
import { hazardFactors, monthProbabilities, typhoonShares, rollEvents, applyEventsToWeather, prepareForecast } from '../src/climate/events.js';
import { TYPHOON } from '../src/data/hazards.js';

// 碗狀地形：中間低、四周高；城市蓋在碗底，下大雨時水會往這裡集中
function bowlTown() {
  const w = new World(48, { seed: 7, funds: 1e9 });
  const L = w.layers;
  for (let y = 0; y < 48; y++) for (let x = 0; x < 48; x++) {
    const i = y * 48 + x;
    L.surface[i] = SURFACE.GRASS;
    // 半徑 12 格內是碗，外面是往地圖邊緣下降的山坡（外面的雨會流走）
    const r = Math.hypot(x - 24, y - 20);
    L.elev[i] = SEA_LEVEL_CM + 300 + Math.round(r <= 12 ? r * 6 : 72 - (r - 12) * 6);
  }
  w.city.disabledHazards = ['typhoon', 'heavyRain', 'heatwave', 'drought'];
  must(w, { op: 'road', tiles: row(w, 20, 10, 38) });
  must(w, { op: 'zone', zone: 2, tiles: [...rect(w, 14, 16, 34, 19), ...rect(w, 14, 21, 34, 24)] });
  for (const i of rect(w, 14, 16, 34, 24)) if (L.zone[i]) { L.devLevel[i] = 3; L.pop[i] = 300; }
  return w;
}

describe('淹水模型', () => {
  it('同樣的強降雨下，有滯洪池與透水鋪面的區域淹水範圍較小（原提示詞驗收項目）', () => {
    const w = bowlTown();
    const before = floodSummary(w, computeFlood(w, { rainMm: 250 }).depth);
    expect(before.urban).toBeGreaterThan(5);
    must(w, { op: 'adapt', type: 'detentionPond', x: 23, y: 13 });
    must(w, { op: 'cover', flag: 'permeable', tiles: rect(w, 10, 16, 38, 24) });
    const r = computeFlood(w, { rainMm: 250 });
    const after = floodSummary(w, r.depth);
    expect(after.urban).toBeLessThan(before.urban * 0.8);
    expect(r.stats.pondStoredM3).toBeGreaterThan(0);
    // 「假如沒有設施」的反事實計算要和原本一樣（災情報告用）
    const without = floodSummary(w, computeFlood(w, { rainMm: 250, adapt: false }).depth);
    expect(Math.abs(without.urban - before.urban)).toBeLessThanOrEqual(2);
  });

  it('低窪的地方先淹：碗底比碗邊深', () => {
    const w = bowlTown();
    const d = computeFlood(w, { rainMm: 300 }).depth;
    expect(d[w.index(24, 19)]).toBeGreaterThan(d[w.index(14, 16)]);
  });

  it('抽水站沒電就不能抽水；有電時積水變淺', () => {
    const w = bowlTown();
    must(w, { op: 'adapt', type: 'pumpStation', x: 24, y: 14 });
    const i0 = w.index(24, 14);
    const off = computeFlood(w, { rainMm: 300 });
    expect(off.stats.pumpsOffline).toBe(1);
    expect(off.stats.pumpedM3).toBe(0);
    w.layers.util[i0] |= UTIL.POWERED;
    const on = computeFlood(w, { rainMm: 300 });
    expect(on.stats.pumpedM3).toBeGreaterThan(0);
    const sum = (d) => d.reduce((a, b) => a + b, 0);
    expect(sum(on.depth)).toBeLessThan(sum(off.depth));
  });

  it('河水暴漲時，低窪河岸會淹；蓋了堤防就擋住', () => {
    const w = new World(40, { seed: 3, funds: 1e9 });
    const L = w.layers;
    for (let y = 0; y < 40; y++) for (let x = 0; x < 40; x++) {
      const i = y * 40 + x;
      if (x >= 18 && x <= 20) { L.surface[i] = SURFACE.WATER; L.waterBody[i] = WATER_BODY.RIVER; L.elev[i] = SEA_LEVEL_CM + 20; }
      else { L.surface[i] = SURFACE.GRASS; L.elev[i] = SEA_LEVEL_CM + 120 + Math.abs(x - 19) * 15; }
    }
    const before = computeFlood(w, { rainMm: 0, riverStage: 2.2 });
    expect(before.depth[w.index(22, 20)]).toBeGreaterThan(0.1);
    // 兩岸各一整排堤防
    must(w, { op: 'defense', flag: 'levee', tiles: [...rect(w, 17, 0, 17, 39), ...rect(w, 21, 0, 21, 39)] });
    const after = computeFlood(w, { rainMm: 0, riverStage: 2.2 });
    expect(after.depth[w.index(22, 20)]).toBe(0);
    expect(after.stats.leveeBlocked).toBeGreaterThan(0);
  });
});

// 海岸：x < 8 是海，陸地從海邊 10 公分慢慢升高
function coastWorld(scenario) {
  const w = new World(48, { seed: 5, funds: 1e9, scenario });
  const L = w.layers;
  for (let y = 0; y < 48; y++) for (let x = 0; x < 48; x++) {
    const i = y * 48 + x;
    if (x < 8) { L.surface[i] = SURFACE.WATER; L.waterBody[i] = WATER_BODY.SEA; L.elev[i] = SEA_LEVEL_CM - 300; }
    else { L.surface[i] = SURFACE.GRASS; L.elev[i] = SEA_LEVEL_CM + 10 + (x - 8) * 8; }
  }
  return w;
}

describe('海平面上升', () => {
  it('高排放情境下，海岸低地在 2055 年以後受海平面上升影響；低排放影響較小（原提示詞驗收項目）', () => {
    const hi = coastWorld('high'), lo = coastWorld('low');
    for (const w of [hi, lo]) { w.city.year = 2055; w.city.month = 1; }
    const rh = updateSeaLevel(hi), rl = updateSeaLevel(lo);
    expect(rh.submerged).toBeGreaterThan(0);
    expect(rh.submerged + rh.tidal).toBeGreaterThan(rl.submerged + rl.tidal);
    // 2025 年（現在）還沒有被淹沒的土地
    const now = coastWorld('high'); now.city.year = 2025;
    expect(updateSeaLevel(now).submerged).toBe(0);
  });

  it('海堤擋住海水：海堤後面的低地不會被淹沒', () => {
    const w = coastWorld('high');
    w.city.year = 2055;
    must(w, { op: 'defense', flag: 'seawall', tiles: rect(w, 8, 0, 8, 47) });
    const r = updateSeaLevel(w);
    expect(r.submerged).toBe(0);
    expect(w.layers.state[w.index(10, 10)] & STATE.SUBMERGED).toBe(0);
  });

  it('颱風暴潮會淹海岸；海堤擋得住', () => {
    const w = coastWorld('mid');
    const a = computeFlood(w, { rainMm: 0, surgeM: 1.0, tideM: 0.5 });
    expect(a.depth[w.index(9, 20)]).toBeGreaterThan(0.1);
    must(w, { op: 'defense', flag: 'seawall', tiles: rect(w, 8, 0, 8, 47) });
    const b = computeFlood(w, { rainMm: 0, surgeM: 1.0, tideM: 0.5 });
    expect(b.depth[w.index(9, 20)]).toBe(0);
  });
});

function denseCity(month = 7) {
  const w = flatWorld(64, { month });
  must(w, { op: 'road', tiles: [...row(w, 30, 10, 50), ...rect(w, 30, 10, 30, 50)] });
  must(w, { op: 'zone', zone: 2, tiles: [...rect(w, 14, 20, 29, 29), ...rect(w, 31, 20, 42, 29)] });
  must(w, { op: 'park', type: 'bigPark', x: 43, y: 24 });
  for (const i of rect(w, 14, 20, 42, 29)) if (w.layers.zone[i]) { w.layers.devLevel[i] = 4; w.layers.pop[i] = 450; }
  must(w, { op: 'plant', type: 'gas', x: 10, y: 10 });
  must(w, { op: 'powerline', tiles: [...rect(w, 12, 13, 12, 20), w.index(13, 20)] });
  return w;
}

describe('熱浪', () => {
  it('熱浪期間用電需求上升，熱島嚴重的地方上升最多（原提示詞驗收項目）', () => {
    const w = denseCity(7);
    const L = w.layers;
    updateWeather(w); w.city.climate.activeEvents = []; applyEventsToWeather(w);
    updateHeatIsland(w); updateHeatIsland(w);
    const p0 = updatePower(w);
    const t0 = Float32Array.from(w.localTemp);
    const surf = Float32Array.from(L.surfTemp);
    updateWeather(w); w.city.climate.activeEvents = [{ type: 'heatwave', dT: 3, days: 10 }]; applyEventsToWeather(w);
    updateHeatIsland(w);
    const p1 = updatePower(w);
    expect(p1.demandMWh).toBeGreaterThan(p0.demandMWh);
    expect(p1.heatwave.peakDayMWh).toBeGreaterThan(p1.heatwave.normalDayMWh);
    // 找最熱與最涼（公園旁）的住宅格，比較升溫
    const res = rect(w, 14, 20, 42, 29).filter((i) => L.zone[i]);
    res.sort((a, b) => surf[b] - surf[a]);
    const hot = res[0], cool = res[res.length - 1];
    expect(surf[hot]).toBeGreaterThan(surf[cool] + 0.5);
    expect(w.localTemp[hot] - t0[hot]).toBeGreaterThan(w.localTemp[cool] - t0[cool]);
  });
});

describe('颱風與供電韌性', () => {
  function stormTown() {
    const w = flatWorld(64);
    smallTown(w, 'coal');
    for (let k = 0; k < 18; k++) tick(w);
    w.city.climate.activeEvents = [{ type: 'typhoon', cat: 'strong', name: '強烈颱風', windMs: 55, rainMm: 0, surgeM: 0, days: 2 }];
    return w;
  }
  it('強風吹斷電線造成停電；電線地下化後不會斷', () => {
    const keep = TYPHOON.cats.strong.lineP;
    TYPHOON.cats.strong.lineP = 1; // 測試用：讓每一格架空電線都被吹斷
    try {
      const a = stormTown();
      const ra = settleDisasters(a);
      expect(ra.reports[0].wind.brokenLines).toBeGreaterThan(0);
      expect(ra.reports[0].wind.outageTiles).toBeGreaterThan(0);

      const b = stormTown();
      const lines = [];
      for (let i = 0; i < b.size * b.size; i++) if (b.layers.net[i] & NET.POWERLINE) lines.push(i);
      must(b, { op: 'cover', flag: 'undergroundGrid', tiles: lines });
      const rb = settleDisasters(b);
      expect(rb.reports[0].wind.brokenLines).toBe(0);
      expect(rb.reports[0].wind.outageTiles).toBe(0);
      expect(rb.reports[0].wind.savedLines).toBeGreaterThan(0);
    } finally { TYPHOON.cats.strong.lineP = keep; }
  });
});

describe('乾旱與供水', () => {
  it('水庫蓄水率低時限水，工廠減產；再生水廠讓缺水變少', () => {
    const w = flatWorld(64, { month: 3 });
    smallTown(w, 'coal');
    for (let k = 0; k < 18; k++) tick(w);
    expect(w.city.jobs.i).toBeGreaterThan(0);
    updateWeather(w);
    w.city.water = { storage: 0.12 };
    const a = updateWater(w);
    expect(a.level).toBe(3);
    expect(a.indCutFrac).toBeGreaterThan(0);

    must(w, { op: 'adapt', type: 'recycledWater', x: 50, y: 30 });
    const inst = [...w.instances.values()].find((x) => x.def === 'recycledWater');
    w.layers.util[w.index(inst.x, inst.y)] |= UTIL.POWERED;
    w.city.water = { storage: 0.12 };
    const b = updateWater(w);
    expect(b.recycledM3).toBeGreaterThan(0);
    expect(b.indCutFrac).toBeLessThan(a.indCutFrac);
    expect(b.shortageM3).toBeLessThan(a.shortageM3);
  });

  it('再生水廠沒電就不能供水', () => {
    const w = flatWorld(64, { month: 3 });
    smallTown(w, 'coal');
    for (let k = 0; k < 6; k++) tick(w);
    must(w, { op: 'adapt', type: 'recycledWater', x: 50, y: 30 });
    updateWeather(w);
    const r = updateWater(w);
    expect(r.recycledM3).toBe(0);
    expect(r.offline).toContain('recycledWater');
  });
});

describe('極端天氣頻率（IPCC AR6）', () => {
  it('升溫越多，熱浪、強降雨、乾旱越頻繁；2025 年為基準 1 倍', () => {
    const now = hazardFactors('mid', 2025);
    expect(now.heatFreq).toBeCloseTo(1, 6);
    const hi = hazardFactors('high', 2090), lo = hazardFactors('low', 2090);
    expect(hi.heatFreq).toBeGreaterThan(lo.heatFreq);
    expect(hi.heatFreq).toBeGreaterThan(2);
    expect(hi.rainFreq).toBeGreaterThan(1.3);
    expect(hi.droughtFreq).toBeGreaterThan(1.5);
    expect(hi.rainMult).toBeGreaterThan(1.1);
  });
  it('颱風次數不變，但強颱比例與雨量增加（設計決策 Q5）', () => {
    expect(monthProbabilities('high', 2090, 8).typhoon).toBe(monthProbabilities('high', 2025, 8).typhoon);
    expect(typhoonShares('high', 2090).strong).toBeGreaterThan(typhoonShares('high', 2025).strong);
    expect(hazardFactors('high', 2090).tcRainMult).toBeGreaterThan(1.15);
  });
  it('同一個地圖編號一定得到同樣的天氣', () => {
    expect(rollEvents(42, 'mid', 2031, 8)).toEqual(rollEvents(42, 'mid', 2031, 8));
  });
});

describe('天氣預報與災情報告', () => {
  it('預報在事件發生前一個月出現，下個月事件真的發生', () => {
    const w = flatWorld(64, { month: 6, hazards: true });
    smallTown(w, 'coal');
    prepareForecast(w);
    let found = null;
    for (let k = 0; k < 60 && !found; k++) {
      const fc = w.city.climate.forecast;
      if (fc.events.some((e) => e.type === 'typhoon' || e.type === 'heavyRain' || e.type === 'heatwave')) found = fc.events.map((e) => e.type);
      tick(w);
      if (found) expect(w.city.history.monthly.at(-1).events).toEqual(found);
    }
    expect(found).not.toBeNull();
  });

  it('災情報告比較「有設施」與「沒有設施」，並列出發揮作用的設施', () => {
    const w = bowlTown();
    must(w, { op: 'adapt', type: 'detentionPond', x: 23, y: 13 });
    must(w, { op: 'cover', flag: 'permeable', tiles: rect(w, 10, 16, 38, 24) });
    w.city.climate.activeEvents = [{ type: 'heavyRain', name: '豪雨', rainMm: 280, days: 2 }];
    const r = settleDisasters(w);
    const rep = r.reports[0];
    expect(rep.compare.withoutTiles).toBeGreaterThan(rep.compare.withTiles);
    expect(rep.helped.map((h) => h[0])).toContain('detentionPond');
    expect(rep.helped.map((h) => h[0])).toContain('sponge');
    expect(w.city.reports.length).toBe(1);
    expect(r.lossK).toBeGreaterThanOrEqual(0);
  });

  it('同樣的地圖與決策，兩次模擬的災害完全相同', () => {
    const a = flatWorld(64, { month: 5, hazards: true }), b = flatWorld(64, { month: 5, hazards: true });
    smallTown(a); smallTown(b);
    for (let k = 0; k < 30; k++) { tick(a); tick(b); }
    expect(a.city.history.monthly.map((h) => h.events.join())).toEqual(b.city.history.monthly.map((h) => h.events.join()));
    expect(a.city.funds).toBe(b.city.funds);
  });
});

describe('氣候韌性指數', () => {
  it('蓋避難中心與預警中心後，韌性指數上升', () => {
    const w = denseCity(7);
    for (let k = 0; k < 3; k++) tick(w);
    const before = computeResilience(w).score;
    must(w, { op: 'adapt', type: 'shelter', x: 32, y: 18 });
    must(w, { op: 'adapt', type: 'warningCenter', x: 33, y: 18 });
    const after = computeResilience(w);
    expect(after.score).toBeGreaterThan(before);
    expect(after.parts.warning).toBe(1);
    expect(after.parts.shelter).toBeGreaterThan(0);
  });
  it('屋頂光電讓停電時還有電（輪流停電時跳過）', () => {
    const w = denseCity(7);
    for (let k = 0; k < 2; k++) tick(w);
    const homes = rect(w, 14, 20, 29, 29).filter((i) => w.layers.zone[i] && w.layers.devLevel[i]);
    must(w, { op: 'cover', flag: 'roofSolar', tiles: homes });
    expect(w.layers.cover[homes[0]] & COVER.ROOF_SOLAR).toBeTruthy();
    const p = updatePower(w);
    expect(p.rooftopMW).toBeGreaterThan(0);
  });
});
