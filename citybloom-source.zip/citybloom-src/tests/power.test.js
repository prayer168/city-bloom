import { describe, it, expect } from 'vitest';
import { flatWorld, smallTown, must, row, rect } from './helpers.js';
import { applyCommand } from '../src/sim/commands.js';
import { tick } from '../src/sim/tick.js';
import { findGrids, dispatchDay, updatePower } from '../src/sim/systems/power.js';
import { UTIL } from '../src/core/constants.js';
import { PLANTS } from '../src/data/energy.js';

// 讓小鎮先長出建築
function grownTown(type = 'coal', months = 24) {
  const w = flatWorld(64);
  smallTown(w, type);
  for (let k = 0; k < months; k++) tick(w);
  return w;
}

describe('電網連通', () => {
  it('電線斷開後，不連通的區域停電（原提示詞驗收項目）', () => {
    const w = grownTown('coal');
    const res = w.index(10, 18);
    expect(w.layers.devLevel[res]).toBeGreaterThan(0);
    expect(w.layers.util[res] & UTIL.POWERED).toBeTruthy();

    // 拆掉電線中間一格
    must(w, { op: 'bulldoze', tiles: [w.index(38, 18)] });
    updatePower(w);
    expect(w.layers.util[res] & UTIL.POWERED).toBe(0);
    // 電廠那一側的電線仍然有電
    expect(w.layers.util[w.index(43, 18)] & UTIL.POWERED).toBeTruthy();
    expect(findGrids(w).grids.length).toBeGreaterThanOrEqual(2);
  });

  it('道路不導電，必須在路上架電線', () => {
    const w = flatWorld(64);
    must(w, { op: 'road', tiles: row(w, 10, 0, 63) });
    must(w, { op: 'zone', zone: 1, tiles: rect(w, 10, 8, 14, 9) });
    must(w, { op: 'plant', type: 'gas', x: 10, y: 11 });
    const { comp } = findGrids(w);
    expect(comp[w.index(10, 9)]).not.toBe(comp[w.index(10, 11)]);
    must(w, { op: 'powerline', tiles: [w.index(10, 10)] });
    const g2 = findGrids(w).comp;
    expect(g2[w.index(10, 9)]).toBe(g2[w.index(10, 11)]);
  });
});

describe('一天四時段調度', () => {
  const demand = [10, 10, 10, 10]; // 每時段 10 MWh
  const solar = (n = 1) => Array.from({ length: n }, () => ({ def: 'solar' }));

  it('只有太陽能、沒有儲能：夜間一定缺電（原提示詞：冬季應出現供電缺口）', () => {
    const jan = dispatchDay(solar(20), demand, 1);
    expect(jan.slots[0].unserved).toBeCloseTo(10, 5); // 夜
    expect(jan.slots[3].unserved).toBeCloseTo(10, 5); // 晚
    expect(jan.unserved).toBeGreaterThan(0);
  });

  it('加上儲能：中午多的電存起來，夜間缺口變小', () => {
    const noStore = dispatchDay(solar(20), demand, 7);
    const withStore = dispatchDay([...solar(20), { def: 'battery' }, { def: 'battery' }], demand, 7);
    expect(withStore.discharged).toBeGreaterThan(0);
    expect(withStore.unserved).toBeLessThan(noStore.unserved);
    expect(withStore.curtailed).toBeLessThan(noStore.curtailed);
  });

  it('風光互補：太陽能夏強冬弱，風力冬強夏弱', () => {
    const s = (m) => dispatchDay(solar(1), [100, 100, 100, 100], m).genBySource.solar;
    const wd = (m) => dispatchDay([{ def: 'wind' }], [100, 100, 100, 100], m).genBySource.wind;
    expect(s(7)).toBeGreaterThan(s(1));
    expect(wd(1)).toBeGreaterThan(wd(7));
  });

  it('核能日夜固定出力；燃煤依需求調整', () => {
    const nuc = dispatchDay([{ def: 'nuclear' }], [600, 600, 600, 600], 1);
    nuc.slots.forEach((s) => expect(s.baseUsed).toBeCloseTo(PLANTS.nuclear.mw * PLANTS.nuclear.cf * 6, 5));
    const coal = dispatchDay([{ def: 'coal' }], [10, 50, 80, 30], 1);
    expect(coal.slots.map((s) => Math.round(s.coal))).toEqual([10, 50, 80, 30]);
    expect(coal.unserved).toBe(0);
  });

  it('再生能源優先，燃煤只補不足的部分', () => {
    const r = dispatchDay([...solar(10), { def: 'coal' }], [40, 40, 40, 40], 7);
    expect(r.slots[2].coal).toBeLessThan(r.slots[0].coal); // 中午太陽能多，燃煤少
  });
});

describe('輪流停電', () => {
  it('電不夠時，離電廠最遠的用戶先停電', () => {
    const w = flatWorld(64);
    must(w, { op: 'road', tiles: row(w, 20, 2, 60) });
    must(w, { op: 'zone', zone: 2, tiles: rect(w, 5, 18, 60, 19) });
    must(w, { op: 'plant', type: 'wind', x: 2, y: 17 }); // 一座風場供應不了這麼多人，部分用戶要停電
    for (let i of rect(w, 5, 18, 60, 19)) { w.layers.devLevel[i] = 2; w.layers.pop[i] = 180; }
    const p = updatePower(w);
    expect(p.blackoutTiles).toBeGreaterThan(0);
    const near = w.layers.util[w.index(6, 18)];
    const far = w.layers.util[w.index(60, 18)];
    expect(far & UTIL.BLACKOUT).toBeTruthy();
    expect(near & UTIL.BLACKOUT).toBe(0);
  });
});

describe('碳排放與再生能源比例', () => {
  it('把燃煤換成太陽能 + 儲能，碳排放明顯下降、再生能源比例上升', () => {
    const coal = grownTown('coal', 24);
    const pc = updatePower(coal);
    const solar = flatWorld(64);
    smallTown(solar, 'solar');
    // 用相同的城市規模比較：複製建築狀態
    for (const k of ['zone', 'devLevel', 'pop', 'jobs']) solar.layers[k].set(coal.layers[k]);
    must(solar, { op: 'plant', type: 'solar', x: 45, y: 21 });
    must(solar, { op: 'plant', type: 'solar', x: 45, y: 24 });
    must(solar, { op: 'plant', type: 'battery', x: 48, y: 21 });
    const ps = updatePower(solar);
    expect(ps.co2t).toBeLessThan(pc.co2t * 0.3);
    expect(ps.renewableShare).toBeGreaterThan(0.9);
    expect(pc.renewableShare).toBe(0);
    // 燃煤每度電約 0.82 公斤 CO₂
    expect(pc.co2t / pc.generationMWh).toBeCloseTo(0.82, 2);
  });
});

describe('建築成長', () => {
  it('有道路、有電、有需求才會長出建築', () => {
    const w = grownTown('coal', 36);
    expect(w.city.population).toBeGreaterThan(2000);
    expect(w.city.jobs.i).toBeGreaterThan(0);
    expect(w.city.jobs.c).toBeGreaterThan(0);
  });

  it('沒有電：不會長出建築', () => {
    const w = flatWorld(64);
    must(w, { op: 'road', tiles: row(w, 20, 5, 40) });
    must(w, { op: 'zone', zone: 1, tiles: rect(w, 5, 18, 20, 19) });
    for (let k = 0; k < 24; k++) tick(w);
    expect(w.city.population).toBe(0);
  });

  it('沒有道路（超過 3 格）：不會長出建築', () => {
    const w = flatWorld(64);
    must(w, { op: 'zone', zone: 1, tiles: rect(w, 5, 5, 20, 8) });
    must(w, { op: 'plant', type: 'gas', x: 21, y: 5 });
    for (let k = 0; k < 24; k++) tick(w);
    expect(w.city.population).toBe(0);
    must(w, { op: 'road', tiles: row(w, 9, 5, 20) });
    for (let k = 0; k < 24; k++) tick(w);
    expect(w.city.population).toBeGreaterThan(0);
  });

  it('同樣的種子與操作，結果完全一樣', () => {
    const a = grownTown('coal', 18), b = grownTown('coal', 18);
    expect(a.city.population).toBe(b.city.population);
    expect(Buffer.from(a.layers.devLevel.buffer).equals(Buffer.from(b.layers.devLevel.buffer))).toBe(true);
  });
});

describe('建造規則', () => {
  it('地面不平不能蓋電廠', () => {
    const w = flatWorld(32);
    must(w, { op: 'terrain', tool: 'raise', x: 6, y: 6 });
    const r = applyCommand(w, { op: 'plant', type: 'gas', x: 5, y: 5 });
    expect(r.ok).toBe(false);
    expect(r.reason).toMatch(/整平/);
  });

  it('水力電廠必須在河邊', () => {
    const w = flatWorld(32);
    expect(applyCommand(w, { op: 'plant', type: 'hydro', x: 5, y: 5 }).ok).toBe(false);
    for (let y = 0; y < 32; y++) { const i = w.index(10, y); w.layers.surface[i] = 2; w.layers.waterBody[i] = 2; }
    expect(applyCommand(w, { op: 'plant', type: 'hydro', x: 8, y: 5 }).ok).toBe(true);
  });

  it('資金不足不能蓋，蓋了會扣錢', () => {
    const w = flatWorld(32, { funds: 2000 });
    expect(applyCommand(w, { op: 'plant', type: 'nuclear', x: 2, y: 2 }).reason).toMatch(/資金不足/);
    const before = w.city.funds;
    must(w, { op: 'plant', type: 'wind', x: 2, y: 2 });
    expect(w.city.funds).toBe(before - PLANTS.wind.cost);
  });

  it('拆除電廠任一格，整座電廠都會移除', () => {
    const w = flatWorld(32);
    must(w, { op: 'plant', type: 'coal', x: 2, y: 2 });
    expect(w.instances.size).toBe(1);
    must(w, { op: 'bulldoze', tiles: [w.index(4, 4)] });
    expect(w.instances.size).toBe(0);
    expect(w.layers.bld[w.index(2, 2)]).toBe(0);
  });

  it('有建設的地方不能直接改地形', () => {
    const w = flatWorld(32);
    must(w, { op: 'road', tiles: [w.index(3, 3)] });
    expect(applyCommand(w, { op: 'terrain', tool: 'raise', x: 3, y: 3 }).ok).toBe(false);
  });
});
