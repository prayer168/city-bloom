// 階段六校正：在真實地圖上蓋一座小城市，跑很多年，看災害頻率、淹水大小、損失、水庫
import { generateMap } from '../src/sim/mapgen.js';
import { applyCommand } from '../src/sim/commands.js';
import { tick } from '../src/sim/tick.js';
import { prepareForecast } from '../src/climate/events.js';
import { updateFloodRisk } from '../src/sim/systems/disaster.js';

const preset = process.argv[2] || 'river-plain';
const scenario = process.argv[3] || 'mid';
const years = +(process.argv[4] || 15);
const w = generateMap({ seed: 20261016, preset, size: 128, cityOptions: { scenario } });
w.city.climate.scenario = scenario;
w.city.funds = 1e7;
const S = w.size, idx = (x, y) => y * S + x;
// 找靠近河或海、平坦的 40×14 區塊
let best = null;
for (let y0 = 4; y0 < S - 18; y0 += 2) for (let x0 = 4; x0 < S - 44; x0 += 2) {
  let ok = true, water = 0;
  for (let y = y0; y < y0 + 14 && ok; y++) for (let x = x0; x < x0 + 40; x++) { if (w.surface[idx(x, y)] === 2) { ok = false; break; } }
  if (!ok) continue;
  for (let y = y0 - 3; y < y0 + 17; y++) for (let x = x0 - 3; x < x0 + 43; x++) if (w.inBounds(x, y) && w.surface[idx(x, y)] === 2) water++;
  let lo = 0; for (let y = y0; y < y0 + 14; y++) for (let x = x0; x < x0 + 40; x++) lo += w.layers.elev[idx(x, y)];
  const score = water * 10 - lo / 560;
  if (water > 0 && (!best || score > best.score)) best = { x0, y0, score };
}
const { x0: X, y0: Y } = best;
const row = (y, a, b) => { const t = []; for (let x = a; x <= b; x++) t.push(idx(x, y)); return t; };
const rect = (a, b, c, d) => { const t = []; for (let y = b; y <= d; y++) for (let x = a; x <= c; x++) t.push(idx(x, y)); return t; };
const cmds = [
  { op: 'road', tiles: row(Y + 6, X, X + 39) }, { op: 'road', tiles: rect(X + 14, Y, X + 14, Y + 13) },
  { op: 'zone', zone: 2, tiles: rect(X, Y, X + 13, Y + 5) }, { op: 'zone', zone: 1, tiles: rect(X, Y + 7, X + 13, Y + 13) },
  { op: 'zone', zone: 4, tiles: rect(X + 15, Y, X + 26, Y + 5) }, { op: 'zone', zone: 6, tiles: rect(X + 15, Y + 7, X + 30, Y + 13) },
];
for (const c of cmds) { const r = applyCommand(w, c); if (!r.ok) console.log('fail', c.op, r.reason); }
// 電廠：找空地
let placed = false;
for (let y = Y; y < Y + 10 && !placed; y++) for (let x = X + 31; x < X + 37 && !placed; x++) {
  const r = applyCommand(w, { op: 'plant', type: 'coal', x, y }); if (r.ok) placed = true;
}
if (!placed) { applyCommand(w, { op: 'terrain', tool: 'level', x: X + 34, y: Y + 2, radius: 2, targetLevel: w.level(idx(X + 34, Y + 2)) }); console.log('plant', applyCommand(w, { op: 'plant', type: 'coal', x: X + 32, y: Y }).reason); }
applyCommand(w, { op: 'powerline', tiles: row(Y + 2, X + 27, X + 33) });
applyCommand(w, { op: 'powerline', tiles: [idx(X + 14, Y + 3), idx(X + 14, Y + 9), idx(X + 20, Y + 6), idx(X + 5, Y + 6)] });
if (process.argv[5] === 'adapt') {
  console.log('pond', applyCommand(w, { op: 'adapt', type: 'detentionPond', x: X + 2, y: Y - 3 }).reason || 'ok');
  console.log('perm', applyCommand(w, { op: 'cover', flag: 'permeable', tiles: rect(X, Y, X + 30, Y + 13) }).reason || 'ok');
}
prepareForecast(w); updateFloodRisk(w);
let tot = 0, ms = 0, maxMs = 0;
const ev = {};
for (let k = 0; k < years * 12; k++) {
  const r = tick(w);
  ms += r.ms; maxMs = Math.max(maxMs, r.ms);
  const h = w.city.history.monthly.at(-1);
  for (const e of h.events) ev[e] = (ev[e] || 0) + 1;
  tot += h.lossK;
  for (const rep of r.reports) console.log(`${h.y}/${h.m}`, rep.title, (rep.rows.find((x) => x[0] === '雨量') || [])[1] || '', 'flood', rep.compare?.withTiles ?? '', '/no', rep.compare?.withoutTiles ?? '', 'dev', (rep.rows.find((x) => x[0] === '市區淹水') || [])[1] || '', 'loss', Math.round(rep.lossK / 10), '萬 pop', h.pop, 'water', h.water, 'sea', h.seaCm, rep.rows.filter((x)=>/停電|風速|水位|蓄水|燈號|35/.test(x[0])).map(x=>x.join(':')).join(' | '));
}
const h = w.city.history.monthly.at(-1);
console.log('jobs', h.jobsC, h.jobsI, JSON.stringify(w.city.demandRCI), JSON.stringify(w.city.demandFactors), 'site', X, Y, 'unpowered', w.city.power.unpoweredTiles, 'gen', Math.round(w.city.power.generationMWh));
console.log('events', JSON.stringify(ev), 'totalLoss 萬', Math.round(tot / 10), 'pop', h.pop, 'funds', Math.round(w.city.funds), 'avg ms', (ms / (years * 12)).toFixed(1), 'max', maxMs.toFixed(0), 'resil', JSON.stringify(w.city.resilience), 'coastal', JSON.stringify(w.city.climate.coastal));
