import { generateMap } from '../src/sim/mapgen.js';
import { applyCommand } from '../src/sim/commands.js';
import { computeFlood, floodSummary } from '../src/sim/systems/flood.js';
const w = generateMap({ seed: 20261016, preset: 'river-plain', size: 128 });
w.city.funds = 1e9;
const S = 128, idx = (x, y) => y * S + x, X = 44, Y = 72;
const lv = w.level(idx(X + 20, Y + 6));
const before = [];
for (let y = Y - 3; y < Y + 15; y++) { let r = ''; for (let x = X - 3; x < X + 43; x += 3) r += String(Math.round((w.layers.elev[idx(x, y)] - 10000) / 10)).padStart(4); before.push(r); }
for (let y = Y; y < Y + 12; y++) for (let x = X; x < X + 40; x++) applyCommand(w, { op: 'terrain', tool: 'level', x, y, radius: 0, targetLevel: lv });
console.log('level', lv, 'elev of town', w.layers.elev[idx(X + 5, Y + 5)] - 10000);
console.log(before.join('\n'));
const row = (y, a, b) => { const t = []; for (let x = a; x <= b; x++) t.push(idx(x, y)); return t; };
const rect = (a, b, c, d) => { const t = []; for (let y = b; y <= d; y++) for (let x = a; x <= c; x++) t.push(idx(x, y)); return t; };
applyCommand(w, { op: 'road', tiles: row(Y + 5, X, X + 39) });
applyCommand(w, { op: 'zone', zone: 2, tiles: rect(X, Y + 1, X + 11, Y + 4) });
for (const i of rect(X, Y + 1, X + 11, Y + 4)) { w.layers.devLevel[i] = 2; }
const a = computeFlood(w, { rainMm: 296, riverStage: 0 });
const b = computeFlood(w, { rainMm: 0, riverStage: 1.2 });
const c = computeFlood(w, { rainMm: 296 });
console.log('pluvial', JSON.stringify(floodSummary(w, a.depth)), 'fluvial', JSON.stringify(floodSummary(w, b.depth)), 'both', JSON.stringify(floodSummary(w, c.depth)));
let r = ''; for (let y = Y - 2; y < Y + 14; y++) { for (let x = X - 2; x < X + 42; x++) { const d = a.depth[idx(x, y)]; r += d > 0.5 ? '#' : d > 0.1 ? '+' : d > 0.02 ? '.' : ' '; } r += '\n'; } console.log(r);
