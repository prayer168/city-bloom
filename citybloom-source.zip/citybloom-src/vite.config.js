import { defineConfig } from 'vite';

// GitHub Pages 部署在 https://prayer168.github.io/city-bloom/
// 若改用其他 repo 名稱，修改 base 即可。
export default defineConfig({
  base: process.env.ZC_BASE ?? '/city-bloom/',
  build: {
    target: 'es2020',
    outDir: 'dist',
    assetsInlineLimit: 0,
  },
  test: {
    environment: 'node',
    include: ['tests/**/*.test.js'],
  },
});
